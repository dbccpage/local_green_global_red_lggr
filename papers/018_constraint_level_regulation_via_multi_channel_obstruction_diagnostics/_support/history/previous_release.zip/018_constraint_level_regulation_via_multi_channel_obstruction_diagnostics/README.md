# Constraint-Level Regulation via Multi-Channel Obstruction Diagnostics

**Monograph 018** | Finite Obstruction Calculus Program  
**DOI:** 10.5281/zenodo.20214310 | **Version:** 2.0.2

## Abstract
This paper formalizes a repair-selection controller for discrete constraint systems. By monitoring five obstruction channels (geometric quotient residual, logical inconsistency, curvature defect, relational interface drift, and trace distortion), the controller filters and ranks candidate repair operators under strict piecewise closure ratio (R_cl) guardrails, guarded descent bounds, and strict trace metric tie-breaking.

## Quick Start
```bash
py -3.12 -m pytest code/tests/
py -3.12 verify_deposit.py --test code/tests/test_constraint_regulation.py --lean
```

