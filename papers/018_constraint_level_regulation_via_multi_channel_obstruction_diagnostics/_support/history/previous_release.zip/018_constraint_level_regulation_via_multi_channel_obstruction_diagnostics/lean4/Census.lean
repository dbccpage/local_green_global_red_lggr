import Regulate

#print axioms zero_geom_rejects_curvature
#print axioms zero_geom_rejects_xi
#print axioms separated_sat_accepts
#print axioms ratio_infinite_rejects
#print axioms collapsed_pair_passes
#print axioms ratio_positive_rejects
#print axioms ratio_positive_admits
#print axioms descent_rejects
#print axioms tearing_after_descent
#print axioms deletion_shaped_passes
#print axioms lift_rejects
#print axioms lift_accepts
#print axioms outside_eps_loses
#print axioms lower_xi_in_score_tie
#print axioms name_orders_exact_tie
#print axioms empty_is_stalled
#print axioms classify_all_tearing
#print axioms classify_all_descent
#print axioms classify_all_invalid
#print axioms mixed_stalls
