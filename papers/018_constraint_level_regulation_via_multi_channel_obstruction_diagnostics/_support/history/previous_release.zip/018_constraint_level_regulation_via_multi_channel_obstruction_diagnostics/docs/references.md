# References

1. Carroll, J. H. (2026). *An L1 Obstruction Framework for Coboundary Defects*. Zenodo. DOI: 10.5281/zenodo.20186809.
2. Carroll, J. H. (2026). *Constraint-Level Regulation via Multi-Channel Obstruction Diagnostics*. Zenodo. DOI: 10.5281/zenodo.20214310.
3. Carroll, J. H. (2026). *Observer-Robust Control of Obstruction Diagnostics*. Zenodo. DOI: 10.5281/zenodo.20214468.
4. Bertsekas, D. P. (2017). *Dynamic Programming and Optimal Control*. Athena Scientific.
5. Boyd, S., & Vandenberghe, L. (2004). *Convex Optimization*. Cambridge University Press.
