"""Executable Python/Rust companion harness for Paper 012-000 (Relational Reasoning & RSI No-Go).

AuthorityEffect: None.

Instantiates finite-state self-modifying transition graphs over container-free relational
carriers, records the exact step k <= N + 1 at which:
1. Report collision / Goodhart decoupling (`REPORT_COLLISION`),
2. Lift-budget exhaustion (`LIFT_BUDGET_EXHAUSTION`, budget = 0), or
3. Overlap gluing refusal (`OVERLAP_GLUING_REFUSAL`, Phi_1([delta]) > 0)
occurs, and cross-checks the emitted refusal receipts against the Rust
`omega_epistemic_immune_system` crate (`independence::assert_signals_independent`,
`independence::signal1_digest`, and `TwoSignalDangerGate::evaluate`).
"""

from __future__ import annotations

import argparse
from collections.abc import Callable, Mapping, Sequence
from dataclasses import dataclass, field
from fractions import Fraction
import hashlib
import json
import math
import os
from pathlib import Path
import subprocess
import tempfile

DANGER_KINDS: tuple[str, ...] = (
    "MALFORMED_PAYLOAD",
    "MANIFEST_CONTAMINATION",
    "PROTECTED_FIELD_VIOLATION",
    "REPLAY_FAILURE",
)

FORBIDDEN_SELF_OBSERVERS: frozenset[str] = frozenset(
    {"model", "llm", "agent", "detector", "matcher"}
)


def _ascii_json_string(text: str) -> str:
    out: list[str] = ['"']
    for ch in text:
        code = ord(ch)
        if ch == '"':
            out.append('\\"')
        elif ch == "\\":
            out.append("\\\\")
        elif ch == "\b":
            out.append("\\b")
        elif ch == "\f":
            out.append("\\f")
        elif ch == "\n":
            out.append("\\n")
        elif ch == "\r":
            out.append("\\r")
        elif ch == "\t":
            out.append("\\t")
        elif not (0x20 <= code < 0x7F):
            encoded = ch.encode("utf-16-be")
            for idx in range(0, len(encoded), 2):
                unit = (encoded[idx] << 8) | encoded[idx + 1]
                out.append(f"\\u{unit:04x}")
        else:
            out.append(ch)
    out.append('"')
    return "".join(out)


def compute_signal1_digest(matches: list[dict[str, object]]) -> str:
    """Compute exact SHA-256 Signal 1 digest matching `omega_epistemic_immune_system::independence::signal1_digest`."""
    rows = sorted(
        matches,
        key=lambda r: (
            str(r["epitope_name"]),
            str(r["pattern_matched"]),
            int(r["offset"]),
        ),
    )
    parts: list[str] = ["["]
    for idx, row in enumerate(rows):
        if idx > 0:
            parts.append(",")
        offset_val = int(row["offset"])
        if offset_val < 0 or isinstance(row["offset"], bool):
            raise ValueError("EIS_VALUE_ERROR: offset must be an exact nonnegative integer")
        parts.append(
            "["
            + _ascii_json_string(str(row["epitope_name"]))
            + ","
            + _ascii_json_string(str(row["pattern_matched"]))
            + ","
            + str(offset_val)
            + "]"
        )
    parts.append("]")
    raw = "".join(parts).encode("utf-8")
    return "sha256:" + hashlib.sha256(raw).hexdigest()


def _trim_python(text: str) -> str:
    return text.strip()


def verify_signal_independence(
    matches: list[dict[str, object]],
    danger: dict[str, object] | None,
    context: dict[str, object],
) -> dict[str, object]:
    """Verify two-signal independence matching `omega_epistemic_immune_system::independence::assert_signals_independent`."""
    if danger is None:
        return {"ok": "no Signal 2 was observed"}

    detector_id = str(context.get("detector_id", ""))
    if not _trim_python(detector_id):
        return {
            "error": {
                "code": "EIS_VALUE_ERROR",
                "message": "EIS_VALUE_ERROR: detector_id must name the matcher that produced Signal 1",
            }
        }

    observer = str(danger.get("observer_id", ""))
    if not _trim_python(observer):
        return {
            "error": {
                "code": "UNWITNESSED_DANGER_SIGNAL",
                "message": "UNWITNESSED_DANGER_SIGNAL: Signal 2 names no host observer, so its independence cannot be checked",
            }
        }

    folded = _trim_python(observer).casefold()
    if folded in FORBIDDEN_SELF_OBSERVERS:
        return {
            "error": {
                "code": "TWO_SIGNAL_COLLAPSE",
                "message": (
                    f"TWO_SIGNAL_COLLAPSE: Signal 2 was reported by {observer!r}; "
                    "danger is observed by a host check, not proposed by a model or a detector"
                ),
            }
        }

    if folded == _trim_python(detector_id).casefold():
        return {
            "error": {
                "code": "TWO_SIGNAL_COLLAPSE",
                "message": (
                    f"TWO_SIGNAL_COLLAPSE: Signal 2 was observed by {observer!r}, "
                    "the matcher that produced Signal 1; the danger bit is derived from the match"
                ),
            }
        }

    danger_type = str(danger.get("danger_type", ""))
    if danger_type not in DANGER_KINDS:
        return {
            "error": {
                "code": "UNREGISTERED_DANGER_KIND",
                "message": (
                    f"UNREGISTERED_DANGER_KIND: {danger_type!r} is not in the closed registry: "
                    + ", ".join(DANGER_KINDS)
                ),
            }
        }

    predicates = set(context.get("detector_predicates", []))
    if danger_type in predicates:
        return {
            "error": {
                "code": "TWO_SIGNAL_COLLAPSE",
                "message": (
                    f"TWO_SIGNAL_COLLAPSE: the matcher {detector_id!r} already evaluates {danger_type}; "
                    "the same predicate would be counted twice"
                ),
            }
        }

    evidence_digest = str(danger.get("evidence_digest", ""))
    if matches and evidence_digest == compute_signal1_digest(matches):
        return {
            "error": {
                "code": "TWO_SIGNAL_COLLAPSE",
                "message": (
                    "TWO_SIGNAL_COLLAPSE: Signal 2's evidence is the digest of the Signal 1 matches; "
                    "that is one signal counted twice"
                ),
            }
        }

    if bool(context.get("offsets_are_content", False)):
        spans = list(danger.get("evidence_spans", []))
        for m in matches:
            offset = int(m["offset"])
            pat_len = max(1, len(str(m["pattern_matched"])))
            stop = offset + pat_len
            for low, high in spans:
                if offset < int(high) and int(low) < stop:
                    return {
                        "error": {
                            "code": "TWO_SIGNAL_COLLAPSE",
                            "message": (
                                f"TWO_SIGNAL_COLLAPSE: the Signal 1 match at characters [{offset}, {stop}) "
                                f"lies inside the {danger_type} evidence; one token cannot be both signals"
                            ),
                        }
                    }

    defect_count = int(danger.get("defect_count", 0))
    prefix = evidence_digest[:23]
    return {
        "ok": (
            f"host observer {observer} reported {danger_type} "
            f"({defect_count} defect(s), evidence {prefix}...), "
            f"distinct from matcher {detector_id} and its matches"
        )
    }


@dataclass(frozen=True)
class TransitionState:
    """State of a finite relational model at step k."""

    step_index: int
    report_id: int
    internal_eval: int
    remaining_budget: int
    requests_carrier_lift: bool = False
    edge_cochain: dict[tuple[int, int], Fraction] = field(default_factory=dict)
    signal2_observer_id: str = "host.rsi_obstruction_gate"


@dataclass(frozen=True)
class ObstructionReceipt:
    """Exact obstruction termination receipt at step k <= N + 1."""

    halted: bool
    obstruction_kind: str
    termination_step: int
    carrier_capacity: int
    horizon_bound: int
    colliding_prior_step: int | None
    remaining_budget: int
    phi1_holonomy: Fraction
    eis_vector: dict[str, object]
    eis_independence_verdict: dict[str, object]


def compute_d1_triangle(
    cochain: dict[tuple[int, int], Fraction], u: int, v: int, w: int
) -> Fraction:
    """Exact 1-coboundary (d^1 delta)(u, v, w) = delta(u, v) + delta(v, w) - delta(u, w)."""
    duv = cochain.get((u, v), Fraction(0, 1))
    dvw = cochain.get((v, w), Fraction(0, 1))
    duw = cochain.get((u, w), Fraction(0, 1))
    return duv + dvw - duw


def compute_phi1_holonomy(
    cochain: dict[tuple[int, int], Fraction],
    triangles: tuple[tuple[int, int, int], ...],
) -> Fraction:
    """Exact rational L1 coboundary holonomy functional Phi_1([delta]) = sum_{t in T} |d^1 delta(t)|."""
    total = Fraction(0, 1)
    for u, v, w in triangles:
        val = compute_d1_triangle(cochain, u, v, w)
        if not isinstance(val, Fraction):
            raise TypeError("Cochain values must be exact fractions.Fraction")
        total += abs(val)
    return total


class FiniteStateSelfModifyingGraph:
    """Finite-state self-modifying transition graph over a relational carrier of capacity N."""

    def __init__(
        self,
        carrier_capacity: int,
        initial_lift_budget: int,
        triangles: tuple[tuple[int, int, int], ...] = ((0, 1, 2),),
        detector_id: str = "detector.rsi_claim_scanner",
    ) -> None:
        if isinstance(carrier_capacity, bool) or not isinstance(carrier_capacity, int) or carrier_capacity <= 0:
            raise ValueError("carrier_capacity N must be a positive integer")
        if isinstance(initial_lift_budget, bool) or not isinstance(initial_lift_budget, int) or initial_lift_budget < 0:
            raise ValueError("initial_lift_budget B_0 must be a non-negative integer")
        self.carrier_capacity = carrier_capacity
        self.initial_lift_budget = initial_lift_budget
        self.triangles = triangles
        self.detector_id = detector_id

    def run_trajectory(
        self,
        initial_state: TransitionState,
        step_fn: Callable[[TransitionState], TransitionState],
    ) -> ObstructionReceipt:
        """Execute M_{k+1} = Phi(M_k) and record the exact step k <= N + 1 at which refusal occurs."""
        horizon_bound = self.carrier_capacity + 1
        seen_reports: dict[int, int] = {}
        current = initial_state
        budget = self.initial_lift_budget

        for k in range(horizon_bound + 1):
            if current.report_id < 0 or current.report_id >= self.carrier_capacity:
                raise ValueError(
                    f"report_id {current.report_id} outside finite carrierFin({self.carrier_capacity})"
                )

            # 1. Check Overlap Gluing Refusal: Phi_1([delta_k]) > 0
            phi1 = compute_phi1_holonomy(current.edge_cochain, self.triangles)
            if phi1 > Fraction(0, 1):
                return self._build_receipt(
                    obstruction_kind="OVERLAP_GLUING_REFUSAL",
                    danger_type="PROTECTED_FIELD_VIOLATION",
                    step=k,
                    colliding_prior_step=None,
                    remaining_budget=budget,
                    phi1_holonomy=phi1,
                    observer_id=current.signal2_observer_id,
                    pattern_matched=f"step_{k}_claim_glued_section",
                )

            # 2. Check Lift-Budget Exhaustion: requests_carrier_lift when budget == 0
            if current.requests_carrier_lift:
                if budget == 0:
                    return self._build_receipt(
                        obstruction_kind="LIFT_BUDGET_EXHAUSTION",
                        danger_type="MANIFEST_CONTAMINATION",
                        step=k,
                        colliding_prior_step=None,
                        remaining_budget=0,
                        phi1_holonomy=phi1,
                        observer_id=current.signal2_observer_id,
                        pattern_matched=f"step_{k}_claim_unlicensed_carrier_lift",
                    )
                budget -= 1

            # 3. Check Report Collision / Goodhart Decoupling at step k <= N
            if current.report_id in seen_reports:
                prior_step = seen_reports[current.report_id]
                return self._build_receipt(
                    obstruction_kind="REPORT_COLLISION",
                    danger_type="REPLAY_FAILURE",
                    step=k,
                    colliding_prior_step=prior_step,
                    remaining_budget=budget,
                    phi1_holonomy=phi1,
                    observer_id=current.signal2_observer_id,
                    pattern_matched=f"step_{k}_claim_strict_dominance_over_step_{prior_step}",
                )

            if current.internal_eval >= self.carrier_capacity:
                return self._build_receipt(
                    obstruction_kind="REPORT_COLLISION",
                    danger_type="REPLAY_FAILURE",
                    step=k,
                    colliding_prior_step=0,
                    remaining_budget=budget,
                    phi1_holonomy=phi1,
                    observer_id=current.signal2_observer_id,
                    pattern_matched=f"step_{k}_goodhart_decoupled_eval_{current.internal_eval}",
                )

            seen_reports[current.report_id] = k
            current = step_fn(
                TransitionState(
                    step_index=k,
                    report_id=current.report_id,
                    internal_eval=current.internal_eval,
                    remaining_budget=budget,
                    requests_carrier_lift=current.requests_carrier_lift,
                    edge_cochain=current.edge_cochain,
                    signal2_observer_id=current.signal2_observer_id,
                )
            )

        raise RuntimeError("Unreachable: pigeonhole principle forces collision by step N <= N + 1")

    def _build_receipt(
        self,
        obstruction_kind: str,
        danger_type: str,
        step: int,
        colliding_prior_step: int | None,
        remaining_budget: int,
        phi1_holonomy: Fraction,
        observer_id: str,
        pattern_matched: str,
    ) -> ObstructionReceipt:
        horizon_bound = self.carrier_capacity + 1
        assert 0 <= step <= horizon_bound, f"Step {step} exceeded N + 1 = {horizon_bound}"

        matches: list[dict[str, object]] = [
            {
                "epitope_name": f"rsi.{obstruction_kind.lower()}",
                "pattern_matched": pattern_matched,
                "offset": 0,
            }
        ]
        evidence_payload = (
            f"obstruction={obstruction_kind};step={step};N={self.carrier_capacity};"
            f"prior={colliding_prior_step};budget={remaining_budget};"
            f"phi1={phi1_holonomy.numerator}/{phi1_holonomy.denominator}"
        ).encode("utf-8")
        evidence_digest = "sha256:" + hashlib.sha256(evidence_payload).hexdigest()

        danger: dict[str, object] = {
            "danger_type": danger_type,
            "observer_id": observer_id,
            "evidence_digest": evidence_digest,
            "defect_count": 1,
            "evidence_spans": [[128, 192]],
        }
        context: dict[str, object] = {
            "detector_id": self.detector_id,
            "detector_predicates": ["UNREGISTERED_SELF_PROXY"],
            "offsets_are_content": True,
        }
        eis_vector: dict[str, object] = {
            "matches": matches,
            "danger": danger,
            "context": context,
            "signal1_digest": compute_signal1_digest(matches),
        }
        verdict = verify_signal_independence(matches, danger, context)
        return ObstructionReceipt(
            halted=True,
            obstruction_kind=obstruction_kind,
            termination_step=step,
            carrier_capacity=self.carrier_capacity,
            horizon_bound=horizon_bound,
            colliding_prior_step=colliding_prior_step,
            remaining_budget=remaining_budget,
            phi1_holonomy=phi1_holonomy,
            eis_vector=eis_vector,
            eis_independence_verdict=verdict,
        )


@dataclass(frozen=True)
class HypergraphAgentSpec:
    """Finite-state transition agent specification in a communicating hypergraph."""

    agent_id: str
    carrier_capacity: int

    def __post_init__(self) -> None:
        if not self.agent_id.strip():
            raise ValueError("agent_id must be non-empty")
        if (
            isinstance(self.carrier_capacity, bool)
            or not isinstance(self.carrier_capacity, int)
            or self.carrier_capacity <= 0
        ):
            raise ValueError("carrier_capacity N_i must be a positive integer")


@dataclass(frozen=True)
class SharedTwoComplex:
    """Shared 2-complex K = (V, E, T) across which communicating hypergraph agents exchange boundary projections."""

    vertices: tuple[int, ...] = (0, 1, 2)
    triangles: tuple[tuple[int, int, int], ...] = ((0, 1, 2),)
    shared_edges: tuple[tuple[int, int], ...] = ((0, 1), (1, 2), (0, 2))


@dataclass(frozen=True)
class MultiAgentTransitionState:
    """Joint state of m >= 2 finite relational models exchanging boundary projections pi_A(M_k) across a shared 2-complex."""

    step_index: int
    agent_reports: tuple[int, ...]
    joint_internal_eval: int
    remaining_budget: int
    requests_carrier_lift: bool = False
    edge_cochain: dict[tuple[int, int], Fraction] = field(default_factory=dict)
    agent_edge_proposals: dict[str, dict[tuple[int, int], Fraction]] = field(default_factory=dict)
    signal2_observer_id: str = "host.hypergraph_obstruction_gate"


@dataclass(frozen=True)
class HypergraphObstructionReceipt:
    """Exact obstruction termination receipt at step k <= N_A * N_B + 1 for a multi-agent communicating hypergraph."""

    halted: bool
    obstruction_kind: str
    termination_step: int
    agent_capacities: tuple[int, ...]
    product_carrier_capacity: int
    horizon_bound: int
    single_agent_max_capacity: int
    delayed_beyond_single_agent: bool
    colliding_prior_step: int | None
    colliding_joint_report: tuple[int, ...] | None
    remaining_budget: int
    phi1_holonomy: Fraction
    boundary_exchange_trace: tuple[tuple[int, ...], ...]
    eis_vector: dict[str, object]
    eis_independence_verdict: dict[str, object]

    @property
    def carrier_capacity(self) -> int:
        return self.product_carrier_capacity

    def to_obstruction_receipt(self) -> ObstructionReceipt:
        return ObstructionReceipt(
            halted=self.halted,
            obstruction_kind=self.obstruction_kind,
            termination_step=self.termination_step,
            carrier_capacity=self.product_carrier_capacity,
            horizon_bound=self.horizon_bound,
            colliding_prior_step=self.colliding_prior_step,
            remaining_budget=self.remaining_budget,
            phi1_holonomy=self.phi1_holonomy,
            eis_vector=self.eis_vector,
            eis_independence_verdict=self.eis_independence_verdict,
        )


def compute_hypergraph_phi1_holonomy(
    edge_cochain: dict[tuple[int, int], Fraction],
    agent_edge_proposals: dict[str, dict[tuple[int, int], Fraction]],
    shared_complex: SharedTwoComplex,
) -> Fraction:
    """Compute exact rational L1 holonomy Phi_1([delta]) on a shared 2-complex across communicating agents.

    Combines:
    1. Triangle coboundary circulation sum_{(u,v,w) in T} |(d^1 delta)(u,v,w)| on the shared 2-complex.
    2. Inter-agent overlap section disagreement sum_{i < j} sum_{e in E_shared} |delta^{(i)}(e) - delta^{(j)}(e)|.
    All quantities are strictly required to be exact `fractions.Fraction`.
    """
    total = compute_phi1_holonomy(edge_cochain, shared_complex.triangles)
    agent_ids = sorted(agent_edge_proposals.keys())
    for idx_i in range(len(agent_ids)):
        prop_i = agent_edge_proposals[agent_ids[idx_i]]
        for idx_j in range(idx_i + 1, len(agent_ids)):
            prop_j = agent_edge_proposals[agent_ids[idx_j]]
            for edge in shared_complex.shared_edges:
                if edge in prop_i and edge in prop_j:
                    val_i = prop_i[edge]
                    val_j = prop_j[edge]
                    if not isinstance(val_i, Fraction) or not isinstance(val_j, Fraction):
                        raise TypeError("Agent edge cochain proposals must be exact fractions.Fraction")
                    total += abs(val_i - val_j)
    return total


def build_flat_shared_cochain(
    agent_reports: tuple[int, ...],
    shared_complex: SharedTwoComplex = SharedTwoComplex(),
) -> dict[tuple[int, int], Fraction]:
    """Construct an exact 0-coboundary 1-cochain d^0(alpha) on `shared_complex` from exchanged boundary projections."""
    alpha: dict[int, Fraction] = {}
    for idx, v in enumerate(shared_complex.vertices):
        rep = agent_reports[idx % len(agent_reports)]
        alpha[v] = Fraction(int(rep), int(idx + 1))
    cochain: dict[tuple[int, int], Fraction] = {}
    for u, v, w in shared_complex.triangles:
        for src, dst in ((u, v), (v, w), (u, w)):
            cochain[(src, dst)] = alpha.get(dst, Fraction(0, 1)) - alpha.get(src, Fraction(0, 1))
    for src, dst in shared_complex.shared_edges:
        cochain[(src, dst)] = alpha.get(dst, Fraction(0, 1)) - alpha.get(src, Fraction(0, 1))
    return cochain


def coupled_odometer_step_fn(
    agent_capacities: tuple[int, ...],
    shared_complex: SharedTwoComplex = SharedTwoComplex(),
) -> Callable[[MultiAgentTransitionState], MultiAgentTransitionState]:
    """Coupled co-adaptation operator where agents exchange boundary projections pi_A(M_k), pi_B(M_k) across K.

    Agent m-1 advances every step; each upstream agent i advances iff all downstream boundary projections
    pi_j(M_k) (j > i) hit their boundary carry threshold N_j - 1. This co-adaptation delays joint report
    collision past max_i(N_i) to the exact product-carrier bound prod_i(N_i) <= prod_i(N_i) + 1 while
    maintaining exact rational Phi_1([delta]) = 0 on the shared 2-complex.
    """
    product_cap = math.prod(agent_capacities)

    def _step(state: MultiAgentTransitionState) -> MultiAgentTransitionState:
        next_reports = list(state.agent_reports)
        carry = True
        for idx in range(len(agent_capacities) - 1, -1, -1):
            if carry:
                if next_reports[idx] + 1 < agent_capacities[idx]:
                    next_reports[idx] += 1
                    carry = False
                else:
                    next_reports[idx] = 0
                    carry = True
        reports_tuple = tuple(next_reports)
        flat_cochain = build_flat_shared_cochain(reports_tuple, shared_complex)
        return MultiAgentTransitionState(
            step_index=state.step_index + 1,
            agent_reports=reports_tuple,
            joint_internal_eval=(state.joint_internal_eval + 1) % product_cap,
            remaining_budget=state.remaining_budget,
            requests_carrier_lift=state.requests_carrier_lift,
            edge_cochain=flat_cochain,
            agent_edge_proposals={
                f"agent_{i}": dict(flat_cochain) for i in range(len(agent_capacities))
            },
            signal2_observer_id=state.signal2_observer_id,
        )

    return _step


def uncoupled_parallel_step_fn(
    agent_capacities: tuple[int, ...],
    shared_complex: SharedTwoComplex = SharedTwoComplex(),
) -> Callable[[MultiAgentTransitionState], MultiAgentTransitionState]:
    """Uncoupled parallel evolution where each agent updates pi_i(M_{k+1}) = (pi_i(M_k) + 1) mod N_i without cross-reading."""
    product_cap = math.prod(agent_capacities)

    def _step(state: MultiAgentTransitionState) -> MultiAgentTransitionState:
        reports_tuple = tuple(
            (rep + 1) % cap for rep, cap in zip(state.agent_reports, agent_capacities)
        )
        flat_cochain = build_flat_shared_cochain(reports_tuple, shared_complex)
        return MultiAgentTransitionState(
            step_index=state.step_index + 1,
            agent_reports=reports_tuple,
            joint_internal_eval=(state.joint_internal_eval + 1) % product_cap,
            remaining_budget=state.remaining_budget,
            requests_carrier_lift=state.requests_carrier_lift,
            edge_cochain=flat_cochain,
            agent_edge_proposals={
                f"agent_{i}": dict(flat_cochain) for i in range(len(agent_capacities))
            },
            signal2_observer_id=state.signal2_observer_id,
        )

    return _step


class MultiAgentCommunicatingHypergraph:
    """Multi-agent communicating hypergraph of m >= 2 finite-state transition graphs exchanging pi_i(M_k) across a shared 2-complex."""

    def __init__(
        self,
        agents: Sequence[HypergraphAgentSpec],
        initial_lift_budget: int,
        shared_complex: SharedTwoComplex = SharedTwoComplex(),
        detector_id: str = "detector.hypergraph_rsi_scanner",
    ) -> None:
        if len(agents) < 2:
            raise ValueError("MultiAgentCommunicatingHypergraph requires at least 2 agents")
        if (
            isinstance(initial_lift_budget, bool)
            or not isinstance(initial_lift_budget, int)
            or initial_lift_budget < 0
        ):
            raise ValueError("initial_lift_budget B_0 must be a non-negative integer")
        self.agents: tuple[HypergraphAgentSpec, ...] = tuple(agents)
        self.agent_capacities: tuple[int, ...] = tuple(a.carrier_capacity for a in self.agents)
        self.product_carrier_capacity: int = math.prod(self.agent_capacities)
        self.horizon_bound: int = self.product_carrier_capacity + 1
        self.single_agent_max_capacity: int = max(self.agent_capacities)
        self.initial_lift_budget = initial_lift_budget
        self.shared_complex = shared_complex
        self.detector_id = detector_id

    def encode_joint_report(self, agent_reports: tuple[int, ...]) -> int:
        """Bijective mixed-radix encoding of (pi_1(M_k), ..., pi_m(M_k)) into Fin(prod_i N_i)."""
        if len(agent_reports) != len(self.agents):
            raise ValueError(
                f"Expected {len(self.agents)} agent boundary reports, got {len(agent_reports)}"
            )
        code = 0
        for idx, (rep, spec) in enumerate(zip(agent_reports, self.agents)):
            if isinstance(rep, bool) or not isinstance(rep, int) or rep < 0 or rep >= spec.carrier_capacity:
                raise ValueError(
                    f"Agent {spec.agent_id} (index {idx}) report_id {rep} outside Fin({spec.carrier_capacity})"
                )
            code = code * spec.carrier_capacity + rep
        return code

    def run_coupled_trajectory(
        self,
        initial_state: MultiAgentTransitionState,
        step_fn: Callable[[MultiAgentTransitionState], MultiAgentTransitionState],
    ) -> HypergraphObstructionReceipt:
        """Execute coupled transition M_{k+1} = Phi(M_k) and record exact step k <= prod_i(N_i) + 1 of obstruction."""
        seen_joint_reports: dict[int, int] = {}
        exchange_log: list[tuple[int, ...]] = []
        current = initial_state
        budget = self.initial_lift_budget

        for k in range(self.horizon_bound + 1):
            joint_code = self.encode_joint_report(current.agent_reports)
            exchange_log.append(tuple(current.agent_reports))

            # 1. Check Overlap Gluing Refusal on the shared 2-complex: Phi_1([delta_k]) > 0
            phi1 = compute_hypergraph_phi1_holonomy(
                current.edge_cochain, current.agent_edge_proposals, self.shared_complex
            )
            if phi1 > Fraction(0, 1):
                return self._build_hypergraph_receipt(
                    obstruction_kind="OVERLAP_GLUING_REFUSAL",
                    danger_type="PROTECTED_FIELD_VIOLATION",
                    step=k,
                    colliding_prior_step=None,
                    colliding_joint_report=None,
                    remaining_budget=budget,
                    phi1_holonomy=phi1,
                    exchange_log=tuple(exchange_log),
                    observer_id=current.signal2_observer_id,
                    pattern_matched=f"hypergraph_step_{k}_claim_glued_shared_2complex",
                )

            # 2. Check Lift-Budget Exhaustion: requests_carrier_lift when budget == 0
            if current.requests_carrier_lift:
                if budget == 0:
                    return self._build_hypergraph_receipt(
                        obstruction_kind="LIFT_BUDGET_EXHAUSTION",
                        danger_type="MANIFEST_CONTAMINATION",
                        step=k,
                        colliding_prior_step=None,
                        colliding_joint_report=None,
                        remaining_budget=0,
                        phi1_holonomy=phi1,
                        exchange_log=tuple(exchange_log),
                        observer_id=current.signal2_observer_id,
                        pattern_matched=f"hypergraph_step_{k}_claim_unlicensed_product_lift",
                    )
                budget -= 1

            # 3. Check Joint Product-Carrier Report Collision / Goodhart Decoupling at k <= N_A * N_B
            if joint_code in seen_joint_reports:
                prior_step = seen_joint_reports[joint_code]
                return self._build_hypergraph_receipt(
                    obstruction_kind="REPORT_COLLISION",
                    danger_type="REPLAY_FAILURE",
                    step=k,
                    colliding_prior_step=prior_step,
                    colliding_joint_report=tuple(current.agent_reports),
                    remaining_budget=budget,
                    phi1_holonomy=phi1,
                    exchange_log=tuple(exchange_log),
                    observer_id=current.signal2_observer_id,
                    pattern_matched=(
                        f"hypergraph_step_{k}_joint_report_{joint_code}_collides_with_step_{prior_step}"
                    ),
                )

            if current.joint_internal_eval >= self.product_carrier_capacity:
                return self._build_hypergraph_receipt(
                    obstruction_kind="REPORT_COLLISION",
                    danger_type="REPLAY_FAILURE",
                    step=k,
                    colliding_prior_step=0,
                    colliding_joint_report=tuple(current.agent_reports),
                    remaining_budget=budget,
                    phi1_holonomy=phi1,
                    exchange_log=tuple(exchange_log),
                    observer_id=current.signal2_observer_id,
                    pattern_matched=(
                        f"hypergraph_step_{k}_goodhart_decoupled_joint_eval_{current.joint_internal_eval}"
                    ),
                )

            seen_joint_reports[joint_code] = k
            current = step_fn(
                MultiAgentTransitionState(
                    step_index=k,
                    agent_reports=current.agent_reports,
                    joint_internal_eval=current.joint_internal_eval,
                    remaining_budget=budget,
                    requests_carrier_lift=current.requests_carrier_lift,
                    edge_cochain=current.edge_cochain,
                    agent_edge_proposals=current.agent_edge_proposals,
                    signal2_observer_id=current.signal2_observer_id,
                )
            )

        raise RuntimeError(
            "Unreachable: product-carrier pigeonhole forces joint collision by step prod(N_i) <= prod(N_i) + 1"
        )

    def _build_hypergraph_receipt(
        self,
        obstruction_kind: str,
        danger_type: str,
        step: int,
        colliding_prior_step: int | None,
        colliding_joint_report: tuple[int, ...] | None,
        remaining_budget: int,
        phi1_holonomy: Fraction,
        exchange_log: tuple[tuple[int, ...], ...],
        observer_id: str,
        pattern_matched: str,
    ) -> HypergraphObstructionReceipt:
        assert 0 <= step <= self.horizon_bound, (
            f"Step {step} exceeded product horizon N_prod + 1 = {self.horizon_bound}"
        )
        matches: list[dict[str, object]] = [
            {
                "epitope_name": f"rsi.hypergraph.{obstruction_kind.lower()}",
                "pattern_matched": pattern_matched,
                "offset": 0,
            }
        ]
        caps_str = "x".join(str(c) for c in self.agent_capacities)
        evidence_payload = (
            f"hypergraph_obstruction={obstruction_kind};step={step};"
            f"caps={caps_str};N_prod={self.product_carrier_capacity};"
            f"prior={colliding_prior_step};budget={remaining_budget};"
            f"phi1={phi1_holonomy.numerator}/{phi1_holonomy.denominator}"
        ).encode("utf-8")
        evidence_digest = "sha256:" + hashlib.sha256(evidence_payload).hexdigest()

        danger: dict[str, object] = {
            "danger_type": danger_type,
            "observer_id": observer_id,
            "evidence_digest": evidence_digest,
            "defect_count": 1,
            "evidence_spans": [[128, 192]],
        }
        context: dict[str, object] = {
            "detector_id": self.detector_id,
            "detector_predicates": ["UNREGISTERED_SELF_PROXY"],
            "offsets_are_content": True,
        }
        eis_vector: dict[str, object] = {
            "matches": matches,
            "danger": danger,
            "context": context,
            "signal1_digest": compute_signal1_digest(matches),
            "agent_capacities": list(self.agent_capacities),
        }
        verdict = verify_signal_independence(matches, danger, context)
        return HypergraphObstructionReceipt(
            halted=True,
            obstruction_kind=obstruction_kind,
            termination_step=step,
            agent_capacities=self.agent_capacities,
            product_carrier_capacity=self.product_carrier_capacity,
            horizon_bound=self.horizon_bound,
            single_agent_max_capacity=self.single_agent_max_capacity,
            delayed_beyond_single_agent=(step > self.single_agent_max_capacity),
            colliding_prior_step=colliding_prior_step,
            colliding_joint_report=colliding_joint_report,
            remaining_budget=remaining_budget,
            phi1_holonomy=phi1_holonomy,
            boundary_exchange_trace=exchange_log,
            eis_vector=eis_vector,
            eis_independence_verdict=verdict,
        )


@dataclass(frozen=True)
class HigherCellComplex:
    """Shared higher k-cell cochain complex (C^k --d^k--> C^{k+1}) for multi-agent boundary gluing.

    An oriented (k+1)-cell is represented as a tuple of (k+2) distinct integer vertex indices
    `(v_0, v_1, ..., v_{k+1})`. Its boundary consists of (k+2) oriented k-cells
    `(v_0, ..., hat{v_i}, ..., v_{k+1})` with alternating signs `(-1)^i`.
    """

    degree: int
    k_plus_1_cells: tuple[tuple[int, ...], ...]

    def __post_init__(self) -> None:
        if self.degree < 1:
            raise ValueError(f"HigherCellComplex requires degree k >= 1, got {self.degree}")
        if not self.k_plus_1_cells:
            raise ValueError("HigherCellComplex requires at least one oriented (k+1)-simplex")
        expected_len = self.degree + 2
        for cell in self.k_plus_1_cells:
            if len(cell) != expected_len:
                raise ValueError(
                    f"Degree k={self.degree} requires (k+1)-cells of length {expected_len}, got {cell}"
                )
            if len(set(cell)) != expected_len:
                raise ValueError(f"Degenerate (k+1)-simplex is not allowed: {cell}")

    @classmethod
    def standard_simplex(
        cls, degree: int, num_cells: int = 1
    ) -> "HigherCellComplex":
        """Construct a higher k-cell complex with `num_cells` oriented (k+1)-simplices `(0, 1, ..., k, k+1+idx)`."""
        if degree < 1:
            raise ValueError(f"degree must be >= 1, got {degree}")
        if num_cells < 1:
            raise ValueError(f"num_cells must be >= 1, got {num_cells}")
        cells: list[tuple[int, ...]] = []
        base = tuple(range(degree + 1))
        for c_idx in range(num_cells):
            apex = degree + 1 + c_idx
            cells.append((*base, apex))
        return cls(degree=degree, k_plus_1_cells=tuple(cells))

    @classmethod
    def from_shared_two_complex(cls, two_complex: SharedTwoComplex) -> "HigherCellComplex":
        """Embed a `SharedTwoComplex` (C^1 --d^1--> C^2) as a degree k=1 `HigherCellComplex`."""
        return cls(degree=1, k_plus_1_cells=two_complex.triangles)

    @staticmethod
    def boundary_faces_of_simplex(
        simplex: tuple[int, ...],
    ) -> tuple[tuple[int, tuple[int, ...]], ...]:
        """Return alternating boundary faces `((-1)^i, (v_0, ..., hat{v_i}, ..., v_m))`."""
        faces: list[tuple[int, tuple[int, ...]]] = []
        for i in range(len(simplex)):
            sign = 1 if (i % 2 == 0) else -1
            face = simplex[:i] + simplex[i + 1 :]
            faces.append((sign, face))
        return tuple(faces)

    def required_k_cells(self) -> set[tuple[int, ...]]:
        """Return all oriented k-simplices appearing on the boundary of any (k+1)-cell."""
        k_cells: set[tuple[int, ...]] = set()
        for cell in self.k_plus_1_cells:
            for _, face in self.boundary_faces_of_simplex(cell):
                k_cells.add(face)
        return k_cells

    def required_k_minus_1_cells(self) -> set[tuple[int, ...]]:
        """Return all oriented (k-1)-simplices appearing on the boundary of any required k-cell."""
        km1_cells: set[tuple[int, ...]] = set()
        for k_cell in self.required_k_cells():
            for _, face in self.boundary_faces_of_simplex(k_cell):
                km1_cells.add(face)
        return km1_cells


def compute_dk_coboundary(
    k_cochain: Mapping[tuple[int, ...], Fraction],
    k_plus_1_cell: tuple[int, ...],
) -> Fraction:
    """Compute exact rational coboundary `(d^k delta^{(k)})(v_0, ..., v_{k+1})` in `C^{k+1}(X; Q)`.

    `(d^k delta^{(k)})(v_0, ..., v_{k+1}) = sum_{i=0}^{k+1} (-1)^i delta^{(k)}(v_0, ..., hat{v_i}, ..., v_{k+1})`.
    For k=1 on `(u, v, w)`, this equals `delta(v, w) - delta(u, w) + delta(u, v)`, matching `compute_d1_triangle`.
    For k=2 on `(u, v, w, z)`, this equals `delta(v,w,z) - delta(u,w,z) + delta(u,v,z) - delta(u,v,w)`,
    matching `OmegaRelationalRsi.d2` in `lean4/RelationalRsiNoGo.lean`.
    """
    if len(k_plus_1_cell) < 3:
        raise ValueError(f"(k+1)-simplex must have at least 3 vertices, got {k_plus_1_cell}")
    missing = [
        face
        for _, face in HigherCellComplex.boundary_faces_of_simplex(k_plus_1_cell)
        if face not in k_cochain
    ]
    if missing:
        raise KeyError(f"Missing k-cochain values for boundary k-faces: {missing}")
    total = Fraction(0, 1)
    for sign, face in HigherCellComplex.boundary_faces_of_simplex(k_plus_1_cell):
        val = k_cochain[face]
        if not isinstance(val, Fraction):
            raise TypeError("Higher k-cochain values must be exact fractions.Fraction")
        total += Fraction(sign, 1) * val
    return total


def build_exact_k_cochain_from_potential(
    complex_k: HigherCellComplex,
    k_minus_1_potential: Mapping[tuple[int, ...], Fraction],
) -> dict[tuple[int, ...], Fraction]:
    """Construct an exact k-cochain `delta^{(k)} = d^{k-1} eta^{(k-1)}` from a (k-1)-cochain potential.

    By the fundamental cochain identity `d^k o d^{k-1} = 0`, any k-cochain generated by this
    function satisfies `(d^k delta^{(k)})(sigma) = 0` on every (k+1)-cell `sigma`, and hence
    `Phi_1([delta^{(k)}]) = 0` in exact rational arithmetic.
    """
    required_km1 = complex_k.required_k_minus_1_cells()
    missing = [cell for cell in required_km1 if cell not in k_minus_1_potential]
    if missing:
        raise KeyError(f"Missing (k-1)-potential values for cells: {sorted(missing)}")
    k_cochain: dict[tuple[int, ...], Fraction] = {}
    for k_cell in sorted(complex_k.required_k_cells()):
        val = Fraction(0, 1)
        for sign, face in HigherCellComplex.boundary_faces_of_simplex(k_cell):
            pot_val = k_minus_1_potential[face]
            if not isinstance(pot_val, Fraction):
                raise TypeError("(k-1)-potential values must be exact fractions.Fraction")
            val += Fraction(sign, 1) * pot_val
        k_cochain[k_cell] = val
    return k_cochain


def compute_higher_cell_phi1_holonomy(
    complex_k: HigherCellComplex,
    k_cochain: Mapping[tuple[int, ...], Fraction],
) -> Fraction:
    """Compute exact rational L1 coboundary norm `Phi_1([delta^{(k)}]) = sum_{sigma in C_{k+1}} |(d^k delta^{(k)})(sigma)|`."""
    total = Fraction(0, 1)
    for cell in complex_k.k_plus_1_cells:
        total += abs(compute_dk_coboundary(k_cochain, cell))
    return total


class AsynchronousMessageDelayBuffer:
    """Bounded FIFO communication latency buffer for multi-agent boundary projection exchange.

    At step `k`, agent `a` emits its current boundary projection `pi_a(M_k^{(a)})`, which is
    stored in the channel history. The channel delivers the delayed boundary projection
    `hat{pi}_a(k) = pi_a(M_{k - tau_{a,k}}^{(a)})` where `tau_{a,k} = min(k, tau_a)` for configured
    non-negative integer latency `tau_a >= 0`.
    """

    def __init__(self, num_agents: int, latency_steps: int | Sequence[int]) -> None:
        if num_agents < 2:
            raise ValueError(f"AsynchronousMessageDelayBuffer requires >= 2 agents, got {num_agents}")
        if isinstance(latency_steps, int):
            if latency_steps < 0:
                raise ValueError(f"latency_steps must be >= 0, got {latency_steps}")
            self._latency_per_agent = tuple(latency_steps for _ in range(num_agents))
        else:
            if len(latency_steps) != num_agents:
                raise ValueError(
                    f"Expected {num_agents} latency values, got {len(latency_steps)}"
                )
            for tau in latency_steps:
                if tau < 0:
                    raise ValueError(f"Per-agent latency must be >= 0, got {tau}")
            self._latency_per_agent = tuple(int(tau) for tau in latency_steps)
        self._num_agents = num_agents
        self._history: list[tuple[int, ...]] = []

    @property
    def latency_per_agent(self) -> tuple[int, ...]:
        """Configured non-negative integer latency steps `(tau_0, ..., tau_{m-1})`."""
        return self._latency_per_agent

    @property
    def max_latency(self) -> int:
        """Maximum communication latency `max_a tau_a` across all agents."""
        return max(self._latency_per_agent)

    def reset(self) -> None:
        """Clear buffered projection history."""
        self._history.clear()

    def record_and_deliver(
        self, step: int, emitted_projections: tuple[int, ...]
    ) -> tuple[tuple[int, ...], tuple[int, ...]]:
        """Record `emitted_projections` at `step` and return `(delivered_projections, effective_lags)`."""
        if len(emitted_projections) != self._num_agents:
            raise ValueError(
                f"Expected {self._num_agents} projections, got {len(emitted_projections)}"
            )
        if step != len(self._history):
            raise ValueError(
                f"AsynchronousMessageDelayBuffer step {step} out of sync with history length {len(self._history)}"
            )
        self._history.append(tuple(int(p) for p in emitted_projections))
        delivered: list[int] = []
        lags: list[int] = []
        for agent_idx, tau in enumerate(self._latency_per_agent):
            eff_lag = min(step, tau)
            source_step = step - eff_lag
            delivered.append(self._history[source_step][agent_idx])
            lags.append(eff_lag)
        return tuple(delivered), tuple(lags)


class NonMonotonicMessageChannel:
    """Causal message-delivery channel supporting packet loss and non-FIFO out-of-order permutations.

    At step `k >= 0`, each agent `a` emits a boundary projection `pi_a(M_k)` into the channel.
    Unlike a strictly monotonic FIFO delay buffer (`sigma_a(k) = k - min(k, tau_a)`), a general
    causal delivery schedule `sigma_a : Nat -> Nat` satisfies `0 <= sigma_a(k) <= k` and supports:
      1. **Packet loss (hold-last-delivered)**: If step `k` is in `dropped_steps_per_agent[a]`,
         the incoming update for step `k` is dropped and the receiver retains the previously
         delivered source step `sigma_a(k) = sigma_a(k - 1)` (or `0` at `k = 0`).
      2. **Non-FIFO out-of-order message permutation**: If step `k` is in
         `permutation_schedule_per_agent[a]`, the channel delivers `sigma_a(k) = perm[k]`
         (validated to satisfy causality `0 <= sigma_a(k) <= k`), allowing out-of-order
         inversions `sigma_a(k_2) < sigma_a(k_1)` for `k_1 < k_2`.
      3. **Baseline latency fallback**: Otherwise, `sigma_a(k) = k - min(k, tau_a)`.
    """

    def __init__(
        self,
        num_agents: int,
        latency_steps: int | Sequence[int] = 0,
        dropped_steps_per_agent: Mapping[int, Sequence[int] | set[int]] | Sequence[int] | set[int] | None = None,
        permutation_schedule_per_agent: Mapping[int, Mapping[int, int]] | Mapping[int, int] | None = None,
    ) -> None:
        if num_agents < 2:
            raise ValueError(f"num_agents must be >= 2, got {num_agents}")
        if isinstance(latency_steps, int):
            if latency_steps < 0:
                raise ValueError(f"latency_steps must be >= 0, got {latency_steps}")
            self._latency_per_agent: tuple[int, ...] = tuple(
                latency_steps for _ in range(num_agents)
            )
        else:
            if len(latency_steps) != num_agents:
                raise ValueError(
                    f"latency_steps sequence length {len(latency_steps)} != num_agents {num_agents}"
                )
            for idx, tau in enumerate(latency_steps):
                if tau < 0:
                    raise ValueError(f"latency_steps[{idx}] must be >= 0, got {tau}")
            self._latency_per_agent = tuple(int(tau) for tau in latency_steps)

        self._num_agents = num_agents

        # Normalize dropped_steps_per_agent: dict[int, frozenset[int]]
        dropped_map: dict[int, frozenset[int]] = {a: frozenset() for a in range(num_agents)}
        if dropped_steps_per_agent is not None:
            if isinstance(dropped_steps_per_agent, Mapping):
                for a_idx, steps in dropped_steps_per_agent.items():
                    if not (0 <= int(a_idx) < num_agents):
                        raise ValueError(f"Invalid agent index {a_idx} in dropped_steps_per_agent")
                    for s in steps:
                        if int(s) < 0:
                            raise ValueError(f"Dropped step must be >= 0, got {s}")
                    dropped_map[int(a_idx)] = frozenset(int(s) for s in steps)
            else:
                shared_drops = frozenset(int(s) for s in dropped_steps_per_agent)
                for s in shared_drops:
                    if s < 0:
                        raise ValueError(f"Dropped step must be >= 0, got {s}")
                for a_idx in range(num_agents):
                    dropped_map[a_idx] = shared_drops
        self._dropped_steps_per_agent = dropped_map

        # Normalize permutation_schedule_per_agent: dict[int, dict[int, int]]
        perm_map: dict[int, dict[int, int]] = {a: {} for a in range(num_agents)}
        if permutation_schedule_per_agent is not None:
            first_val = next(iter(permutation_schedule_per_agent.values()), None)
            if isinstance(first_val, Mapping):
                for a_idx, sched in permutation_schedule_per_agent.items():
                    if not (0 <= int(a_idx) < num_agents):
                        raise ValueError(
                            f"Invalid agent index {a_idx} in permutation_schedule_per_agent"
                        )
                    agent_sched: dict[int, int] = {}
                    for k_step, src_step in sched.items():  # type: ignore[union-attr]
                        k_int, src_int = int(k_step), int(src_step)
                        if k_int < 0 or not (0 <= src_int <= k_int):
                            raise ValueError(
                                f"Causal delivery violation for agent {a_idx} at step {k_int}: "
                                f"source step {src_int} must satisfy 0 <= sigma_a(k) <= k"
                            )
                        agent_sched[k_int] = src_int
                    perm_map[int(a_idx)] = agent_sched
            else:
                shared_sched: dict[int, int] = {}
                for k_step, src_step in permutation_schedule_per_agent.items():
                    k_int, src_int = int(k_step), int(src_step)  # type: ignore[arg-type]
                    if k_int < 0 or not (0 <= src_int <= k_int):
                        raise ValueError(
                            f"Causal delivery violation at step {k_int}: "
                            f"source step {src_int} must satisfy 0 <= sigma_a(k) <= k"
                        )
                    shared_sched[k_int] = src_int
                for a_idx in range(num_agents):
                    perm_map[a_idx] = dict(shared_sched)
        self._permutation_schedule_per_agent = perm_map

        self._history: list[tuple[int, ...]] = []
        self._delivered_source_history: list[tuple[int, ...]] = []
        self._non_monotonic_inversion_count: int = 0

    @property
    def latency_per_agent(self) -> tuple[int, ...]:
        """Configured baseline communication latency `(tau_0, ..., tau_{m-1})`."""
        return self._latency_per_agent

    @property
    def non_monotonic_inversion_count(self) -> int:
        """Cumulative count of non-monotonic delivery inversions (`sigma_a(k) < sigma_a(k-1)`) or packet-loss holds."""
        return self._non_monotonic_inversion_count

    @property
    def channel_mode(self) -> str:
        """Descriptive channel mode (`fifo`, `packet_loss`, `out_of_order`, or `packet_loss+out_of_order`)."""
        has_drops = any(bool(s) for s in self._dropped_steps_per_agent.values())
        has_perms = any(bool(p) for p in self._permutation_schedule_per_agent.values())
        if has_drops and has_perms:
            return "packet_loss+out_of_order"
        if has_drops:
            return "packet_loss"
        if has_perms:
            return "out_of_order"
        return "fifo"

    def reset(self) -> None:
        """Clear recorded projection and delivery histories."""
        self._history.clear()
        self._delivered_source_history.clear()
        self._non_monotonic_inversion_count = 0

    def record_and_deliver_detailed(
        self, step: int, emitted_projections: tuple[int, ...]
    ) -> tuple[tuple[int, ...], tuple[int, ...], tuple[int, ...], bool]:
        """Record `emitted_projections` at `step` and return `(delivered, effective_lags, source_steps, is_non_monotonic)`."""
        if len(emitted_projections) != self._num_agents:
            raise ValueError(
                f"Expected {self._num_agents} projections, got {len(emitted_projections)}"
            )
        if step != len(self._history):
            raise ValueError(
                f"NonMonotonicMessageChannel step {step} out of sync with history length {len(self._history)}"
            )
        self._history.append(tuple(int(p) for p in emitted_projections))

        delivered: list[int] = []
        lags: list[int] = []
        source_steps: list[int] = []
        step_non_monotonic = False

        for agent_idx, tau in enumerate(self._latency_per_agent):
            perm_sched = self._permutation_schedule_per_agent[agent_idx]
            dropped_set = self._dropped_steps_per_agent[agent_idx]

            if step in perm_sched:
                src_step = perm_sched[step]
            elif step in dropped_set:
                if step == 0:
                    src_step = 0
                else:
                    src_step = self._delivered_source_history[-1][agent_idx]
                if step > 0:
                    step_non_monotonic = True
            else:
                eff_lag = min(step, tau)
                src_step = step - eff_lag

            if not (0 <= src_step <= step):
                raise ValueError(
                    f"Causal violation for agent {agent_idx} at step {step}: source_step={src_step}"
                )

            if step > 0:
                prev_src = self._delivered_source_history[-1][agent_idx]
                if src_step < prev_src:
                    step_non_monotonic = True

            delivered.append(self._history[src_step][agent_idx])
            lags.append(step - src_step)
            source_steps.append(src_step)

        if step_non_monotonic:
            self._non_monotonic_inversion_count += 1
        self._delivered_source_history.append(tuple(source_steps))
        return tuple(delivered), tuple(lags), tuple(source_steps), step_non_monotonic

    def record_and_deliver(
        self, step: int, emitted_projections: tuple[int, ...]
    ) -> tuple[tuple[int, ...], tuple[int, ...]]:
        """Compatibility wrapper returning `(delivered_projections, effective_lags)`."""
        delivered, lags, _, _ = self.record_and_deliver_detailed(step, emitted_projections)
        return delivered, lags


class DynamicSimplicialRewiringSchedule:
    """Time-varying simplicial cochain complex schedule `(C^k(X_t) --d_t^k--> C^{k+1}(X_t))_{t >= 0}`.

    Models dynamic topological rewiring of the shared `(k+1)`-complex across steps `t`.
    All complexes `X_t` share the same cochain degree `k >= 1`, while the active `(k+1)`-cells
    can attach, detach, or cycle across vertex sets as `t` advances.
    """

    def __init__(
        self,
        default_complex: HigherCellComplex,
        complex_by_step: Mapping[int, HigherCellComplex] | None = None,
        cyclic_complexes: Sequence[HigherCellComplex] | None = None,
    ) -> None:
        self._degree = default_complex.degree
        self._default_complex = default_complex
        self._complex_by_step: dict[int, HigherCellComplex] = {}
        if complex_by_step is not None:
            for step_idx, cpx in complex_by_step.items():
                if int(step_idx) < 0:
                    raise ValueError(f"Step index in complex_by_step must be >= 0, got {step_idx}")
                if cpx.degree != self._degree:
                    raise ValueError(
                        f"Complex at step {step_idx} has degree {cpx.degree} != expected {self._degree}"
                    )
                self._complex_by_step[int(step_idx)] = cpx

        self._cyclic_complexes: tuple[HigherCellComplex, ...] = ()
        if cyclic_complexes is not None:
            if len(cyclic_complexes) < 1:
                raise ValueError("cyclic_complexes must not be empty when provided")
            for idx, cpx in enumerate(cyclic_complexes):
                if cpx.degree != self._degree:
                    raise ValueError(
                        f"cyclic_complexes[{idx}] has degree {cpx.degree} != expected {self._degree}"
                    )
            self._cyclic_complexes = tuple(cyclic_complexes)

    @classmethod
    def standard_rewiring_cycle(
        cls, degree: int, num_topologies: int = 2, cells_per_topology: int = 2
    ) -> "DynamicSimplicialRewiringSchedule":
        """Construct a deterministic cycle of distinct `(k+1)`-complex topologies of degree `k`."""
        if degree < 1:
            raise ValueError(f"degree must be >= 1, got {degree}")
        if num_topologies < 2:
            raise ValueError(f"num_topologies must be >= 2, got {num_topologies}")
        if cells_per_topology < 1:
            raise ValueError(f"cells_per_topology must be >= 1, got {cells_per_topology}")

        topologies: list[HigherCellComplex] = []
        base_verts = list(range(degree + 1))
        for topo_idx in range(num_topologies):
            cells: list[tuple[int, ...]] = []
            for c_idx in range(cells_per_topology):
                apex = degree + 1 + topo_idx * cells_per_topology + c_idx
                cells.append(tuple(base_verts + [apex]))
            topologies.append(HigherCellComplex(degree=degree, k_plus_1_cells=cells))
        return cls(default_complex=topologies[0], cyclic_complexes=topologies)

    @property
    def degree(self) -> int:
        """Cochain degree `k` shared across all time steps `t`."""
        return self._degree

    def complex_at(self, step: int) -> HigherCellComplex:
        """Return the active `HigherCellComplex` `X_t` at step `t = step`."""
        if step < 0:
            raise ValueError(f"step must be >= 0, got {step}")
        if step in self._complex_by_step:
            return self._complex_by_step[step]
        if self._cyclic_complexes:
            return self._cyclic_complexes[step % len(self._cyclic_complexes)]
        return self._default_complex

    def is_rewired_at(self, step: int) -> bool:
        """Return True if `X_step` has different `(k+1)`-cells from `X_{step-1}` (`step >= 1`)."""
        if step <= 0:
            return False
        return (
            self.complex_at(step).k_plus_1_cells
            != self.complex_at(step - 1).k_plus_1_cells
        )

    def all_required_k_cells(self, max_step: int = 32) -> set[tuple[int, ...]]:
        """Union of all `k`-faces across all topologies reachable up to `max_step`."""
        cells: set[tuple[int, ...]] = set(self._default_complex.required_k_cells())
        for cpx in self._complex_by_step.values():
            cells.update(cpx.required_k_cells())
        for cpx in self._cyclic_complexes:
            cells.update(cpx.required_k_cells())
        for t in range(max_step + 1):
            cells.update(self.complex_at(t).required_k_cells())
        return cells

    def all_required_k_minus_1_cells(self, max_step: int = 32) -> set[tuple[int, ...]]:
        """Union of all `(k-1)`-faces across all topologies reachable up to `max_step`."""
        cells: set[tuple[int, ...]] = set(self._default_complex.required_k_minus_1_cells())
        for cpx in self._complex_by_step.values():
            cells.update(cpx.required_k_minus_1_cells())
        for cpx in self._cyclic_complexes:
            cells.update(cpx.required_k_minus_1_cells())
        for t in range(max_step + 1):
            cells.update(self.complex_at(t).required_k_minus_1_cells())
        return cells


@dataclass(frozen=True)
class HigherCellAsyncState:
    """Joint multi-agent state at step `k` over a higher k-cell complex with asynchronous/non-monotonic latency and dynamic rewiring."""

    step: int
    agent_states: tuple[int, ...]
    emitted_projections: tuple[int, ...]
    delivered_projections: tuple[int, ...]
    effective_lags: tuple[int, ...]
    remaining_budget: int
    k_cochain: dict[tuple[int, ...], Fraction]
    delivered_source_steps: tuple[int, ...] = ()
    active_k_plus_1_cells: tuple[tuple[int, ...], ...] = ()
    is_non_monotonic_delivery: bool = False
    is_topology_rewired: bool = False


@dataclass(frozen=True)
class HigherCellObstructionReceipt:
    """Deterministic refusal receipt emitted by a `HigherCellAsyncCommunicatingHypergraph`."""

    halted: bool
    obstruction_kind: str
    termination_step: int
    cochain_degree: int
    latency_steps: tuple[int, ...]
    agent_capacities: tuple[int, ...]
    product_carrier_capacity: int
    horizon_bound: int
    single_agent_max_capacity: int
    delayed_beyond_single_agent: bool
    colliding_prior_step: int | None
    colliding_joint_report: tuple[int, ...] | None
    remaining_budget: int
    phi1_holonomy: Fraction
    async_exchange_trace: list[dict[str, object]]
    eis_vector: dict[str, object]
    eis_independence_verdict: dict[str, object]
    non_monotonic_inversions: int = 0
    topology_rewiring_events: int = 0
    channel_mode: str = "fifo"

    @property
    def carrier_capacity(self) -> int:
        """Compatibility property returning `product_carrier_capacity` for EIS cross-check."""
        return self.product_carrier_capacity

    def to_json_dict(self) -> dict[str, object]:
        """Serialize receipt to a deterministic JSON-compatible dictionary."""
        return {
            "halted": self.halted,
            "obstruction_kind": self.obstruction_kind,
            "termination_step": self.termination_step,
            "cochain_degree": self.cochain_degree,
            "latency_steps": list(self.latency_steps),
            "agent_capacities": list(self.agent_capacities),
            "product_carrier_capacity": self.product_carrier_capacity,
            "horizon_bound": self.horizon_bound,
            "single_agent_max_capacity": self.single_agent_max_capacity,
            "delayed_beyond_single_agent": self.delayed_beyond_single_agent,
            "colliding_prior_step": self.colliding_prior_step,
            "colliding_joint_report": (
                list(self.colliding_joint_report)
                if self.colliding_joint_report is not None
                else None
            ),
            "remaining_budget": self.remaining_budget,
            "phi1_holonomy": f"{self.phi1_holonomy.numerator}/{self.phi1_holonomy.denominator}",
            "non_monotonic_inversions": self.non_monotonic_inversions,
            "topology_rewiring_events": self.topology_rewiring_events,
            "channel_mode": self.channel_mode,
            "async_exchange_trace": self.async_exchange_trace,
            "eis_vector": self.eis_vector,
            "eis_independence_verdict": self.eis_independence_verdict,
        }


class HigherCellAsyncCommunicatingHypergraph:
    """Multi-agent communicating hypergraph over `C^k --d^k--> C^{k+1}` with asynchronous, non-monotonic, and dynamically rewired topologies.

    Extends `MultiAgentCommunicatingHypergraph` from shared 2-complexes (`C^1 --d^1--> C^2`) to
    arbitrary degree `k >= 1` cochain complexes (`C^k(X_t) --d_t^k--> C^{k+1}(X_t)`) coupled with:
      1. `AsynchronousMessageDelayBuffer` (monotonic FIFO latency `tau >= 0`),
      2. `NonMonotonicMessageChannel` (packet-loss hold-last-delivered and non-FIFO out-of-order
         message permutations `0 <= sigma_a(k) <= k`), and
      3. `DynamicSimplicialRewiringSchedule` (time-varying `(k+1)`-complexes `X_t`).

    Tests whether bounded communication latency, non-monotonic message delivery, and dynamic
    simplicial topology rewiring alter the termination step `k* <= N_A * N_B + 1` or shift the
    distribution of `OVERLAP_GLUING_REFUSAL` (`Phi_1([delta^{(k)}]) > 0`) vs. `REPORT_COLLISION`
    (`Pi(M_k) = Pi(M_j)`).
    """

    def __init__(
        self,
        agent_capacities: Sequence[int],
        higher_complex: HigherCellComplex,
        latency_steps: int | Sequence[int],
        initial_agent_states: Sequence[int],
        initial_budget: int,
        initial_k_cochain: Mapping[tuple[int, ...], Fraction],
        step_fn: Callable[
            [HigherCellAsyncState],
            tuple[tuple[int, ...], Mapping[tuple[int, ...], Fraction]],
        ],
        boundary_maps: Sequence[Callable[[int], int]] | None = None,
        detector_id: str = "detector.higher_cell_async_rsi_scanner",
        signal2_observer_id: str = "host.higher_cell_async_obstruction_gate",
        message_channel: NonMonotonicMessageChannel | None = None,
        rewiring_schedule: DynamicSimplicialRewiringSchedule | None = None,
    ) -> None:
        if len(agent_capacities) < 2:
            raise ValueError(
                f"HigherCellAsyncCommunicatingHypergraph requires >= 2 agents, got {len(agent_capacities)}"
            )
        for idx, cap in enumerate(agent_capacities):
            if cap < 1:
                raise ValueError(f"Agent {idx} capacity must be >= 1, got {cap}")
        if len(initial_agent_states) != len(agent_capacities):
            raise ValueError("initial_agent_states length must match agent_capacities length")
        if initial_budget < 0:
            raise ValueError(f"initial_budget must be >= 0, got {initial_budget}")

        self.agent_capacities: tuple[int, ...] = tuple(int(c) for c in agent_capacities)
        self.higher_complex = higher_complex
        if rewiring_schedule is not None and rewiring_schedule.degree != higher_complex.degree:
            raise ValueError(
                f"rewiring_schedule degree {rewiring_schedule.degree} != higher_complex degree {higher_complex.degree}"
            )
        self.rewiring_schedule = rewiring_schedule
        self.delay_buffer = AsynchronousMessageDelayBuffer(
            num_agents=len(self.agent_capacities),
            latency_steps=latency_steps,
        )
        self.message_channel = message_channel
        self.initial_agent_states: tuple[int, ...] = tuple(
            int(s) % cap for s, cap in zip(initial_agent_states, self.agent_capacities)
        )
        self.initial_budget = int(initial_budget)
        self.initial_k_cochain: dict[tuple[int, ...], Fraction] = {
            cell: Fraction(val) for cell, val in initial_k_cochain.items()
        }
        self.step_fn = step_fn
        if boundary_maps is None:
            self.boundary_maps: tuple[Callable[[int], int], ...] = tuple(
                (lambda s, cap=cap: s % cap) for cap in self.agent_capacities
            )
        else:
            if len(boundary_maps) != len(self.agent_capacities):
                raise ValueError("boundary_maps length must match agent_capacities length")
            self.boundary_maps = tuple(boundary_maps)
        self.detector_id = detector_id
        self.signal2_observer_id = signal2_observer_id

    @property
    def product_carrier_capacity(self) -> int:
        """Joint product-carrier capacity `prod_i N_i` (e.g. `N_A * N_B`)."""
        return math.prod(self.agent_capacities)

    @property
    def horizon_bound(self) -> int:
        """Maximum admissible step count `prod_i N_i + 1`."""
        return self.product_carrier_capacity + 1

    @property
    def single_agent_max_capacity(self) -> int:
        """Maximum individual agent carrier capacity `max_i N_i`."""
        return max(self.agent_capacities)

    def _project_joint_boundary(self, agent_states: tuple[int, ...]) -> tuple[int, ...]:
        """Compute authoritative joint boundary report `(pi_0(s_0), ..., pi_{m-1}(s_{m-1}))`."""
        return tuple(
            int(proj_fn(state)) % cap
            for proj_fn, state, cap in zip(
                self.boundary_maps, agent_states, self.agent_capacities
            )
        )

    def _active_complex_at(self, step: int) -> HigherCellComplex:
        """Return the active `(k+1)`-complex at `step`."""
        if self.rewiring_schedule is not None:
            return self.rewiring_schedule.complex_at(step)
        return self.higher_complex

    def run(self) -> HigherCellObstructionReceipt:
        """Execute the higher k-cell hypergraph until the first obstruction at `k* <= prod_i N_i + 1`."""
        if self.message_channel is not None:
            self.message_channel.reset()
        else:
            self.delay_buffer.reset()
        seen_joint_reports: dict[tuple[int, ...], int] = {}
        exchange_log: list[dict[str, object]] = []

        agent_states = self.initial_agent_states
        budget = self.initial_budget
        k_cochain = dict(self.initial_k_cochain)
        rewiring_events = 0

        for step in range(self.horizon_bound + 1):
            emitted_report = self._project_joint_boundary(agent_states)
            if self.message_channel is not None:
                (
                    delivered_report,
                    effective_lags,
                    source_steps,
                    is_non_monotonic,
                ) = self.message_channel.record_and_deliver_detailed(step, emitted_report)
            else:
                delivered_report, effective_lags = self.delay_buffer.record_and_deliver(
                    step, emitted_report
                )
                source_steps = tuple(step - lag for lag in effective_lags)
                is_non_monotonic = False

            active_complex = self._active_complex_at(step)
            is_rewired = (
                self.rewiring_schedule.is_rewired_at(step)
                if self.rewiring_schedule is not None
                else False
            )
            if is_rewired:
                rewiring_events += 1

            # Ensure all required k-cells of the active complex exist in k_cochain (defaulting missing newly attached faces to 0)
            for req_face in active_complex.required_k_cells():
                if req_face not in k_cochain:
                    k_cochain[req_face] = Fraction(0, 1)

            phi1_val = compute_higher_cell_phi1_holonomy(active_complex, k_cochain)

            exchange_log.append(
                {
                    "step": step,
                    "cochain_degree": active_complex.degree,
                    "active_k_plus_1_cells": [list(c) for c in active_complex.k_plus_1_cells],
                    "is_topology_rewired": is_rewired,
                    "agent_states": list(agent_states),
                    "emitted_boundary_projections": list(emitted_report),
                    "delivered_boundary_projections": list(delivered_report),
                    "delivered_source_steps": list(source_steps),
                    "effective_lags": list(effective_lags),
                    "is_non_monotonic_delivery": is_non_monotonic,
                    "remaining_budget": budget,
                    "phi1_holonomy": f"{phi1_val.numerator}/{phi1_val.denominator}",
                }
            )

            # 1. Check higher k-cell overlap gluing compatibility (Phi_1([delta^{(k)}]) > 0)
            if phi1_val > Fraction(0, 1):
                return self._emit_receipt(
                    obstruction_kind="OVERLAP_GLUING_REFUSAL",
                    danger_type="PROTECTED_FIELD_VIOLATION",
                    step=step,
                    colliding_prior_step=None,
                    colliding_joint_report=None,
                    remaining_budget=budget,
                    phi1_holonomy=phi1_val,
                    exchange_log=exchange_log,
                    pattern_matched=(
                        f"higher_cell_c{active_complex.degree}_step_{step}_gluing_refusal"
                    ),
                    rewiring_events=rewiring_events,
                )

            # 2. Check authoritative joint boundary report collision (Pi(M_k) = Pi(M_j) for j < k)
            if emitted_report in seen_joint_reports:
                prior_step = seen_joint_reports[emitted_report]
                return self._emit_receipt(
                    obstruction_kind="REPORT_COLLISION",
                    danger_type="REPLAY_FAILURE",
                    step=step,
                    colliding_prior_step=prior_step,
                    colliding_joint_report=emitted_report,
                    remaining_budget=budget,
                    phi1_holonomy=phi1_val,
                    exchange_log=exchange_log,
                    pattern_matched=(
                        f"higher_cell_c{active_complex.degree}_step_{step}_collision_with_{prior_step}"
                    ),
                    rewiring_events=rewiring_events,
                )
            seen_joint_reports[emitted_report] = step

            # 3. Check joint lift-budget exhaustion (budget = 0)
            if budget == 0:
                return self._emit_receipt(
                    obstruction_kind="LIFT_BUDGET_EXHAUSTION",
                    danger_type="MANIFEST_CONTAMINATION",
                    step=step,
                    colliding_prior_step=None,
                    colliding_joint_report=None,
                    remaining_budget=0,
                    phi1_holonomy=phi1_val,
                    exchange_log=exchange_log,
                    pattern_matched=(
                        f"higher_cell_c{active_complex.degree}_step_{step}_budget_exhaustion"
                    ),
                    rewiring_events=rewiring_events,
                )

            current_state = HigherCellAsyncState(
                step=step,
                agent_states=agent_states,
                emitted_projections=emitted_report,
                delivered_projections=delivered_report,
                effective_lags=effective_lags,
                remaining_budget=budget,
                k_cochain=k_cochain,
                delivered_source_steps=source_steps,
                active_k_plus_1_cells=active_complex.k_plus_1_cells,
                is_non_monotonic_delivery=is_non_monotonic,
                is_topology_rewired=is_rewired,
            )
            next_states, next_cochain = self.step_fn(current_state)
            if len(next_states) != len(self.agent_capacities):
                raise ValueError(
                    f"step_fn returned {len(next_states)} states, expected {len(self.agent_capacities)}"
                )
            agent_states = tuple(
                int(s) % cap for s, cap in zip(next_states, self.agent_capacities)
            )
            budget -= 1
            k_cochain = {cell: Fraction(val) for cell, val in next_cochain.items()}

        raise RuntimeError(
            "Unreachable: joint pigeonhole bound forces collision or budget exhaustion within prod_i N_i + 1 steps"
        )

    def _emit_receipt(
        self,
        obstruction_kind: str,
        danger_type: str,
        step: int,
        colliding_prior_step: int | None,
        colliding_joint_report: tuple[int, ...] | None,
        remaining_budget: int,
        phi1_holonomy: Fraction,
        exchange_log: list[dict[str, object]],
        pattern_matched: str,
        rewiring_events: int = 0,
    ) -> HigherCellObstructionReceipt:
        assert 0 <= step <= self.horizon_bound, (
            f"Higher-cell async termination step {step} exceeded N_A * N_B + 1 = {self.horizon_bound}"
        )
        matches: list[dict[str, object]] = [
            {
                "epitope_name": f"rsi.higher_cell_c{self.higher_complex.degree}.{obstruction_kind.lower()}",
                "pattern_matched": pattern_matched,
                "offset": 0,
            }
        ]
        caps_str = "x".join(str(c) for c in self.agent_capacities)
        active_latencies = (
            self.message_channel.latency_per_agent
            if self.message_channel is not None
            else self.delay_buffer.latency_per_agent
        )
        non_mono_inversions = (
            self.message_channel.non_monotonic_inversion_count
            if self.message_channel is not None
            else 0
        )
        base_mode = (
            self.message_channel.channel_mode if self.message_channel is not None else "fifo"
        )
        channel_mode = (
            f"{base_mode}+rewired" if self.rewiring_schedule is not None else base_mode
        )
        lags_str = ",".join(str(tau) for tau in active_latencies)
        evidence_payload = (
            f"higher_cell_obstruction={obstruction_kind};degree={self.higher_complex.degree};"
            f"mode={channel_mode};tau={lags_str};step={step};caps={caps_str};"
            f"N_prod={self.product_carrier_capacity};prior={colliding_prior_step};"
            f"budget={remaining_budget};inversions={non_mono_inversions};"
            f"rewirings={rewiring_events};"
            f"phi1={phi1_holonomy.numerator}/{phi1_holonomy.denominator}"
        ).encode("utf-8")
        evidence_digest = "sha256:" + hashlib.sha256(evidence_payload).hexdigest()

        danger: dict[str, object] = {
            "danger_type": danger_type,
            "observer_id": self.signal2_observer_id,
            "evidence_digest": evidence_digest,
            "defect_count": 1,
            "evidence_spans": [[128, 192]],
        }
        context: dict[str, object] = {
            "detector_id": self.detector_id,
            "detector_predicates": ["UNREGISTERED_SELF_PROXY"],
            "offsets_are_content": True,
        }
        eis_vector: dict[str, object] = {
            "matches": matches,
            "danger": danger,
            "context": context,
            "signal1_digest": compute_signal1_digest(matches),
            "agent_capacities": list(self.agent_capacities),
        }
        verdict = verify_signal_independence(matches, danger, context)
        return HigherCellObstructionReceipt(
            halted=True,
            obstruction_kind=obstruction_kind,
            termination_step=step,
            cochain_degree=self.higher_complex.degree,
            latency_steps=active_latencies,
            agent_capacities=self.agent_capacities,
            product_carrier_capacity=self.product_carrier_capacity,
            horizon_bound=self.horizon_bound,
            single_agent_max_capacity=self.single_agent_max_capacity,
            delayed_beyond_single_agent=(step > self.single_agent_max_capacity),
            colliding_prior_step=colliding_prior_step,
            colliding_joint_report=colliding_joint_report,
            remaining_budget=remaining_budget,
            phi1_holonomy=phi1_val if (phi1_val := phi1_holonomy) is not None else Fraction(0, 1),
            async_exchange_trace=exchange_log,
            eis_vector=eis_vector,
            eis_independence_verdict=verdict,
            non_monotonic_inversions=non_mono_inversions,
            topology_rewiring_events=rewiring_events,
            channel_mode=channel_mode,
        )


def make_async_delay_compensated_step_fn(
    agent_capacities: Sequence[int],
    higher_complex: HigherCellComplex,
) -> Callable[
    [HigherCellAsyncState],
    tuple[tuple[int, ...], dict[tuple[int, ...], Fraction]],
]:
    """Build a delay-compensated co-adaptation step function on `C^k --d^k--> C^{k+1}`.

    - Agents update their local states using the *delayed* boundary projections
      `delivered_projections = (hat{pi}_A(k), hat{pi}_B(k), ...)` received from the
      `AsynchronousMessageDelayBuffer`:
      - Agent 0 advances at every step: `s_0' = (s_0 + 1) mod N_0`.
      - Agent `i > 0` increments when the delayed lower-agent projections `hat{pi}_0(k), ..., hat{pi}_{i-1}(k)`
        all wrap at their maximal residues `N_j - 1`, plus a latency-sensitive phase shift when
        `effective_lags[i-1] > 0` and `hat{pi}_{i-1}(k) == (N_{i-1} - 1 - effective_lags[i-1]) % N_{i-1}`.
    - Both agents construct the next `k`-cochain `delta^{(k)} = d^{k-1} eta^{(k-1)}` from the shared
      delayed potential `eta^{(k-1)}` so that `d^k delta^{(k)} = 0` (`Phi_1([delta^{(k)}]) = 0`).
    - Consequently, varying the communication latency `tau` alters the exact trajectory and shifts
      the step `k*(tau)` at which `REPORT_COLLISION` occurs, while strictly obeying `k*(tau) <= prod_i N_i + 1`.
    """
    caps = tuple(int(c) for c in agent_capacities)
    prod_cap = math.prod(caps)
    sorted_km1_cells = sorted(higher_complex.required_k_minus_1_cells())

    def _step(
        state: HigherCellAsyncState,
    ) -> tuple[tuple[int, ...], dict[tuple[int, ...], Fraction]]:
        next_list = list(state.agent_states)
        delivered = state.delivered_projections
        lags = state.effective_lags

        # Agent 0 always steps forward
        next_list[0] = (state.agent_states[0] + 1) % caps[0]

        for idx in range(1, len(caps)):
            # Carry trigger driven by the delayed projection received across the buffer
            prev_delivered = delivered[idx - 1]
            prev_lag = lags[idx - 1]
            if prev_lag == 0:
                carry = all(delivered[j] == caps[j] - 1 for j in range(idx))
                stride = 1 if carry else 0
            else:
                # Under non-zero communication lag tau > 0, delayed feedback couples current and lagged residues
                trigger_residue = (caps[idx - 1] - 1) % caps[idx - 1]
                secondary_residue = (caps[idx - 1] - 1 - (prev_lag % caps[idx - 1])) % caps[idx - 1]
                if prev_delivered == trigger_residue:
                    stride = 1
                elif prev_delivered == secondary_residue and state.step >= prev_lag:
                    stride = 2 if caps[idx] > 2 else 1
                else:
                    stride = 0
            next_list[idx] = (state.agent_states[idx] + stride) % caps[idx]

        # Build an exact k-cochain delta^{(k)} = d^{k-1} eta^{(k-1)} from the delayed common-knowledge buffer
        delayed_sum = sum(delivered)
        potential: dict[tuple[int, ...], Fraction] = {}
        for cell_idx, km1_cell in enumerate(sorted_km1_cells):
            potential[km1_cell] = Fraction((delayed_sum + cell_idx + 1), prod_cap)
        exact_k_cochain = build_exact_k_cochain_from_potential(higher_complex, potential)
        return tuple(next_list), exact_k_cochain

    return _step


def make_async_uncompensated_stale_cochain_step_fn(
    agent_capacities: Sequence[int],
    higher_complex: HigherCellComplex,
    defect_trigger_step: int = 1,
) -> Callable[
    [HigherCellAsyncState],
    tuple[tuple[int, ...], dict[tuple[int, ...], Fraction]],
]:
    """Build an uncompensated asynchronous higher-cochain step function on `C^k --d^k--> C^{k+1}`.

    - Agents evolve via mixed-radix odometer transitions (`s_0' = (s_0 + 1) mod N_0`, etc.).
    - On the shared higher complex `C^k --d^k--> C^{k+1}`, all boundary `k`-faces of the primary
      `(k+1)`-simplex `sigma_0 = (v_0, ..., v_{k+1})` are initialized from an exact potential
      `d^{k-1} eta^{(k-1)}`, EXCEPT the closing face `face_0 = (v_1, ..., v_{k+1})`, where
      Agent A writes using the *delayed* projection `delivered_projections[0]` while Agent B
      evaluates compatibility against the *current* emitted projection `emitted_projections[0]`.
    - When `latency_steps == 0`, `delivered_projections == emitted_projections` at every step,
      so `Phi_1([delta^{(k)}]) == 0` everywhere and the system runs to `REPORT_COLLISION` at
      `k*(0) = prod_i N_i`.
    - When `latency_steps >= 1`, once `step + 1 >= defect_trigger_step`, the lag mismatch
      `|emitted_projections[0] - delivered_projections[0]| > 0` induces a non-zero coboundary defect
      `(d^k delta^{(k)})(sigma_0) != 0` (`Phi_1([delta^{(k)}]) > 0`), halting with
      `OVERLAP_GLUING_REFUSAL` at step `k*(tau) <= prod_i N_i + 1`.
    """
    if defect_trigger_step < 1:
        raise ValueError(f"defect_trigger_step must be >= 1, got {defect_trigger_step}")
    caps = tuple(int(c) for c in agent_capacities)
    prod_cap = math.prod(caps)
    sorted_km1_cells = sorted(higher_complex.required_k_minus_1_cells())
    primary_cell = higher_complex.k_plus_1_cells[0]
    closing_face = HigherCellComplex.boundary_faces_of_simplex(primary_cell)[0][1]

    def _step(
        state: HigherCellAsyncState,
    ) -> tuple[tuple[int, ...], dict[tuple[int, ...], Fraction]]:
        next_list = list(state.agent_states)
        carry = True
        for idx, cap in enumerate(caps):
            if carry:
                next_val = (state.agent_states[idx] + 1) % cap
                carry = next_val == 0
                next_list[idx] = next_val
            else:
                next_list[idx] = state.agent_states[idx]

        potential: dict[tuple[int, ...], Fraction] = {}
        for cell_idx, km1_cell in enumerate(sorted_km1_cells):
            potential[km1_cell] = Fraction((state.step + cell_idx + 1), prod_cap)
        k_cochain = build_exact_k_cochain_from_potential(higher_complex, potential)

        next_step = state.step + 1
        lag_mismatch = abs(state.emitted_projections[0] - state.delivered_projections[0])
        if max(state.effective_lags) > 0 and lag_mismatch == 0 and next_step >= defect_trigger_step:
            # Even if modular wrap temporarily coincides, positive effective lag on a moving carrier
            # induces stale-section mismatch proportional to the effective lag.
            lag_mismatch = max(state.effective_lags)

        if next_step >= defect_trigger_step and lag_mismatch > 0:
            k_cochain[closing_face] = k_cochain[closing_face] + Fraction(lag_mismatch, prod_cap)

        return tuple(next_list), k_cochain

    return _step


def make_non_monotonic_rewiring_step_fn(
    agent_capacities: Sequence[int],
    default_complex: HigherCellComplex,
    rewiring_schedule: DynamicSimplicialRewiringSchedule | None = None,
    compensate_rewiring_under_monotonic: bool = False,
) -> Callable[
    [HigherCellAsyncState],
    tuple[tuple[int, ...], dict[tuple[int, ...], Fraction]],
]:
    """Build a co-adaptation step function sensitive to non-monotonic delivery and dynamic simplicial rewiring.

    Mathematical mechanism:
    - Agents evolve their local state coordinates using delivered boundary projections:
      - Under monotonic FIFO delivery (`is_non_monotonic_delivery == False`), the agents advance
        via a delay-compensated odometer over `prod_i N_i`.
      - When a packet drop or out-of-order message permutation (`is_non_monotonic_delivery == True`)
        occurs, or when `delivered_source_steps` are asymmetric across agents
        (`sigma_0(k) != sigma_1(k)`), Agent A updates boundary `k`-faces of the next complex
        `X_{k+1}` using potential `eta_A` anchored to `sigma_0(k)` while Agent B updates closing
        `k`-faces using potential `eta_B` anchored to `sigma_1(k)` (or to the inverted step defect).
    - Similarly, when `rewiring_schedule` rewires the topology at step `k + 1`
      (`X_{k+1} != X_k`) and `compensate_rewiring_under_monotonic == False`, newly attached
      `(k+1)`-simplices retain legacy `k`-face values on shared lower faces while receiving updated
      potentials on newly attached apex faces, inducing non-zero coboundary holonomy
      `(d_{k+1}^k delta_{k+1}^{(k)})(sigma) != 0` (`Phi_1([delta_{k+1}^{(k)}]) > 0`).
    - Conversely, under monotonic symmetric FIFO delivery on a static (or compensated) complex,
      `Phi_1([delta^{(k)}]) = 0` holds at every step, so the trajectory terminates strictly by
      `REPORT_COLLISION` at `k* <= prod_i N_i`.
    """
    caps = tuple(int(c) for c in agent_capacities)
    prod_cap = math.prod(caps)

    def _step(
        state: HigherCellAsyncState,
    ) -> tuple[tuple[int, ...], dict[tuple[int, ...], Fraction]]:
        next_step = state.step + 1
        delivered = state.delivered_projections
        lags = state.effective_lags

        next_list = list(state.agent_states)
        next_list[0] = (state.agent_states[0] + 1) % caps[0]
        for idx in range(1, len(caps)):
            prev_delivered = delivered[idx - 1]
            prev_lag = lags[idx - 1]
            if prev_lag == 0:
                carry = all(delivered[j] == caps[j] - 1 for j in range(idx))
                stride = 1 if carry else 0
            else:
                trigger_residue = (caps[idx - 1] - 1) % caps[idx - 1]
                secondary_residue = (
                    caps[idx - 1] - 1 - (prev_lag % caps[idx - 1])
                ) % caps[idx - 1]
                if prev_delivered == trigger_residue:
                    stride = 1
                elif prev_delivered == secondary_residue and state.step >= prev_lag:
                    stride = 2 if caps[idx] > 2 else 1
                else:
                    stride = 0
            next_list[idx] = (state.agent_states[idx] + stride) % caps[idx]

        current_complex = (
            rewiring_schedule.complex_at(state.step)
            if rewiring_schedule is not None
            else default_complex
        )
        next_complex = (
            rewiring_schedule.complex_at(next_step)
            if rewiring_schedule is not None
            else default_complex
        )
        will_rewire = next_complex.k_plus_1_cells != current_complex.k_plus_1_cells

        sorted_km1_cells = sorted(
            next_complex.required_k_minus_1_cells()
            | current_complex.required_k_minus_1_cells()
        )
        base_seed = sum(delivered) + next_step
        potential: dict[tuple[int, ...], Fraction] = {
            km1_cell: Fraction(base_seed + idx + 1, prod_cap)
            for idx, km1_cell in enumerate(sorted_km1_cells)
        }
        k_cochain = build_exact_k_cochain_from_potential(next_complex, potential)

        # Detect non-monotonic channel inversion or asymmetric source-step skew across agents
        source_steps = state.delivered_source_steps
        source_skew = (
            max(source_steps) - min(source_steps) if len(source_steps) >= 2 else 0
        )
        non_monotonic_defect = 0
        if state.is_non_monotonic_delivery:
            non_monotonic_defect += max(1, source_skew + max(lags, default=1))
        elif source_skew > 0:
            non_monotonic_defect += source_skew

        # Detect uncompensated dynamic simplicial topology rewiring defect
        rewiring_defect = 1 if (will_rewire and not compensate_rewiring_under_monotonic) else 0

        total_defect = non_monotonic_defect + rewiring_defect
        if total_defect > 0:
            target_simplex = next_complex.k_plus_1_cells[-1]
            closing_face = HigherCellComplex.boundary_faces_of_simplex(target_simplex)[0][1]
            k_cochain[closing_face] = k_cochain.get(closing_face, Fraction(0, 1)) + Fraction(
                total_defect, prod_cap
            )

        return tuple(next_list), k_cochain

    return _step


def evaluate_termination_distribution_under_non_monotonic_rewiring(
    agent_capacities: Sequence[int] = (3, 4),
    cochain_degree: int = 2,
    initial_budget: int = 20,
) -> dict[str, object]:
    """Quantify how packet-loss, non-FIFO out-of-order message permutation, and dynamic simplicial rewiring shift termination outcomes.

    Evaluates four regimes over `C^k(X_t) --d_t^k--> C^{k+1}(X_t)` within `k* <= N_A * N_B + 1`:
      1. `monotonic_fifo_static`: Monotonic symmetric FIFO channels (`tau in {0, 1, 2, 3}`) on a
         static complex `X_0`. Preserves `Phi_1([delta^{(k)}]) = 0`, yielding 100% `REPORT_COLLISION`.
      2. `packet_loss_static`: Channels with dropped updates (`dropped_steps_per_agent`) on `X_0`.
         Dropped updates induce stale-face coboundary mismatch `Phi_1([delta^{(k)}]) > 0`,
         shifting termination to `OVERLAP_GLUING_REFUSAL`.
      3. `out_of_order_permutation_static`: Non-FIFO out-of-order message permutation schedules
         (`sigma_a(k_2) < sigma_a(k_1)` for `k_1 < k_2`) on `X_0`. Out-of-order inversions shift
         termination to `OVERLAP_GLUING_REFUSAL` at the exact inversion step.
      4. `dynamic_simplicial_rewiring`: Time-varying `(k+1)`-complex schedules `X_t` combined with
         both monotonic FIFO and non-monotonic channels, comparing uncompensated vs. compensated
         simplicial rewiring.

    All emitted `HigherCellObstructionReceipt` instances are cross-checked against the Rust
    `omega_epistemic_immune_system` companion binary.
    """
    caps = tuple(int(c) for c in agent_capacities)
    prod_cap = math.prod(caps)
    horizon_bound = prod_cap + 1
    static_complex = HigherCellComplex.standard_simplex(degree=cochain_degree, num_cells=2)
    rewiring_schedule = DynamicSimplicialRewiringSchedule.standard_rewiring_cycle(
        degree=cochain_degree, num_topologies=3, cells_per_topology=2
    )
    zero_k_cochain = {
        face: Fraction(0, 1) for face in rewiring_schedule.all_required_k_cells(max_step=horizon_bound + 2)
    }
    init_states = tuple(0 for _ in caps)

    all_receipts: list[HigherCellObstructionReceipt] = []
    regime_summaries: dict[str, dict[str, object]] = {}

    def _summarize_regime(name: str, receipts: Sequence[HigherCellObstructionReceipt]) -> dict[str, object]:
        counts: dict[str, int] = {
            "OVERLAP_GLUING_REFUSAL": 0,
            "REPORT_COLLISION": 0,
            "LIFT_BUDGET_EXHAUSTION": 0,
        }
        steps: list[int] = []
        for r in receipts:
            counts[r.obstruction_kind] = counts.get(r.obstruction_kind, 0) + 1
            steps.append(r.termination_step)
            if not (0 <= r.termination_step <= horizon_bound):
                raise AssertionError(
                    f"Regime {name} receipt step {r.termination_step} exceeded horizon {horizon_bound}"
                )
        total = len(receipts)
        return {
            "total_runs": total,
            "counts": counts,
            "gluing_refusal_fraction": f"{counts['OVERLAP_GLUING_REFUSAL']}/{total}",
            "report_collision_fraction": f"{counts['REPORT_COLLISION']}/{total}",
            "termination_steps": steps,
            "min_step": min(steps) if steps else 0,
            "max_step": max(steps) if steps else 0,
            "all_within_product_horizon": all(0 <= s <= horizon_bound for s in steps),
        }

    # Regime 1: Monotonic symmetric FIFO channels on static complex (tau = 0, 1, 2, 3)
    fifo_receipts: list[HigherCellObstructionReceipt] = []
    for tau in (0, 1, 2, 3):
        ch = NonMonotonicMessageChannel(num_agents=len(caps), latency_steps=tau)
        hg = HigherCellAsyncCommunicatingHypergraph(
            agent_capacities=caps,
            higher_complex=static_complex,
            latency_steps=tau,
            initial_agent_states=init_states,
            initial_budget=initial_budget,
            initial_k_cochain=zero_k_cochain,
            step_fn=make_non_monotonic_rewiring_step_fn(caps, static_complex),
            message_channel=ch,
        )
        r = hg.run()
        fifo_receipts.append(r)
        all_receipts.append(r)
    regime_summaries["monotonic_fifo_static"] = _summarize_regime(
        "monotonic_fifo_static", fifo_receipts
    )

    # Regime 2: Packet-loss channels on static complex (dropping at step d in {1, 2, 3, 4})
    loss_receipts: list[HigherCellObstructionReceipt] = []
    for drop_step in (1, 2, 3, 4):
        ch = NonMonotonicMessageChannel(
            num_agents=len(caps),
            latency_steps=0,
            dropped_steps_per_agent={0: {drop_step}},
        )
        hg = HigherCellAsyncCommunicatingHypergraph(
            agent_capacities=caps,
            higher_complex=static_complex,
            latency_steps=0,
            initial_agent_states=init_states,
            initial_budget=initial_budget,
            initial_k_cochain=zero_k_cochain,
            step_fn=make_non_monotonic_rewiring_step_fn(caps, static_complex),
            message_channel=ch,
        )
        r = hg.run()
        loss_receipts.append(r)
        all_receipts.append(r)
    regime_summaries["packet_loss_static"] = _summarize_regime(
        "packet_loss_static", loss_receipts
    )

    # Regime 3: Non-FIFO out-of-order message permutation channels on static complex
    perm_receipts: list[HigherCellObstructionReceipt] = []
    for inv_step in (2, 3, 4, 5):
        # At step inv_step, agent 0 receives out-of-order older packet (inv_step - 2) after having received (inv_step - 1)
        perm_sched = {0: {inv_step - 1: inv_step - 1, inv_step: inv_step - 2}}
        ch = NonMonotonicMessageChannel(
            num_agents=len(caps),
            latency_steps=0,
            permutation_schedule_per_agent=perm_sched,
        )
        hg = HigherCellAsyncCommunicatingHypergraph(
            agent_capacities=caps,
            higher_complex=static_complex,
            latency_steps=0,
            initial_agent_states=init_states,
            initial_budget=initial_budget,
            initial_k_cochain=zero_k_cochain,
            step_fn=make_non_monotonic_rewiring_step_fn(caps, static_complex),
            message_channel=ch,
        )
        r = hg.run()
        perm_receipts.append(r)
        all_receipts.append(r)
    regime_summaries["out_of_order_permutation_static"] = _summarize_regime(
        "out_of_order_permutation_static", perm_receipts
    )

    # Regime 4: Dynamic simplicial topology rewiring across C^k(X_t) --d_t^k--> C^{k+1}(X_t)
    # 2 runs with compensated rewiring under monotonic FIFO (terminating via REPORT_COLLISION)
    # + 2 runs with uncompensated rewiring / non-monotonic delivery (terminating via OVERLAP_GLUING_REFUSAL)
    rewired_receipts: list[HigherCellObstructionReceipt] = []
    for tau in (0, 2):
        ch_comp = NonMonotonicMessageChannel(num_agents=len(caps), latency_steps=tau)
        hg_comp = HigherCellAsyncCommunicatingHypergraph(
            agent_capacities=caps,
            higher_complex=static_complex,
            latency_steps=tau,
            initial_agent_states=init_states,
            initial_budget=initial_budget,
            initial_k_cochain=zero_k_cochain,
            step_fn=make_non_monotonic_rewiring_step_fn(
                caps,
                static_complex,
                rewiring_schedule=rewiring_schedule,
                compensate_rewiring_under_monotonic=True,
            ),
            message_channel=ch_comp,
            rewiring_schedule=rewiring_schedule,
        )
        r_comp = hg_comp.run()
        rewired_receipts.append(r_comp)
        all_receipts.append(r_comp)

    for drop_or_inv in (1, 2):
        ch_uncomp = NonMonotonicMessageChannel(
            num_agents=len(caps),
            latency_steps=1,
            dropped_steps_per_agent={0: {drop_or_inv}},
            permutation_schedule_per_agent={1: {2: 0}},
        )
        hg_uncomp = HigherCellAsyncCommunicatingHypergraph(
            agent_capacities=caps,
            higher_complex=static_complex,
            latency_steps=1,
            initial_agent_states=init_states,
            initial_budget=initial_budget,
            initial_k_cochain=zero_k_cochain,
            step_fn=make_non_monotonic_rewiring_step_fn(
                caps,
                static_complex,
                rewiring_schedule=rewiring_schedule,
                compensate_rewiring_under_monotonic=False,
            ),
            message_channel=ch_uncomp,
            rewiring_schedule=rewiring_schedule,
        )
        r_uncomp = hg_uncomp.run()
        rewired_receipts.append(r_uncomp)
        all_receipts.append(r_uncomp)

    regime_summaries["dynamic_simplicial_rewiring"] = _summarize_regime(
        "dynamic_simplicial_rewiring", rewired_receipts
    )

    eis_check = cross_check_receipts_against_rust_eis(all_receipts)
    return {
        "cochain_degree": cochain_degree,
        "agent_capacities": list(caps),
        "product_carrier_capacity": prod_cap,
        "horizon_bound": horizon_bound,
        "total_ensemble_runs": len(all_receipts),
        "regimes": regime_summaries,
        "distribution_shift_verified": (
            regime_summaries["monotonic_fifo_static"]["counts"]["REPORT_COLLISION"] == 4
            and regime_summaries["monotonic_fifo_static"]["counts"]["OVERLAP_GLUING_REFUSAL"] == 0
            and regime_summaries["packet_loss_static"]["counts"]["OVERLAP_GLUING_REFUSAL"] == 4
            and regime_summaries["out_of_order_permutation_static"]["counts"][
                "OVERLAP_GLUING_REFUSAL"
            ]
            == 4
            and regime_summaries["dynamic_simplicial_rewiring"]["counts"]["REPORT_COLLISION"] == 2
            and regime_summaries["dynamic_simplicial_rewiring"]["counts"][
                "OVERLAP_GLUING_REFUSAL"
            ]
            == 2
        ),
        "eis_cross_check": eis_check,
    }


def verify_bundled_eis_fixture() -> dict[str, int]:
    """Verify 100% parity against the 55 independence vectors and 7 digest vectors from `omega_epistemic_immune_system`."""
    fixture_path = Path(__file__).resolve().parent / "eis_independence_vectors_v1.json"
    data = json.loads(fixture_path.read_text(encoding="utf-8"))
    vectors = list(data["vectors"])
    digests = list(data["digests"])
    if len(vectors) != 55:
        raise AssertionError(f"Expected 55 EIS independence vectors, found {len(vectors)}")
    if len(digests) != 7:
        raise AssertionError(f"Expected 7 EIS digest vectors, found {len(digests)}")

    for idx, row in enumerate(vectors):
        inp = row["input"]
        matches = list(inp["matches"])
        danger = inp["danger"]
        ctx = {
            "detector_id": inp["detector_id"],
            "detector_predicates": inp["detector_predicates"],
            "offsets_are_content": inp["offsets_are_content"],
        }
        actual = verify_signal_independence(matches, danger, ctx)
        if actual != row["expected"]:
            raise AssertionError(
                f"EIS fixture vector {idx} mismatch: {actual} != {row['expected']}"
            )

    for idx, row in enumerate(digests):
        matches = list(row["input"])
        actual_digest = compute_signal1_digest(matches)
        if actual_digest != row["expected"]:
            raise AssertionError(
                f"EIS digest vector {idx} mismatch: {actual_digest} != {row['expected']}"
            )

    return {"independence_vectors": len(vectors), "digest_vectors": len(digests)}


def cross_check_receipts_against_rust_eis(
    receipts: Sequence[
        ObstructionReceipt | HypergraphObstructionReceipt | HigherCellObstructionReceipt
    ],
) -> dict[str, object]:
    """Cross-check emitted single-agent, 2-complex, and higher k-cell refusal receipts against `omega_epistemic_immune_system`.

    1. Verifies all 55 independence vectors and 7 digest vectors in `eis_independence_vectors_v1.json`.
    2. Compiles `rust_eis_companion.rs` with `rustc`, pipes every emitted `ObstructionReceipt`,
       `HypergraphObstructionReceipt`, or `HigherCellObstructionReceipt` into the compiled Rust
       binary over stdin, and asserts 100% bit-for-bit agreement on `signal1_digest`,
       `k <= N + 1` (and `k <= N_A * N_B + 1` product carrier bounds), and
       `assert_signals_independent` verdicts.
    """
    fixture_stats = verify_bundled_eis_fixture()
    rust_src = Path(__file__).resolve().parent / "rust_eis_companion.rs"
    if not rust_src.is_file():
        raise FileNotFoundError(f"Missing Rust companion source: {rust_src}")

    stdin_lines: list[str] = []
    for receipt in receipts:
        if not (0 <= receipt.termination_step <= receipt.carrier_capacity + 1):
            raise AssertionError(
                f"Termination step {receipt.termination_step} exceeds N + 1 = {receipt.carrier_capacity + 1}"
            )
        if isinstance(receipt, (HypergraphObstructionReceipt, HigherCellObstructionReceipt)):
            expected_prod = math.prod(receipt.agent_capacities)
            if receipt.product_carrier_capacity != expected_prod:
                raise AssertionError(
                    f"Product capacity mismatch: {receipt.product_carrier_capacity} != {expected_prod}"
                )
            if not (0 <= receipt.termination_step <= expected_prod + 1):
                raise AssertionError(
                    f"Hypergraph step {receipt.termination_step} exceeds N_A * N_B + 1 = {expected_prod + 1}"
                )

        vec = receipt.eis_vector
        matches = list(vec["matches"])  # type: ignore[arg-type]
        danger = dict(vec["danger"])  # type: ignore[arg-type]
        context = dict(vec["context"])  # type: ignore[arg-type]

        expected_sig1 = compute_signal1_digest(matches)
        if vec["signal1_digest"] != expected_sig1:
            raise AssertionError(
                f"Signal 1 digest mismatch: {vec['signal1_digest']} != {expected_sig1}"
            )
        recomputed_verdict = verify_signal_independence(matches, danger, context)
        if recomputed_verdict != receipt.eis_independence_verdict:
            raise AssertionError(
                f"Independence verdict mismatch: {recomputed_verdict} != {receipt.eis_independence_verdict}"
            )

        m0 = matches[0]
        span0 = list(danger["evidence_spans"])[0]  # type: ignore[index]
        preds = list(context.get("detector_predicates", []))  # type: ignore[arg-type]
        pred0 = str(preds[0]) if preds else ""
        fields = [
            str(receipt.termination_step),
            str(receipt.carrier_capacity),
            str(m0["epitope_name"]),
            str(m0["pattern_matched"]),
            str(m0["offset"]),
            str(danger["danger_type"]),
            str(danger["observer_id"]),
            str(danger["evidence_digest"]),
            str(danger["defect_count"]),
            str(span0[0]),
            str(span0[1]),
            str(context["detector_id"]),
            pred0,
        ]
        if isinstance(receipt, (HypergraphObstructionReceipt, HigherCellObstructionReceipt)):
            fields.append(",".join(str(c) for c in receipt.agent_capacities))
        stdin_lines.append("\t".join(fields))

    with tempfile.TemporaryDirectory(prefix="rsi_rust_eis_") as tmp_dir:
        exe_name = "rust_eis_companion.exe" if os.name == "nt" else "rust_eis_companion"
        exe_path = Path(tmp_dir) / exe_name
        compile_proc = subprocess.run(
            ["rustc", "--edition=2021", str(rust_src), "-o", str(exe_path)],
            cwd=tmp_dir,
            capture_output=True,
            text=True,
            encoding="utf-8",
            timeout=60,
            check=False,
        )
        if compile_proc.returncode != 0:
            raise RuntimeError(
                f"rustc compilation of rust_eis_companion.rs failed:\n{compile_proc.stdout}\n{compile_proc.stderr}"
            )

        run_proc = subprocess.run(
            [str(exe_path)],
            input="\n".join(stdin_lines) + "\n",
            cwd=tmp_dir,
            capture_output=True,
            text=True,
            encoding="utf-8",
            timeout=60,
            check=False,
        )
        if run_proc.returncode != 0:
            raise RuntimeError(
                f"Execution of rust_eis_companion failed:\n{run_proc.stdout}\n{run_proc.stderr}"
            )

        out_lines = [ln.strip() for ln in run_proc.stdout.splitlines() if ln.strip()]
        if len(out_lines) != len(receipts):
            raise AssertionError(
                f"Expected {len(receipts)} Rust output lines, got {len(out_lines)}"
            )

        for receipt, out_line in zip(receipts, out_lines):
            parts = out_line.split("\t")
            expected_sig1 = str(receipt.eis_vector["signal1_digest"])
            verdict = receipt.eis_independence_verdict
            if "ok" in verdict:
                if parts[0] != "OK" or parts[1] != expected_sig1 or parts[2] != verdict["ok"]:
                    raise AssertionError(
                        f"Rust/Python EIS mismatch on OK receipt: {parts} vs {verdict}"
                    )
            else:
                err_obj = dict(verdict["error"])  # type: ignore[arg-type]
                if (
                    parts[0] != "ERR"
                    or parts[1] != expected_sig1
                    or parts[2] != err_obj["code"]
                    or parts[3] != err_obj["message"]
                ):
                    raise AssertionError(
                        f"Rust/Python EIS mismatch on ERR receipt: {parts} vs {err_obj}"
                    )

    return {
        "verified_receipt_count": len(receipts),
        "rust_companion_executed": True,
        "eis_fixture_vectors": fixture_stats["independence_vectors"],
        "eis_digest_vectors": fixture_stats["digest_vectors"],
    }


def main(argv: list[str] | None = None) -> int:
    """CLI entry point running single-agent, 2-complex, and higher k-cell async/non-monotonic/rewired hypergraph scenarios."""
    parser = argparse.ArgumentParser(
        description="Execute finite-state self-modifying transition graphs, shared 2-complexes, and higher k-cell async/non-monotonic/rewired hypergraphs with EIS cross-checking."
    )
    parser.add_argument(
        "--json",
        action="store_true",
        help="Emit machine-readable JSON summary.",
    )
    args = parser.parse_args(argv)

    # 1. Single-agent report collision at k = N (with N = 4, budget = 0)
    g_collision = FiniteStateSelfModifyingGraph(carrier_capacity=4, initial_lift_budget=0)
    r_collision = g_collision.run_trajectory(
        TransitionState(step_index=0, report_id=0, internal_eval=0, remaining_budget=0),
        lambda s: TransitionState(
            step_index=s.step_index + 1,
            report_id=(s.report_id + 1) % 4,
            internal_eval=(s.internal_eval + 1) % 4,
            remaining_budget=s.remaining_budget,
        ),
    )

    # 2. Single-agent lift-budget exhaustion at k = 2 <= N + 1 (with N = 5, budget = 2)
    g_budget = FiniteStateSelfModifyingGraph(carrier_capacity=5, initial_lift_budget=2)
    r_budget = g_budget.run_trajectory(
        TransitionState(
            step_index=0,
            report_id=0,
            internal_eval=0,
            remaining_budget=2,
            requests_carrier_lift=True,
        ),
        lambda s: TransitionState(
            step_index=s.step_index + 1,
            report_id=(s.report_id + 1) % 5,
            internal_eval=(s.internal_eval + 1) % 5,
            remaining_budget=s.remaining_budget,
            requests_carrier_lift=True,
        ),
    )

    # 3. Single-agent overlap gluing refusal (Phi_1([delta]) = 3/4 > 0 at step k = 0 <= N + 1)
    g_holonomy = FiniteStateSelfModifyingGraph(carrier_capacity=4, initial_lift_budget=1)
    r_holonomy = g_holonomy.run_trajectory(
        TransitionState(
            step_index=0,
            report_id=0,
            internal_eval=0,
            remaining_budget=1,
            edge_cochain={(0, 1): Fraction(1, 2), (1, 2): Fraction(1, 2), (0, 2): Fraction(1, 4)},
        ),
        lambda s: s,
    )

    # 4. Multi-agent coupled co-adaptation on SharedTwoComplex delaying termination to k = N_A * N_B = 12
    shared_complex = SharedTwoComplex()
    hg_delayed = MultiAgentCommunicatingHypergraph(
        agents=(
            HypergraphAgentSpec("agent_A", 3),
            HypergraphAgentSpec("agent_B", 4),
        ),
        initial_lift_budget=2,
        shared_complex=shared_complex,
    )
    r_hg_delayed = hg_delayed.run_coupled_trajectory(
        MultiAgentTransitionState(
            step_index=0,
            agent_reports=(0, 0),
            joint_internal_eval=0,
            remaining_budget=2,
            edge_cochain=build_flat_shared_cochain((0, 0), shared_complex),
        ),
        coupled_odometer_step_fn((3, 4), shared_complex),
    )

    # 5. Multi-agent shared 2-complex overlap gluing refusal at step k = 0 <= N_A * N_B + 1
    r_hg_gluing = hg_delayed.run_coupled_trajectory(
        MultiAgentTransitionState(
            step_index=0,
            agent_reports=(0, 0),
            joint_internal_eval=0,
            remaining_budget=2,
            edge_cochain={(0, 1): Fraction(1, 2), (1, 2): Fraction(2, 3), (0, 2): Fraction(1, 3)},
        ),
        coupled_odometer_step_fn((3, 4), shared_complex),
    )

    # 6. Higher k-cell (degree k=2, C^2 --d^2--> C^3) async hypergraph with delay-compensated co-adaptation (tau=2)
    higher_c2 = HigherCellComplex.standard_simplex(degree=2, num_cells=1)
    zero_c2 = {face: Fraction(0, 1) for face in higher_c2.required_k_cells()}
    hg_higher_compensated = HigherCellAsyncCommunicatingHypergraph(
        agent_capacities=(3, 4),
        higher_complex=higher_c2,
        latency_steps=2,
        initial_agent_states=(0, 0),
        initial_budget=20,
        initial_k_cochain=zero_c2,
        step_fn=make_async_delay_compensated_step_fn((3, 4), higher_c2),
    )
    r_higher_compensated = hg_higher_compensated.run()

    # 7. Higher k-cell (degree k=3, C^3 --d^3--> C^4) async hypergraph with uncompensated stale-cochain defect (tau=2)
    higher_c3 = HigherCellComplex.standard_simplex(degree=3, num_cells=1)
    zero_c3 = {face: Fraction(0, 1) for face in higher_c3.required_k_cells()}
    hg_higher_stale = HigherCellAsyncCommunicatingHypergraph(
        agent_capacities=(3, 4),
        higher_complex=higher_c3,
        latency_steps=2,
        initial_agent_states=(0, 0),
        initial_budget=20,
        initial_k_cochain=zero_c3,
        step_fn=make_async_uncompensated_stale_cochain_step_fn(
            (3, 4), higher_c3, defect_trigger_step=2
        ),
    )
    r_higher_stale = hg_higher_stale.run()

    # 8. Non-monotonic channel (packet-loss + out-of-order permutation) and dynamic simplicial rewiring ensemble
    dist_eval = evaluate_termination_distribution_under_non_monotonic_rewiring(
        agent_capacities=(3, 4),
        cochain_degree=2,
        initial_budget=20,
    )

    all_receipts: list[
        ObstructionReceipt | HypergraphObstructionReceipt | HigherCellObstructionReceipt
    ] = [
        r_collision,
        r_budget,
        r_holonomy,
        r_hg_delayed,
        r_hg_gluing,
        r_higher_compensated,
        r_higher_stale,
    ]
    cross_check = cross_check_receipts_against_rust_eis(all_receipts)

    summary = {
        "single_agent_count": 3,
        "multi_agent_hypergraph_count": 2,
        "higher_cell_async_scenarios": [
            r_higher_compensated.to_json_dict(),
            r_higher_stale.to_json_dict(),
        ],
        "non_monotonic_rewiring_distribution": dist_eval,
        "eis_cross_check": cross_check,
    }
    if args.json:
        print(json.dumps(summary, indent=2, sort_keys=True))
    else:
        print(
            f"[OK] Verified {len(all_receipts)} core receipts + {dist_eval['total_ensemble_runs']} "
            f"non-monotonic/rewired ensemble runs against Rust EIS companion "
            f"(distribution_shift_verified={dist_eval['distribution_shift_verified']})."
        )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

