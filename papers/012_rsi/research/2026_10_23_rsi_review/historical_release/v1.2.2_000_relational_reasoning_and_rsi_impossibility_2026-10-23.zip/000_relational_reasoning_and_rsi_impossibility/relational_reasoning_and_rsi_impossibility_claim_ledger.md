# Historical ledger pointer

The pre-integration ledger is preserved verbatim in [docs/pre_integration_claim_ledger.md](docs/pre_integration_claim_ledger.md). It describes the earlier manuscript and is not the claim inventory for version 1.1.0. Current statements and hypotheses are in the manuscript and [docs/embedded_research.md](docs/embedded_research.md); the generated axiom censuses cover actual declarations.
