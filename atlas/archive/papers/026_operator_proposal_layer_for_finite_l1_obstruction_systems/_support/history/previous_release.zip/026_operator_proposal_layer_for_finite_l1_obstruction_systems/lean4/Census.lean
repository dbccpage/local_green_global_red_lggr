import Proposal

open OperatorProposal

#print axioms triangle_coboundary_sums_zero
#print axioms gamma_independent_of_potential
#print axioms phi_zero_implies_gamma_zero
#print axioms exact_field_gamma_zero
#print axioms chart1_is_coboundary
#print axioms chart2_is_coboundary
#print axioms global_cycle_obstructed
#print axioms zero_cycle_exact
#print axioms global_step_not_descent
#print axioms cyclic_shift_preserves_cycle_sum
#print axioms stepOk_erase
#print axioms bridgeOk_erase
#print axioms all_stepOk_erase
#print axioms map_isEmpty
#print axioms pathOk_erase
#print axioms both_paths_accept
#print axioms contEq_refl
#print axioms contEq_symm
#print axioms contEq_trans
#print axioms contEq_in_kernel
#print axioms contEq_stable
#print axioms contEq_maximal
#print axioms same_phi_split_by_translation
#print axioms translation_splits_kernel
