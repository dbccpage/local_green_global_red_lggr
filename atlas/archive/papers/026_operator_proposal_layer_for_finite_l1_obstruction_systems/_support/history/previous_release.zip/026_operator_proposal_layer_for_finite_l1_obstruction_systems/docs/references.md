# Bibliography & Reference Register: Operator Dynamics and Structural Constraints in L1 Obstruction Systems

1. Carroll, J. H. (2026). *Primitive Axiomatics of Finite Obstruction Calculus.* Concept DOI: 10.5281/zenodo.20651224.
2. B. C. Hall, *Lie Groups, Lie Algebras, and Representations*, 2nd ed., Springer, 2015.
3. M. Ehrgott, *Multicriteria Optimization*, 2nd ed., Springer, 2005.
4. J. H. Carroll, "$\ell^1$-Native Cohomology of Defect Fields" (10.5281/zenodo.20186523); "Conditional Density Lift and Dual-Witness $\Xi$ Functional" (10.5281/zenodo.20192297); "Degree-Wise Obstruction Calculus and Symbolic DSL" (10.5281/zenodo.20213227). Zenodo, 2026.
5. R. S. Sutton and A. G. Barto, *Reinforcement Learning: An Introduction*, 2nd ed., MIT Press, 2018.
6. A. Hatcher, *Algebraic Topology*, Cambridge University Press, 2002.
