# tests package initialization
