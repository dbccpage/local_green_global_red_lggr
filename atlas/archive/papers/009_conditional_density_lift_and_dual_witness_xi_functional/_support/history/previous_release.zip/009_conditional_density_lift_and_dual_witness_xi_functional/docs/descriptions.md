# Conditional Density Lift and Dual-Witness Xi Functional: Package Documentation

## 1. Executive Summary
This paper introduces the Conditional Density Lift and the secondary Ξ functional for finite obstruction systems. When multiple candidate repair configurations share identical primary obstruction signatures (Φ₁, Γ₂), the Ξ functional provides deterministic tie-breaking based on the trace distance between pure-state density lifts of the canonical primal residual and optimal dual witness.

## 2. Theoretical Architecture
- **Conditional Density Lift:** Maps non-zero ℓ¹ cochains to pure-state density matrices via ψ(v)_e = sgn(v_e) · √(|v_e| / ||v||₁).
- **Scale Invariance:** ρ(c · v) = ρ(v) for all c > 0, ensuring normalized representation independent of arbitrary cochain scaling.
- **Canonical Representative Selection:** Canonical primal residual h* and dual witness φ* are selected via successive coordinate minimization on the compact optimal face relative to a declared edge ordering.
- **Domain of Ξ:** Defined on the obstructed domain Φ₁ > 0 (where ||h*||₁ > 0); for unobstructed classes Φ₁ = 0, Ξ = 0 by declared operational convention.
- **Trace-Norm Duality and Bounds:** Computes Ξ = ½ Tr|ρ(h*) - ρ(φ*)| = √(1 - |⟨ψ(h*) | ψ(φ*)⟩|²). For optimal pairs, LP complementary slackness enforces Ξ ≤ √(1 - 1/||φ*||₁) ≤ √(1 - 1/m) < 1, precluding orthogonality (Ξ = 1). Zero distance (Ξ = 0) requires magnitude uniformity across the common support in addition to sign agreement.
- **Tiered Evaluator Subordination:** Subordinates Ξ strictly below Φ₁ and Γ₂; Ξ is evaluated only when Φ₁ and Γ₂ are tied within numerical tolerance, subject to the boundary guardrail R_cl ≤ R_max.

## 3. Reference Implementation Overview
The module `code/mod_conditional_density_lift_core.py` provides:
- `DensityLift`: Data structure holding the normalized state vector and density matrix.
- `ConditionalDensityLift`: Engine for computing lifts, trace distances, and the Ξ functional with declared zero-obstruction convention.
- `GuardedEvaluator`: Decision logic implementing tiered priority admission with threshold gating.

## 4. Verification and Test Suite
The test suite `code/tests/test_conditional_density_lift.py` verifies:
- Trace preservation and state purity (Tr(ρ) = 1, ρ² = ρ).
- Strict scale invariance under positive dilation.
- Exact pure-state trace distance formula on generic vectors.
- Zero-obstruction domain handling and declared convention.
- Strictly sub-unitary bounds on optimal pairs (Ξ < 1) and exact zero condition.
- Tiered priority evaluator admission rejecting Φ₁ increases despite favorable Ξ.

The end-to-end integration suite `code/tests/test_lp_solver_integration.py` verifies:
- Successive coordinate minimization pairing with an external LP solver across connected cycle topologies (Figure-Eight B_2, Theta graph, Dumbbell graph, Complete graph K_4, and disjoint triangles).
- Verification of LP strong duality, divergence-free dual circulation (div(φ*) = 0), and complementary slackness.
- Evaluation of Ξ functional on LP-derived canonical representatives, confirming sub-unitary bounds Ξ ≤ √(1 - 1/||φ*||₁) < 1.
- Zero-obstruction convention handling on exact coboundaries (Φ₁ = 0 ⇒ Ξ = 0.0).
- Evaluator tie-breaking behavior on competing LP-solved candidate proposals.

## 5. Security and Scope Boundaries
- **No Physical Quantum Claims:** The density lift is a formal diagnostic tool; it does not claim quantum physical emergence.
- **Diagnostic Scope:** Calculating Ξ produces a secondary diagnostic scalar for tie-breaking; it does not constitute an independent objective or feasibility certificate.
- **Loss of Total Mass and Global Sign:** The mapping v ↦ ρ(v) discards total scalar magnitude M(v) = ||v||₁ and common global sign.

## 6. Mathematical Identities
ψ(v)_e = sgn(v_e) · √(|v_e| / ||v||₁),    ρ(v) = |ψ(v)⟩⟨ψ(v)|
Ξ([ω₁]) = √(1 - |⟨ψ(h*) | ψ(φ*)⟩|²)

## 7. Change Management and Audit History
- v1.0.0: Initial pre-print definition of the Ξ diagnostic.
- v2.0.0: Standardized publication-grade package with exact evaluator subordination and local verification.
- v2.0.1: Defined domain of Ξ with explicit zero-obstruction convention; established canonical selector via successive coordinate minimization on compact optimal face; corrected Proposition 4.2 optimal-pair bounds (Ξ < 1 strictly) and magnitude uniformity condition for Ξ = 0; aligned Section 5 and GuardedEvaluator to tiered priority admission with threshold gating; purged institutional vocabulary; added end-to-end integration test suite pairing external LP solver with compute_xi across connected cycle topologies (`code/tests/test_lp_solver_integration.py`).
- v2.0.2: Corrected domain inequality in Definition 4.1 to ||φ*||₁ ≥ 1 > 0; enforced literal non-increase fences in GuardedEvaluator and Section 5 rejecting any positive creep in Φ₁ or Γ₂; updated compute_xi to preserve small positive obstructions (e.g. triangle canonical residual mass 10⁻¹³ yields exact Ξ = √(2/3)) and flag numerical uncertainty unless certified zero; added relative scaling to integration LP solver; separated exact analytical propositions from float64 implementation checks in claim ledger.
- v2.0.3: Established LP certification boundary via `certify_canonical_primal_dual_pair` checking primal/dual feasibility and certified duality gap (treating tolerance-level defects as uncertain); implemented safe finite-input coordinate normalization scaling by max coordinate before summing; introduced `ZeroObstructionCertificate` checking coboundary residual Bα = ω; validated all evaluator state diagnostics before branching; provided full CC-BY-4.0 and MIT license texts and reconciled Zenodo metadata.

## 8. Standards Compliance
Conforms to CC-BY-4.0 licensing, clean architecture inward dependency invariants, and local-first verification standards.
