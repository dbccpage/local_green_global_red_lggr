# References

1. Carroll, J. H. (2026). *An L1 Obstruction Framework for Coboundary Defects*. Zenodo. DOI: 10.5281/zenodo.20186809.
2. Carroll, J. H. (2026). *Conditional Density Lift and Dual-Witness Xi Functional*. Zenodo. DOI: 10.5281/zenodo.20192297.
3. Carroll, J. H. (2026). *Operator Lifts Trace Metrics and Representation Limits*. Zenodo. DOI: 10.5281/zenodo.20213629.
4. Nielsen, M. A., & Chuang, I. L. (2010). *Quantum Computation and Quantum Information*. Cambridge University Press.
5. Rockafellar, R. T. (1970). *Convex Analysis*. Princeton University Press.
