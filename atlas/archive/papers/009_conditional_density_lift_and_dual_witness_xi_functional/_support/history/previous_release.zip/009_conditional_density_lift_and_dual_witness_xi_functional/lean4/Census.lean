import Xi

#print axioms weights_sum_to_one
#print axioms weight_sign_cross
#print axioms weight_scale_cross
#print axioms cauchy_gap_nonneg
#print axioms dual_mass_at_least_one
#print axioms zero_mass_convention
#print axioms primary_decrease_accepts
#print axioms primary_increase_rejects
#print axioms secondary_increase_rejects
#print axioms guardrail_rejects
