# Conditional Density Lift and Dual-Witness Xi Functional

**Monograph 009** | Finite Obstruction Calculus Program  
**DOI:** 10.5281/zenodo.20192297 | **Version:** 2.0.3

## Abstract
This paper defines a secondary diagnostic functional, Xi, for an l1-primary finite obstruction framework. Using a normalized square-root map into rank-1 density matrices that preserves normalized absolute coordinate weights and real amplitudes without independent phases (discarding total mass and common global sign), Xi measures the trace distance between the canonical primal residual and dual circulation witness selected via successive coordinate minimization. Xi is defined on the obstructed domain Phi_1 > 0 (with Xi = 0 by declared convention when Phi_1 = 0). For optimal pairs, LP complementary slackness enforces Xi < 1 strictly. Xi acts strictly as a tertiary tie-breaker under a tiered priority policy when primary diagnostics (Phi_1, Gamma_2) are tied within tolerance and boundary guardrail R_cl <= R_max is satisfied.

## Quick Start
```bash
py -3.12 -m pytest code/tests/
py -3.12 verify_deposit.py --test code/tests/test_conditional_density_lift.py --test code/tests/test_lp_solver_integration.py --lean
```

