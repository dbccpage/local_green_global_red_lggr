"""Conditional density lift and Xi functional core."""
