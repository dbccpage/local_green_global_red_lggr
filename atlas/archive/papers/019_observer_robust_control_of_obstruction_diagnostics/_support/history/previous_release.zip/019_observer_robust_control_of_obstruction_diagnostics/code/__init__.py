"""Observer robust control core package."""
