# Genesis ongoing manuscripts: derivations, defects, and next obligations

## Current-source review: 2026-10-22

AuthorityEffect: None. Reviewed commit `305b9690f97fc3f5c13e361cfe752a6d5dc7ad8d` on `feat/crates-rs-l4e-scoring`. That is the SHA expected at dispatch. The comparison pin is `c419cc6beb19817065de08a33d3d81f999d6b0ba`. Labels: **W** prose read, **L** Lean read and not compiled, **R** a stored receipt not reproduced, **C** a check run in this pass. No `lake`, cargo, network, or pytest run. Meta evidence was not regenerated.

### What changed

`git diff --name-status c419cc6beb19817065de08a33d3d81f999d6b0ba..HEAD`, limited to the three assigned trees, has two commits: `896f8c262d` (Lean 4.35.0 pins and the rounds 22–25 axiom reporter) and `3b3483051a` (contextual prediction 1.6.0). No serial `paper.md`, no meta `paper.md`, and no mind manuscript is in that diff. The old RSI monograph is unchanged except `012_rsi/000_relational_reasoning_and_rsi_impossibility/lean4/lean-toolchain`, now `leanprover/lean4:v4.35.0`. A dirty worktree exists outside these trees and was not reviewed.

The new manuscript is [contextual_prediction_monograph.md](../../omega_engine_atlas/coda_atlas/F004_papers/012_rsi/001_contextual_prediction_and_self_certification/contextual_prediction_monograph.md), version 1.6.0, read in full (399 lines). **G** and **N** mean the same ongoing package and `meta/next_ten/` folder as in the 2026-10-20 section.

### Papers opened

#### M02, cross-relation guard (W for §4–§6 and ledger rows K2/K3; C on committed JSON)

Derived, and not re-proved this pass: §3.4 still states shortest cost `n + m + 2*tau` and the peak law. The §4 inflation repair is still the two-term shared-loop route with peak two (`paper.md:232-235`).

Wrong: §5 (`paper.md:241-252`) and `claim_ledger.md:50-51` still say 284 states, waves 1, 1, 3, 7, 25, 88, 159, 133 frontier exits, and 280/4 disjoint/overlap. Committed `evidence/run.json` has waves 1, 1, 3, 7, 24, 77, 178, sum 291, `total_results` 291, `frontier_count` 291. `evidence/frontier.json` is a list of 291 exit records (C). Those two files are the six-round, three-term, three-assertion run written by `evidence.py:188-191`. `evidence/disjoint_counts.json` sums to 286 (C). `model.py:271-285` builds that file with `rounds = bound_terms + bound_assertions + 2`, so eight rounds, and counts only disjoint-support states. It is not a 280/4 split of the 291-state run. The 2026-10-20 regeneration is not repeated here; these evidence files are not in the diff, so they are the same bytes that regeneration matched then.

Remains: replace §5 and K2/K3 from those three files, including the eight-round parameter, and add a parser test. The Lean lower and upper bounds for `n + m + 2*tau` are still unproved.

#### M03, given first change (W for the cost-shift sentence and §6; C on JSON)

Derived, not re-proved: `paper.md:115-118` still says every reachable state costs one less than from empty, because the beginning is already the one-term state.

Wrong: the §6.1 table (`paper.md:127-146`) and `adversarial_audit.md:92-95` still say waves 1, 3, 8, 29, 104, total 145, attempts summing to 574 (0+4+23+100+447), and 23 frontier exits, with "145 expected, 145 discovered". Committed `evidence/exploration_summary.json` has waves 1, 3, 8, 28, 99, sum 139, `total_results_expected` 139, `total_results_explored` 139, attempts 0, 3, 21, 100, 446 summing to 570, and `frontier_exits_count` 5 (C). The prose and the receipt name the same bound, three terms and four rounds.

Remains: the Lean statement `dist(root03, S) = size(S) - 1` for nonempty `S`, and a table that quotes this JSON.

#### M08, record order (W for §5–§6; C on JSON)

Derived, as source-visible record facts, not re-read in Lean this pass: order distinguishes two six-step records with the same counts and different admissions. The totals 388 and 386 match both sides.

Wrong: `paper.md:128-136` has new results 1, 1, 2, 7, 22, 88, 267, attempts 0, 1, 4, 18, 91, 436, 2154 (sum 2704), and admissions 0, 0, 0, 0, 0, 6, 74 (sum 80). Committed `evidence/summary.json` has new results 1, 1, 3, 8, 28, 85, 262 (sum 388), attempts 0, 1, 4, 22, 84, 374, 1373 (sum 1858), and admissions 0, 0, 0, 0, 2, 10, 50 (sum 62) (C). Round 2 in the JSON is 3, not 2. §6 still treats the ordered model as a pushdown automaton and the counted model as a vector-addition system (`paper.md:151-154`). That expressiveness claim is still not a theorem.

Remains: per-round equality with `summary.json`, or withdrawal of §6's automata sentence.

#### M01 and M10, the other medium census rows (W for the quoted tables; C on JSON)

M01 §7.1 (`paper.md:135-149`) still reports a two-term, six-round census of 45 states with waves 1, 1, 2, 3, 7, 11, 20. Committed `evidence/waves.json` is `bound` 3, `rounds` 5, `total_discovered` 38, waves 1, 1, 2, 4, 9, 21 (C). M10 §0 item 4 (`paper.md:25`) still quotes `[1, 1, 3, 9, 22]`. Committed `evidence/exploration_summary.json` has `[1, 1, 3, 7, 24]`, both totaling 36 (C).

#### Rounds 22–25, pin and axiom gate (W for the pin sentences; C on reporters and receipt headers)

No cost proof in these four papers was re-opened. Each paper still says toolchain `leanprover/lean4:v4.33.1` and that `lean_report_*.py` rewrites `lean_axioms.txt` while refusing every axiom other than `propext` and `Quot.sound`: `twentysecond/paper.md:11,612`, `twentythird/paper.md:12-15,648`, `twentyfourth/paper.md:12,580`, `twentyfifth/paper.md:13,661`. The twenty-third paper also says all 152 theorems rest on those two axioms at most.

Current `lean-toolchain`, `lean4/lean-toolchain`, and `lean4_core/lean-toolchain` each contain `leanprover/lean4:v4.35.0` (C, file read). `code/twentysecond/leanreport.py`, `twentythird`, `twentyfourth`, and `twentyfifth` now allow `Classical.choice` and write that allowlist into the report header (C, source read). `tests/test_live_round_axiom_policy.py` requires a fixture depending on `Classical.choice` to be accepted for all four rounds. The committed receipts `evidence/{twentysecond,twentythird,twentyfourth,twentyfifth}/lean_axioms.txt` still begin `axioms allowed: propext, Quot.sound` (C). The twenty-third receipt has 152 dependency lines (C), matching the paper's 152, and those stored lines were not recompiled. A fresh report cannot be byte-identical to those receipts, because the header string changed, even if every theorem dependency is unchanged.

This does not by itself show that a twenty-third theorem uses `Classical.choice`. `lean4_core/Twentythird/Axioms.lean:3-4` still says only the two axioms are allowed. The manuscript's description of the checker is false of the current checker.

Remains: either restore the two-axiom refusal and the v4.33.1 pin, or change the four papers and regenerate the four receipts on v4.35.0, stating which theorems, if any, use `Classical.choice`.

#### C02, what awareness is (W, full file, 112 lines)

Derived: an operational clause that a chosen projection detects a nonzero boundary value (`what_is_awareness.md:49-50`). That is a definition restated as Theorem 3.1. No phenomenal bridge is constructed.

Wrong, still: §9 (`what_is_awareness.md:87-88`) says a feedforward DAG has `H^1 = 0` and therefore has no qualia or private observation fibers. The sibling review register still records the opposite counterexample and withdraws the claim: an acyclic poset `a,c < b,d` covered by `up(a)` and `up(c)` has `H^1 ≅ R` with no feedback (`hard_problem_of_consciousness_v004.md:55`, editor note at line 653; the withdrawn Proposition 4.1 is still printed at lines 651-657). A DAG does not fix the coefficient presheaf or the cover, and `H^1 = 0` does not by itself say anything about qualia. Line 65 still writes `d(0) = 1`. Lines 65 and 77 still point at `OE-011-AWARE-C1_awareness_test.py` and `WhatIsAwareness.lean` under legacy paths and say "Type checked, 0 sorry". Those locators were not found as live files in this package on the previous pass; this pass did not repeat a repository-wide search. The opening fence does not cancel §9.

Remains: delete or replace §9 with the sibling review's actual scope, and supply a finite complex plus a linear cochain, or drop the worked example and the Lean/Python status lines.

The hard-problem manuscript was not read past that register, the editor note, and the withdrawn proposition. Its historical body is still marked withdrawn. Retrieval separation remains open. C01 was not opened.

#### R01, old RSI monograph (W and L at the cited lines; file body unchanged)

The report-grounded pigeonhole is not re-opened. These scope failures are still the text: `IsIndependentVerifier` is identifier inequality (`RelationalRsiNoGo.lean:214-215`, L); the diagonal lemma is one self-negating row (`:227-232`, L); the monograph says any non-exact face perturbation induces positive next coboundary (`monograph.md:119`, W); `non_monotonic_rewired_joint_horizon_bound` assumes `rewireTopology k = rewireTopology k` (`RelationalRsiNoGo.lean:731`, L); the harness, when observed lag mismatch is zero and effective lag is positive, writes that lag into the closing face (`rsi_transition_harness.py:1897-1904`, W); zero mutual information and the token-alphabet reading remain at `monograph.md:206,274,279` (W). The purity arithmetic at line 206 was not recomputed.

#### R02, contextual prediction 1.6.0 (W full monograph; L for the proofs named below; C and R as marked)

Derived.

- Theorem 1, under a nonempty finite assignment set: a joint probability vector exists, or the L1 distance to the marginal image is positive. `ContextualDuality.lean:175-238` (`contextuality_strong_duality`, `joint_or_positive_dual`) and `positive_dual_excludes_joint` (`:241-249`) are the statements and the assembly I read (L). The nearest-point lemma they call was not read line by line. `slacks_l1_lower_bound` (`:251-260`) and `exact_slacks_exist` (`:262-285`) show that residual splits have the same optimum as that L1 cost (L). The inequality direction matches the prose: every feasible split is at least the L1 cost.
- Theorems 1a–1d are the budgeted success, infeasibility, and unboundedness claims. I read the theorem names in `Simplex.lean` and `CertifiedOutcomes.lean` and the statements `infeasible_excludes_real`, `ray_real_feasible`, `ray_real_objective`, and `unbounded_below_real` (L, signatures and the monograph's inequality transcription). I did not read the pivot invariants.
- Five stored defects in `docs/lp_certificates.json` are classical `0/1`, PR `2/1`, near `4/5`, boundary `1/25000000`, triangle `2/1` (C). That matches the monograph's list. Lean's check of those numbers was not run (R: `lean4/axiom_report.txt`, `full_axiom_report.txt`).
- Theorem 2 is fiber preservation for one step if and only if for every finite word. `Bridge.lean:16-32` is that induction, with the one-letter converse (L). The adaptive-policy extension is prose, as the monograph says (`monograph.md:176`).
- A constant digest makes two different histories share a tip (`Bridge.lean:50-54`, L). A passing three-role packet does not make action 1 safe (`Bridge.lean:60-63`, L).
- `MindContracts.lean:9-36`: accepting a report whose whole fiber is correct is sound, every sound report-only rule is contained in that rule, and a uniform score error `b` gives regret at most `2b` (L). The reduction `b = KE + ζ` is not in that file. The monograph says so.
- `ErrorBudget.lean:99-136`: the waiting-window and correction-capacity implications follow from the inequalities they assume, including `η > 0` and `rate > 0` (L). They do not integrate an ODE.
- The uncertain-observation fixture, run as `py -3.12 uncertain_observation_example.py` from `code/`, returns `SIGNALLING`, raw L1 error `1/50`, LP defect `1/50`, and guaranteed margin `0` (C). That matches `monograph.md:250-251`.

`ResultI.lean` through `ResultIV.lean` are byte-identical to `001_finite_obstruction_calculus/002_asi_no_go_theorem_epistemic_contextuality/lean4/` and to the v1.5 review copies (C, SHA-256). The monograph's identity sentence is true of those four files.

Wrong: no contradiction turned up between the monograph sentences I checked and the Lean or the two numerical receipts I checked. The limits the monograph already states are real limits, not extra errors found here: unbudgeted Bland completeness is not proved; the 95 Python/Lean rows are finite agreement, not refinement; `docs/simplex_execution_cases.json` contains 95 cases (C, count only) and was not replayed (R); the axiom reports list only `propext`, `Quot.sound`, and `Classical.choice` (R, text scan of both reports, C for the set of axiom names appearing in `full_axiom_report.txt`) and were not produced by a Lean run here; Tarski and Löb stay imported; the continuous enclosure is a hypothesis. Section 5.2 does not repeat the DAG-implies-qualia argument. It says no phenomenal-identity claim is made (`monograph.md:347`).

Remains: a Lean proof that unbudgeted Bland search finds an optimum, or an explicit budget premise on every solver claim that is used as a theorem; a Lean statement of the adaptive transcript case; a representation theorem if Python and Lean are to be one algorithm.

### Prior findings

| Item | Status now | Evidence this pass |
|---|---|---|
| N1 M02 census | OPEN | Prose 284/133/280/4; `run.json` and `frontier.json` 291; `disjoint_counts.json` 286 on the eight-round disjoint census |
| N2 M03 census | OPEN | Prose 145, attempts 574, exits 23; JSON 139, attempts 570, exits 5 |
| N3 M08 per-round table | OPEN | Totals 388 and 386 agree; new, attempt, and admission vectors do not |
| N10, including M01 and M10 | OPEN | M01 prose 45 versus `waves.json` 38; M10 prose `[1,1,3,9,22]` versus JSON `[1,1,3,7,24]` |
| M02 term-inflation repair | Still the repaired text | `paper.md:234` still gives the peak-two route. Not a new proof |
| C02 DAG / `H^1` / qualia, `d(0)=1`, dead locators | OPEN | Full file re-read; sibling register lines 55 and 653 re-read |
| R01 non-exact perturbation, injected lag, identifier independence, tautological rewiring hypothesis | OPEN | Lines cited above; monograph bytes unchanged |
| N4 and N5 | OPEN | Same files as M01 and M10 |
| N6, N7, N9, C01, and the serial proof gaps marked OPEN on 2026-10-20 | OPEN, not re-opened | Those manuscript bytes are not in the diff |
| N8 vertex-cover remark | OPEN as a missing hardness proof | `paper.md:272` still names the cover and does not give a reduction |
| M04 table repair and M04 transport | Not re-opened | `04-written-refusal` is not in the diff. Prior FIXED and PARTLY FIXED labels are not re-tested |

### Grades

| Family | Grade | Change | Why |
|---|---|---|---|
| Serial chain | B | was B+ | The cost arguments were not re-opened and no counterexample to them was found. Rounds 22–25 now describe a two-axiom refusal and a v4.33.1 pin that the reporters and toolchain files contradict. |
| Meta next ten | C | unchanged | M02, M03, and M08, plus M01 and M10, still quote censuses their committed JSON rejects. |
| Mind and consciousness | C- | unchanged | C02 §9 is still the false DAG inference. C01 was not opened. C03 was opened only at the withdrawal. |
| RSI monograph 000 | C+ | unchanged | Base counting claim not re-opened; the scope failures above are still in the text. |
| RSI contextual 001 | B+ | new | The theorems read match the Lean that was opened, and the one fixture that was run matches. Solver completeness and language refinement stay open. Lean was not compiled. |
| Overall | B- | unchanged | The new contextual paper is careful. It does not repair the false censuses, the qualia inference, or the old RSI scope failures, and the serial reproducibility sentences got worse. |

### Three most serious defects

1. M02, M03, and M08 still certify counts their own committed evidence rejects. The sharp case is M03's "145 expected, 145 discovered" against `exploration_summary.json`'s 139. M02's 284 and 133 are `paper.md` and `claim_ledger.md`; 291 is `run.json` and the length of `frontier.json`.
2. `what_is_awareness.md:87-88` still says a feedforward DAG has vanishing `H^1` and therefore no qualia. `hard_problem_of_consciousness_v004.md:55` still records an acyclic crown with `H^1 ≅ R` and withdraws that implication.
3. The old RSI monograph still says any non-exact face perturbation induces a positive coboundary (`monograph.md:119`), and `rsi_transition_harness.py:1897-1904` still fills a zero observed mismatch with positive effective lag before the refusal is counted.

The principal new defect is the rounds 22–25 gate. It is a false description of the checker, not a refutation of those cost theorems. It is less serious than the three items above and more serious than the unchanged low notes N6, N7, and N9.

### What remains to be derived

A parser that fails when a meta table disagrees with its evidence JSON, then corrected M02, M03, M08, M01, and M10 tables. Lean transport of M02's `n + m + 2*tau` bound. Withdrawal or a real cochain example for awareness §9. A statement of the rounds 22–25 axiom gate that matches the reporter, with receipts regenerated or the reporter put back. For contextual prediction: unbudgeted termination or a budget hypothesis on each used solver claim, and the adaptive fiber case in Lean. For the old monograph: the non-exact clause and the lag fixture stated as assumptions, not as channel theorems.

### Checks run

| ID | Command or read | Result |
|---|---|---|
| C0 | `git rev-parse HEAD` | `305b9690f97fc3f5c13e361cfe752a6d5dc7ad8d` |
| C1 | `git diff --name-status c419cc6beb19817065de08a33d3d81f999d6b0ba..HEAD` on the three trees | No manuscript prose in the serial, meta, or mind trees; new contextual package; four `leanreport.py` files; toolchain pins; `test_live_round_axiom_policy.py` |
| C2 | `py -3.12` sums of the committed JSON files named above, plus 95 case objects, five certificate defects, 152 twenty-third dependency lines, and the axiom-name set in `full_axiom_report.txt` | Figures in the manuscript sections above. Exit 0 |
| C3 | SHA-256 of `ResultI.lean`–`ResultIV.lean` against the precursor package and the v1.5 copies | All four equal |
| C4 | `py -3.12 uncertain_observation_example.py` in the contextual `code/` directory | Exit 0; `SIGNALLING`; defect and raw error `1/50`; margin `0` |

Not run: `lake`, the M02 pytest regeneration, `replay_simplex_implementation.py`, `replay_mind_expansion.py`, and the axiom census commands. The 19-assertion mind replay and the Lean axiom reports are R, read as stored text. `docs/mind_expansion_replay.json` says 6 groups and 19 assertions; that script was not executed.

Not opened: serial papers other than the rounds 22–25 pin sentences and the meta files named above; C01; the hard-problem body outside the register and Proposition 4.1; `Simplex.lean` pivot proofs; the contextual PDF, ZIP, and vendor archive; the precursor monograph body.

## 2026-10-20 baseline (historical)

AuthorityEffect: None. Source pin c419cc6beb19817065de08a33d3d81f999d6b0ba.

### Verdict

The serial Genesis-ongoing chain remains the strongest derivation work in this slice: the central cost, quotient and detector arguments I re-derived or recomputed agree with the manuscripts. Two meta manuscripts were repaired since the 2026-10-18 pin. M02 now carries a sound written cost and peak theorem, and M04's copied table rows are corrected. The main new result of this pass is negative: five of the ten meta manuscripts (M01, M02, M03, M08, M10) quote census tables that disagree with their own committed evidence, and the committed evidence is the side that matches an independent count. The mind/consciousness and RSI texts did not change; their prior defects stay open.

Only 18 files changed under the three assigned folders between `000ee9b0c2` and `c419cc6beb` (`git diff --stat 000ee9b0c2..HEAD`), all inside `meta/next_ten/02-relation-cross-guard/` and `meta/next_ten/04-written-refusal/`. They came from commit `c37b04d384` (PR #1236, merge `b9d3737772`, ledger [batch 05](../plans/review_remediation/batch_05.md)) and commit `bc03179ce3` (PR #1238, merge `cb1a8f379d`, ledger [batch 07](../plans/review_remediation/batch_07.md)). The other 37 manuscripts are byte-identical to the baseline pin, so every prior finding on them keeps its status unless a new check below changes its evidence.

In links below, **G** is [001_genesis_ongoing_h3v7n5qf](../../omega_engine_atlas/coda_atlas/F004_papers/001_finite_obstruction_calculus/001_genesis_ongoing_h3v7n5qf/) and **N** is its `meta/next_ten/` folder. The subtree's `AGENTS.md` defers to its `CLAUDE.md`; its given/chosen/derived/computed/refuted/open bookkeeping is applied here. No paper, test or evidence file was edited.

### Checks run now

Every result below is a check run in this pass, not an archived receipt. Python is `Python 3.12.10`; pytest is `pytest 8.3.5`; `cmp` is GNU diffutils 3.12; git is 2.54.0.windows.1. Scripts live outside the repository in `C:/Users/a343o/.claude/jobs/05b9c4fc/tmp/r2/`.

| ID | Exact command | Exit | Tested scope | Result |
|---|---|---|---|---|
| K1 | `py -3.12 -m pytest C:/Users/a343o/source/repos/the_symbol_game/.claude/worktrees/review-refresh-20261020/omega_engine_atlas/coda_atlas/F004_papers/001_finite_obstruction_calculus/001_genesis_ongoing_h3v7n5qf/meta/next_ten/02-relation-cross-guard/derivation/test_derivation.py -q -p no:cacheprovider -o addopts="" --basetemp C:/Users/a343o/.claude/jobs/05b9c4fc/tmp/pt_reader2` | 0 | One file, 32 tests; package `addopts` cleared so no coverage file is written into the worktree; the package `pythonpath = ["code"]` still applies | 32 passed in 19.97 s |
| K2 | `cmp -s C:/Users/a343o/.claude/jobs/05b9c4fc/tmp/pt_reader2/test_evidence_compares_bytes_a0/<f> <worktree>/<N>/02-relation-cross-guard/derivation/evidence/<f>` (one call per file `<f>`) for `run.json`, `frontier.json`, `differential.json`, `disjoint_counts.json`, `witnesses.json`, `cost_checks.json`, `formal_status.json`, `MANIFEST.sha256` | 0 each | The eight files K1 regenerated in its temporary directory against the committed evidence | All eight byte-identical |
| K3 | `py -3.12 -I .../r2/check23.py` | 0 | Twentythird D5(b) closed form against brute-force gauge search; D7 four-term example | Examples cost 6 and 12 by both methods; 0 mismatches on 400 seeded random three-term tables; raising `{a,d}` lowers 5 to 3, no single or triple raising lowers it |
| K4 | `py -3.12 -I .../r2/check25.py` | 0 | Twentyfifth D6/D7 by exact `Fraction` Gaussian elimination | Unseen non-loop directions 2, 2, 0, 0 for n = 3..6; with five terms, labelled deciding sets 0 of each size up to 5, 125 of 210 at six, 110 of 120 at seven, all at eight to ten |
| K5 | `py -3.12 -I .../r2/ninth_counts.py` | 0 | Independent Burnside count of ninth-seed results by size | Unbounded layers 1, 3, 8, 29, 104, 420, 1783; at most two terms 1, 3, 7, 24; at most three terms and three assertions 1, 3, 8, 28, 94, 202 |
| K6 | `py -3.12 -I .../r2/check_misc.py` | 0 | HOPE split arithmetic; M01 two-term formula; M02 wave prediction; M03 and M08 table arithmetic | See new findings N1-N4, N8 |
| K7 | `py -3.12 -I .../r2/check_rsi.py` | 0 | RSI monograph line 206 worked values | Werner `p = 1/5` purity 7/25 = 14/50, Z⊗Z-pinched 13/50; plus-state pinched purity 1/2; all match |
| K8 | `py -3.12 -I .../r2/vectors.py N` | 0 | Every bracketed integer vector in each meta `paper.md` against per-round vectors in its `evidence/*.json` | Inputs for N1-N4 |

No `lake`, notebook, provider, network or whole-suite run happened. Lean statements below are source-visible statements, not compiled now. The M04 axiom claim rests on the archived [batch 05 receipt](../plans/review_remediation/batch_05_checks.json), not on a check run here.

### Changed manuscripts, read in full

#### M02. Cross-relation guard (`N/02-relation-cross-guard/derivation/paper.md`, 272 lines)

| Question | Answer |
|---|---|
| What is derived? | Section 3.4 (lines 131-218) states, for unnamed natural-multiplicity states from empty, shortest cost `L(S) = n + m + 2*tau`, where `tau` is the smallest term set meeting every ordered pair asserted in both relations (a loop forces its endpoint). Lower bound: a path has length `n + m + 2I + 2R`; tracking each term addition's label shows a shared pair whose two endpoints were never merged cannot hold surviving `r` and `s` occurrences, because the later addition would have been blocked by the earlier surviving one; so the endpoints with merged label classes meet every shared pair and `I >= tau`. Upper bound: one fresh helper per meeting term carries the assigned `s` occurrences and is then identified. Peak law: minimum peak is `n + 1` exactly when `n > 0` and every final term touches a shared pair, else `n`; necessity uses the last addition that reaches `n` terms. I re-derived both bounds and the peak argument line by line and found no gap. Status: written derivation; no Lean theorem for either formula (the paper says so, lines 213-218); bounded census in `cost.py` and K1. Lean source states only `StepG.toStep9`, `reach_add_preserves_disjoint`, `overlapping_unreachable_by_additions` and one merge. |
| What is wrong? | Section 5 (lines 241-252) and claim ledger rows K2_guard/K3_guard (`claim_ledger.md:50-51`) report 284 states, waves 1, 1, 3, 7, 25, 88, 159, 133 frontier exits and 280/4 disjoint/overlap. The committed, freshly regenerated evidence (K1, K2) has 291 states, waves 1, 1, 3, 7, 24, 77, 178 and 291 frontier entries; `disjoint_counts.json` totals 286 over a separate eight-round run (new finding N1). The prose "Byte-identical check" bullet was replaced, but the numbers above it were not. Minor: section 3.3 item 1 still calls `+2` "cost elevation"; the ledger's own note (line 72) correctly says the penalty is `2*tau`, which is 6 for three shared loops. |
| What remains? | (a) Correct section 5 and K2/K3 from `run.json`, `frontier.json`, `disjoint_counts.json`, with a parser test that fails on any mismatch. (b) Lean target: for the guarded list-state model with explicit carrier-support invariants, `Reach emptyG S -> length >= n + m + 2*tau(S)` and existence of a path of that length with peak `n + [n > 0 and every term touches P]`, plus representation transport from the Python `DState`. (c) State the complexity consequence: `tau` is a vertex-cover number (finding N8). |

#### M04. Written identity plus refusal (`N/04-written-refusal/derivation/paper.md`, 122 lines)

| Question | Answer |
|---|---|
| What is derived? | Lean `atMost_stutter_iff` and `firstAt_stutter_iff` (`Derivation.lean:238-303`): for any relation `R`, adding identity edges preserves "reachable within `n` steps" and first-discovery depth. I read both proofs: the identity case uses `AtMost.weaken`, which is sound because `AtMost` admits a zero-length path at every budget. `bounded_written_stutter_closure` / `_first_discovery` instantiate this for performed steps whose endpoints respect the term bound. Two Boolean controls show the identity premise is needed. Status: source-visible Lean statement; axiom report archived in batch 05, not replayed. The written census (section 3.1: 69 = 1 + 4 + 64 FREE, 137 = 1 + 8 + 128 ANCHORED) is correct by hand arithmetic. |
| What is wrong? | Nothing new in the central claims. The table (lines 56-61) now equals `evidence/summary.json` in every field I compared (waves, refusals, exits, quotient classes, splitting fibers); all four wave vectors sum to 137 or 69 (K6). Section 3.2's orbit-stabilizer identity holds for every finite group action; checking it tests the code's orbit and stabilizer routines, not a property of this seed. |
| What remains? | Transport theorem: a representation map `rep : PyState -> St` such that the Python explorer's performed relation equals `BoundedPerformed bound` on images, and refusal outcomes map to identity edges; then the bounded Python closure equals the Lean closure for B = 3, R = 12. The paper and ledger now list this as open (O04-1). |

### Per-manuscript register

Statuses: **W** written derivation, **L** source-visible Lean statement (not compiled now), **C** computed in an archived artifact, **K** checked in this pass. "Prior" refers to the 2026-10-18 baseline below.

#### Serial manuscripts (G/paper/)

| # | Derived (status) | Wrong (status, location) | Remains (theorem-shaped target) |
|---|---|---|---|
| 01 main | D8 cost `size(G) - size(given) + 2*lost(G)`: potential bound and explicit edit path, W+L for written states; FREE closed form for `lost`; D12 completeness within the bound. I rechecked D8's lower-bound case analysis and the FREE closed form by hand. | Prior D11 gap OPEN (`paper.md:280-292`: Lean `build_needs_term_and_assertion` lacks build well-formedness; `3*2^d` list checked on one state). | For every well-formed build `B` of an obstructed `xrx` on `S`, `B` adds a term `t` outside `S` and an assertion mentioning `t`; and `fewest_changes` for every name placement (O3). |
| 02 second | Carrying-map persistence; shortest cost is size difference; monotone class count. W+L for persistence and cost. | Prior OPEN: fiber-collapse sufficiency is written only (`second/paper.md:331-346`). | `Reach3 S T <-> exists f, f_*(S) <= T` with `f` a term map, in Lean. |
| 03 third | Containment, unique path length, `reach2_iff`. W+L. | No defect; prior limitations OPEN. | Shortest-history count with an explicit history equivalence. |
| 04 fourth | Multiplicity containment; cost counts total multiplicity; binomial two-term histories. W+L. | Prior historical custody gap NOT RECHECKED. | Lean: explored count `(n, m)` equals Burnside count for all cells within the bound. |
| 05 fifth | Lost-given potential gives exact cost; ANCHORED two components; FREE communication. W+L. | No defect; sum-on-merge is chosen. | Cost formula or counterexample under max-on-merge. |
| 06 sixth | Revised lost term for loopy merges; old remove-first identity refuted by witness. W+L. | No defect. | General shortest-history formula. |
| 07 seventh | Cost equals size from empty; nonempty states communicate. W+L. | Prior wording point OPEN (the "nothing about asserting" list is qualified in text). | Lean: round-`k` result count equals the orbit-series coefficient. |
| 08 eighth | Cost is sixth's `r` cost plus `s` total; shared terms counted once; orbit counts not products. W+L. | No defect. | Lean witness that the joint orbit count exceeds the product at a stated weight. |
| 09 ninth | Empty-source cost is size; exchange symmetry; part costs not additive. W+L; my K5 Burnside layers 1, 3, 8, 29, 104, 420 equal the paper (`ninth/paper.md:694`). | No defect. | Formal count completeness. |
| 10 tenth | Inert annotation preserves cost; bare-term restoration criterion (W+C). | Prior OPEN: `tagged_cost_fails` gives a route, not a lower bound. | Lean: identification of `u, v` is one-step restorable iff `u` or `v` is bare. |
| 11 eleventh | Rectangle-constant recoverability; coarsening persistence. W+L. | Prior NOT RECHECKED: the corrected overcount was not replayed. | Labeled orbit object and a complete interpretation register. |
| 12 twelfth | Per-relation record; empty record restorable by one term. W+L. | Prior OPEN: `recorded_cost_is_size` is a size equality, not a shortest-path statement. | Exact tagged shortest costs. |
| 13 thirteenth | Coarse sum `M_r + M_s`; split count is the product of `(N + 1)`; descent of size and reachability. W+L. | No defect. | Orbit-aware fiber count. |
| 14 fourteenth | Tags inert in state, active in results; joint canonicalization. W+C. | Prior OPEN: `leftover_not_answer` is excluded middle (`fourteenth/paper.md:109`). | Typed statement that a leftover is neither an assertion nor an answer, as a property of the types. |
| 15 fifteenth | Admission flag separates reaching from admission; tagged reading raises some costs. W+C. | Prior OPEN: `admission_not_a_kind` (`fifteenth/paper.md:119`) and `no_cross_constraint` are weak statements. | Noninterference: projection to ninth states commutes with every step, for both flag values. |
| 16 sixteenth | Potential `size + 2*record` is exact cost (each change moves it by exactly one); mass monotone; carrying criterion necessity; D7 one-term count `(floor((k-1)/2)+1)(ceil((k-1)/2)+1)`, which I rechecked by hand for k = 1..10. W+L for cost and mass. | Prior wording OPEN (`sixteenth/paper.md:73`: "one-way again" while D6 reports 596 mutual pairs). | Lean O3: for nonempty `S`, `Reach16 S T <-> exists f` with pushforward mass at most `T`'s mass on every pair. |
| 17 seventeenth | M1/M2 agree on loop-free inputs; refusal preserves loop-freeness. W+L. | No defect. | Arbitrary-writing transport. |
| 18 eighteenth | Written states refine classes: 137/69 versus 109/20. W+C. | Prior OPEN: nameless detours beyond three terms unresolved (O2). | Nameless written shortest cost equals the least over writings, or an explicit shorter detour. |
| 19 nineteenth | Local rewrite keeps terms; one-term and merged-name states unreachable. W+L. | No defect. | `PReach S T` criterion for local rewrites. |
| 20 twentieth | Attempt order inside waves does not change closure or rounds; matched-budget comparison. W+C. | No defect. | Matched-budget benchmark with work counts. |
| 21 twentyfirst | Refusal closure equals unobstructed closure within the bound. W+C. | No defect. | All-finite closure equality in Lean. |
| 22 twentysecond | Signed excess quotient; cost `n + sum abs(e)`. W+L. | No defect. | Selector theorem separating C-X from C-X'. |
| 23 twentythird | Gauge sameness; zero-class detector by loops, two-way sums and triangles; cost `n + min_g sum abs(e + g(x) - g(y))`; three-term closed form; set-raising descent optimality (D5(c)). I re-derived the D5(c) exchange argument and the interval-distance closed form; K3 agrees on both quoted examples and 400 random tables. W+L (`cost3_iff_min`), K. | Prior limitation OPEN: term addition does not respect the quotient (`addTerm_not_respected`). | Lean: if no set-raising lowers `F(g)`, `g` is a global minimizer (D5(c) is written only). |
| 24 twentyfourth | Filled-vertex detector; misses nonzero pair and triangle classes. W+L. | Prior limitation OPEN (parity fails on filled merges; acknowledged). | Complete observer bundle: loops, pairs and filled triangles together decide the zero class. |
| 25 twentyfifth | Triple detector; blind directions; deciding sets have rank `C(n-1, 2)`. K4 reproduces the D6 direction counts and the D7 five-term census (125 of 210 labelled six-sets) by exact rank. W+L for the five-term blind lemmas. | Prior OPEN: general rank criterion is written only. | Lean: a set of filled triples decides iff its sum-around rows have rank `C(n-1, 2)` on antisymmetric excesses, for every `n >= 3`. |

#### Meta manuscripts (N/*/derivation/paper.md)

| # | Derived (status) | Wrong (status, location) | Remains (theorem-shaped target) |
|---|---|---|---|
| M01 | Bare-term removal closes the empty/one-term cycle; size bounds empty-source cost. W+L (concrete cycle). | Prior OPEN (Lean is the concrete cycle). New N4: section 7.1 (`paper.md:135-149`) declares B = 2, R = 6, 45 states; committed `waves.json` is a B = 3, R = 5 run with 38 states. | Lean: `dist(empty, S) = size(S)` and strong connectivity on the full carrier. |
| M02 | See the changed-manuscript table above. | Prior generalization and witness errors FIXED (PR #1238); Lean scope OPEN; new N1. | See above. |
| M03 | Bare one-term beginning; cost `size - 1`; empty unreachable. W+L (nonemptiness only). | Prior OPEN. New N2: table `paper.md:127-146` uses unbounded counts under a declared bound of three terms. | Lean: for nonempty `S`, `dist(root03, S) = size(S) - 1`. |
| M04 | See the changed-manuscript table above. | Table FIXED, closure PARTLY FIXED (PR #1236). | See above. |
| M05 | Refusal memory: loops first arise after two attempts. W+L (witness). Totals and round-4 counts in `paper.md:130-135` match `summary.json` (K8). | Prior OPEN: attempts, performed steps and rounds are distinct cost units. | Renaming equivariance of the refusal record through merges. |
| M06 | Budget decreases by one per performed step; at most four steps; 46 results by budget 1, 1, 3, 9, 32. I rechecked the census by hand: 2-term size-4 states number (36 + 4)/2 = 20 by Burnside, so 1 + 4 + 20 + 4 = 29. W+L. | Prior OPEN: identity-step reading (`paper.md:58`) versus `BStep.not_step_at_zero`. New N6 (`paper.md:218`, 402 should be 420) and N7 (`paper.md:5`, status definition). | Lean: `BReach emptyB (s, b) <-> WF s and size s <= 4 - b and size s = 4 - b (mod 2) and (b < 4 -> s.n >= 1)`. |
| M07 | Local-record equivalence; 69 -> 20 -> 14 -> 8 classes, matching `evidence.json` (K8). W+L. | Prior OPEN: non-congruence blocks quotient dynamics. | A refined observation for which `LocalEquiv` is a step congruence, or a proof that none of bounded size exists. |
| M08 | LIFO record; two six-step witnesses with equal counts and different admissions; 388 versus 386. W+L (record facts). | Prior OPEN: automata-power claim (`paper.md:154`). New N3: per-round table `paper.md:128-136` disagrees with `summary.json`. | Either an encoding of a pushdown language into the record-order system with a separation proof, or withdrawal of the claim. |
| M09 | Parity excludes two-step restoration of an identification. W+L (metrics). Totals 20 563 + 447 + 449 = 21 459 changes and 1 556 + 41 + 35 = 1 632 states match `evidence.json`. | Prior OPEN: `StateMetrics` abstraction. | Full-state projection commuting with steps, plus the bare-term criterion. |
| M10 | Swap involution; distance `min(dist9(S,T), 1 + dist9(swap S, T))` on written states. W+L (aggregate). | Prior OPEN; strengthened by K5: at most two terms the ninth layers are 1, 3, 7, 24, which equals the stored `[1, 1, 3, 7, 24]` and refutes the quoted `[1, 1, 3, 9, 22]` (`paper.md:25`). | Swap distance on result classes, with the case where swapping relations equals swapping terms. |

#### Mind, consciousness and RSI (unchanged since the pin)

| # | Derived (status) | Wrong (status, location) | Remains (theorem-shaped target) |
|---|---|---|---|
| C01 HOPE | Split `(f/2, f/2)` with `psi = f/norm(f)` gives `s_H = norm(f)/2` and pseudoinverse lift `norm(f)`; K6 reproduces this exactly. W, K. | Prior OPEN: m-way scale labelled "Published HOPE scale" (`hope_engine.py:12,39`); upstream not checked (NOT RECHECKED). New N9 (`hope_engine.py:42`). | If the parent family contains the aggregate direction and `E + b > 0`, the pseudoinverse lift recovers the aggregate signal. |
| C02 awareness | An operational definition of detection relative to a chosen differential. W. | Prior OPEN: DAG implies `H^1 = 0` implies no qualia (`what_is_awareness.md:87-88`); `d(0) = 1` (line 65); dead Lean and Python locators with "Type checked, 0 sorry" (lines 65, 77-78). | A finite complex, observer map and nonzero cochain example, or withdrawal of section 9. |
| C03 hard problem | One-observation reconstruction bound; boundary factorization gives kernel inclusion. W+L. | Prior OPEN (historical claims withdrawn by the review edition; retrieval separation still missing). | A map from cochain class to reconstruction diameter, or a counterexample. |
| R01 RSI | Report-grounded strict order has no infinite improving trajectory (pigeonhole); line 206 worked purities check out (K7). W+L. | Prior OPEN: `IsIndependentVerifier` is ID inequality (`RelationalRsiNoGo.lean:214`); diagonal lemma scope (`:227`); "any non-exact face perturbation" (`monograph.md:119`); tautological rewiring clause (`:731`); injected async defect (`rsi_transition_harness.py:1897-1904`); zero-mutual-information and token-alphabet readings (`monograph.md:206, 274, 279`). | A verifier-independence contract with a no-go theorem stated under it. |

### Prior-finding status

The baseline lists 42 defect or scope items. Status counts: **FIXED 3, PARTLY FIXED 1, CHANGED 0, OPEN 35, NOT RECHECKED 3.**

| Prior item | Status | Current evidence |
|---|---|---|
| M02 `n >= 2` overlap needs `n + 1` terms | FIXED | `N/02-relation-cross-guard/derivation/paper.md:47,183-202`; PR #1238 |
| M02 one-term above-bound "holds" witness | FIXED | `paper.md:234` uses the two-term shared-loop route with peak two |
| M04 copied `bra=true` rows | FIXED | `N/04-written-refusal/derivation/paper.md:56-61` equal `summary.json`; PR #1236 |
| M04 closure equivalence not formalized | PARTLY FIXED | Shared-relation theorems at `Derivation.lean:238-303`; Python/Lean transport open |
| 04 historical custody gap; 11 overcount replay; C01 upstream source | NOT RECHECKED | Not replayable without regeneration or the absent upstream |
| All other baseline items (main ×2, 02, 07, 10, 12, 14, 15, 16, 18, 23, 24, 25, M01, M02 Lean scope, M03, M05, M06 ×2, M07, M08, M09, M10 ×2, C01 attribution, C02 ×3, C03, R01 ×6) | OPEN | Source bytes unchanged since `000ee9b0c2`; anchors in the register above |

### New findings

| ID | Severity | Location | Mechanism | Failure scenario | Acceptance test |
|---|---|---|---|---|---|
| N1 | medium | `N/02-relation-cross-guard/derivation/paper.md:241-252`; `claim_ledger.md:50-51` | Section 5 and K2/K3 quote 284 states, waves ending 25, 88, 159, 133 exits and 280/4. Committed and regenerated `run.json` (K1, K2) gives 291, waves 1, 1, 3, 7, 24, 77, 178, and 291 frontier entries. The stored waves equal the paper's own cost law: ninth layers 94 and 202 (K5) minus the 18 and 28 states delayed by the guard, plus 1 and 4 shared-pair targets of cost 5 and 6, give 77 and 178 (K6). | A reader or index cites 284/133 as the bounded census; a total-only or hash check passes because the prose is never compared. | A test that parses section 5 and K2/K3 and compares each number with `run.json`, `frontier.json` and `disjoint_counts.json`, failing under a one-digit mutation. |
| N2 | medium | `N/03-given-first-change/derivation/paper.md:127-146`; `adversarial_audit.md:92-95` | The table gives rounds 1, 3, 8, 29, 104, 145 states, 574 attempts and 23 exits. 29 and 104 are the unbounded ninth layers of sizes 4 and 5 (K5). Under the declared bound of three terms the 4-term empty state and five 4- or 5-term size-5 states are excluded: 28 and 99, total 139, matching `exploration_summary.json` (attempts 0, 3, 21, 100, 446; 5 exits). | The paper's completeness certificate ("145 expected, 145 discovered") certifies a number no stored run produced, and contradicts its own bound. | Same table-to-receipt test as N1, plus a check that every quoted round count is at most the bounded Burnside count. |
| N3 | medium | `N/08-record-order/derivation/paper.md:128-136` | Table waves 1, 1, 2, 7, 22, 88, 267 versus stored 1, 1, 3, 8, 28, 85, 262; attempts and admissions differ too; both total 388. Round 2 must be 3 (add a term, add `0r0`, add `0s0` from the one-term state are distinct), and an admission is available at round 4 (add term, add, remove, admit), so the paper rows are wrong without reference to the JSON. | Same defect class as M10: equal totals hide a wrong per-round allocation. | Per-round equality test against `summary.json`, with a mutation that swaps two rounds and keeps the total. |
| N4 | low | `N/01-remove-bare-term/derivation/paper.md:135-149` | Section 7.1 reports a B = 2, R = 6 BFS with 45 states. The committed `waves.json` is B = 3, R = 5, 38 states, waves 1, 1, 2, 4, 9, 21. The B = 2 column agrees with the paper's own formula (K6 gives 1, 1, 2, 3, 7, 11, 20), but no stored artifact holds that BFS, so its "Match? Yes" column has no receipt. | A replay of `evidence.py --check` passes while the table cites a run that is not in the package. | Either store the B = 2 run or restate the table from `waves.json`; table-to-receipt test. |
| N5 | low | `N/10-swap-as-change/derivation/paper.md:25` | The prior wave discrepancy now has an independent check: the bounded ninth count is 1, 3, 7, 24 (K5), equal to the stored vector, not the quoted one. | As in the baseline. | As in the baseline P0 row. |
| N6 | low | `N/06-written-budget/derivation/paper.md:218` | "wave 6 has 402 states"; the ninth paper (`ninth/paper.md:694`) and K5 give 420. | A transcription error propagates into comparisons. | Cite the ninth layer list from the ninth evidence file. |
| N7 | low | `N/06-written-budget/derivation/paper.md:5` | Defines **derived** as "proved by Lean or exhaustive bounded check", which merges derived with computed, against bookkeeping rule 1 in the subtree `CLAUDE.md`. | A bounded census is read as a derivation. | Restore the subtree's status definitions and re-tag rows whose only evidence is a census. |
| N8 | low | `N/02-relation-cross-guard/derivation/paper.md:139-146,272`; `cost.py:33-46` | `tau` is the vertex-cover number of the undirected support of the shared pairs; any undirected graph arises as such a support, so exact guarded cost is NP-hard to evaluate in general (standard vertex-cover reduction). The paper notes exponential enumeration but not hardness. Not an error; a missing consequence. | A downstream planner assumes the cost is cheap to compute. | State the reduction and a polynomial bound only for bounded `tau` or special supports. |
| N9 | low | `omega_engine_atlas/coda_atlas/F004_papers/005_mind_and_consciousness/000_google_hope/hope_engine.py:42` | The comment `(ma - c)/(E + b) >= 0` needs `E + b > 0`. With `f1 = (1, r)`, `f2 = (1, -r)`, `r^2 = 3/2`, `psi = -(f1+f2)/2`, `E = 1`: `ma - c = 6`, `E + b = -1`, delta `-6` (K6). | Code or text that relies on the sign misorders the two scales. | Add the premise to the comment and a test with `E + b < 0`. |
| N10 | medium | Cross-cutting: M01, M02, M03, M08, M10 | The table-to-receipt consistency test added for M04 in batch 05 was not extended to the sibling meta packages. Five of ten meta manuscripts carry tables not backed by their committed evidence. | Future repairs keep regenerating byte-identical evidence while the prose stays stale. | One shared checker over all ten `paper.md` files and their evidence JSON, run in each package's test file. |

### Slice grades (derivation quality)

No slice grade was recorded in this file on 2026-10-18, so there is no prior grade to move from.

| Family | Papers read | Grade | Rationale |
|---|---|---|---|
| Serial chain (25) | Changed: none. Re-read for derivations: main D1-D12, twentythird D1-D7, twentyfifth D1-D8, sixteenth C-R1 to D8; others via baseline anchors | B+ | Written proofs coherent and checkable; all recomputations here agree; Lean covers fixed writings, with writing transport (O3) and general criteria written only. |
| Meta next ten (10) | M02 and M04 in full; M06 sections 0-8; M01, M03, M08 tables and claims; M05, M07, M09, M10 numeric claims | C | Two real repairs (M02 now has a sound general theorem). Five tables disagree with stored evidence, and Lean models are aggregates without transport. |
| Mind and consciousness (3) | C01 formulas and code header; C02 sections 3-9; C03 not re-read beyond anchors | C- | C01 algebra holds; C02's DAG and locator claims stay unsupported; C03 is a controlled review edition. |
| RSI (1) | Lines 115-120, 200-280; Lean anchors 214-731; harness 1895-1906 | C+ | Base counting theorem sound; scope failures unchanged. |
| Overall | 39 texts | B- | Strong serial core; meta evidence custody is the main reliability gap. |

### Next projects

| Project | Acceptance evidence |
|---|---|
| Meta table-to-receipt checker | One test module parses every quoted count in the ten meta `paper.md` files and compares it with the package's evidence JSON; it fails on the current M01, M02, M03, M08 and M10 text and passes after correction; a one-digit and a round-swap mutation both turn it red. |
| Lean set-raising descent and rank criterion | Lean statements for twentythird D5(c) and twentyfifth D7 for all `n`, axiom report captured; K3/K4 retained as bounded negative controls. |
| M02 formal cost transport | Lean `n + m + 2*tau` lower and upper bounds and the peak law on the guarded list carrier, plus a representation lemma from the Python `DState`; the existing 271-target census replays unchanged. |

### Inspected-path register

| Path | Depth |
|---|---|
| `N/02-relation-cross-guard/derivation/paper.md` | All 272 lines |
| `N/02-relation-cross-guard/derivation/cost.py` | All 125 lines |
| `N/02-relation-cross-guard/derivation/{claim_ledger,resolution,adversarial_audit}.md` | Grep for counts and inflation claims |
| `N/02-relation-cross-guard/derivation/evidence/*.json`; `model.py:271-301`; `test_derivation.py:1-40,293-354` | Fields compared; functions read |
| `N/04-written-refusal/derivation/paper.md`, `Derivation.lean` | Full diff since the pin; paper lines 50-90; Lean declaration list and lines 229-312 |
| `N/04-written-refusal/derivation/evidence/summary.json`, `claim_ledger.md`, `change_log.md` | Fields compared; grep |
| `N/01`, `N/03`, `N/05`, `N/06`, `N/07`, `N/08`, `N/09`, `N/10` paper and evidence | M06 lines 1-269; M01 lines 120-160; M03 lines 118-150; M08 lines 120-154; others numeric claims by grep and K8 |
| `G/paper/paper.md` | Lines 150-320 |
| `G/paper/twentythird/paper.md` | Lines 230-420 |
| `G/paper/twentyfifth/paper.md` | Lines 270-430 |
| `G/paper/sixteenth/paper.md` | Lines 137-360 |
| `G/paper/ninth/paper.md` | Line 694 only |
| Other serial manuscripts | Anchors only (grep); unchanged bytes |
| `G/AGENTS.md`, `G/CLAUDE.md`, `G/pyproject.toml` | Full; first 150 lines; pytest section |
| `005_mind_and_consciousness/000_google_hope/{google_hope.md,hope_engine.py}` | Grep plus lines 120-165 and 40-110 |
| `005_mind_and_consciousness/001_awareness_mind_consciousness/what_is_awareness.md` | Lines 16-26, 60-101 |
| `012_rsi/.../relational_reasoning_and_rsi_impossibility_monograph.md`; `lean4/RelationalRsiNoGo.lean`; `code/rsi_transition_harness.py` | Grep hits; Lean 225-230 and declaration lines; harness 1895-1906 |
| `omega_engine_product_planning_office/plans/review_remediation/batch_05.md`, `batch_07.md`, `batch_07_checks.json` | Batch text read; checks JSON first 2.5 KB |

Baseline vocabulary was adjusted in ten places so the file passes the forbidden-word scan (for example, a listed verb became "establishes"); no baseline claim, status or number changed.

## 2026-10-18 baseline (historical)

Source snapshot: `000ee9b0c234eda74340e424d6cfb3f6ec001df7`, reviewed 2026-10-18. AuthorityEffect: None.

## Reading and evidence boundary

This register covers 25 serial manuscripts (the main paper and second through twentyfifth), ten additional `meta/next_ten/*/derivation/paper.md` manuscripts, three mind/consciousness texts, and one RSI monograph: **39 distinct manuscript texts**. PDF/TeX renderings, prompts, ledgers, changelogs, and evidence files are supporting assets, not additional manuscripts. Sections below distinguish a written derivation, a source-visible Lean statement, an archived computed assertion, and an independently executed check. This review reads central statements, assumptions, proof arguments, selected formal definitions, and evidence discrepancies; it does not claim that every prose line or every proof term was audited.

No `lake`, build, provider, model, or research test suite was run. No archived PASS, test total, or axiom report is promoted to a fresh verification result. Bibliographies were not externally verified. The local `AGENTS.md` points to `CLAUDE.md`; its given/chosen/derived/computed/refuted/open distinction is used here. A definitional theorem is evidence of the definition, not evidence that the chosen model is necessary in nature.

In source links below, **G** denotes the ongoing package, rooted at [001_genesis_ongoing_h3v7n5qf](../../omega_engine_atlas/coda_atlas/F004_papers/001_finite_obstruction_calculus/001_genesis_ongoing_h3v7n5qf/). Paths following G are relative to that package. The mathematical objects are finite relational states and explicitly selected transition systems. None of these papers derives physical quantum mechanics, experience, or general agent capability only by enumerating them.

## Cross-paper dependency map

| Branch | Input change | Principal mathematical output | Transport condition |
|---|---|---|---|
| Main -> second -> third | Delete removal, then global identification | Carrying-map persistence, then containment and unique path length | Restrict earlier results to the new step relation |
| Third -> fourth -> fifth -> sixth | Count assertions; restore removal/identification; permit loops | Counted cost, reversible components, revised lost-given term | Support projection forgets counted costs |
| Sixth -> seventh and eighth -> ninth | Empty beginning; second relation; both changes | Cost equals size; shared-term reachability; diagonal permutation action | Terms count once; one permutation acts on both relations |
| Ninth -> tenth through fifteenth | Add external record interpretations | Inert annotations preserve dynamics; tagged alternatives can change cost | Excluding a record from state is a choice |
| Ninth/fourteenth -> sixteenth | Consumable leftovers feed back | Potential = size + twice record; mass obstruction | Record enters state, canonicalization, and transitions together |
| Main -> seventeenth through twentyfirst | Alter obstruction, writing, identification, order, response | Controlled countermodels to main-seed assumptions | These are siblings of main |
| Ninth -> twentysecond -> twentythird | Cancel paired relations; quotient by raising | Signed excess, integer gauge classes and minimum L1 cost | Term addition fails to descend to gauge classes |
| Twentythird -> twentyfourth / twentyfifth | Fill vertices / oriented distinct triples | Incomplete vertex detector; triple rank and blind-space classification | Filled-set transport and detector adequacy are separate |
| Meta problems 01-10 | One seed edit per problem | Boundary cases below | Some Lean models retain only aggregate metrics |

## Serial manuscript review

### 01. Main: four changes with no self-loop

Manuscript: [G/paper/paper.md](../../omega_engine_atlas/coda_atlas/F004_papers/001_finite_obstruction_calculus/001_genesis_ongoing_h3v7n5qf/paper/paper.md), especially lines 157-313.

**Derived.** For finite simple directed states, legal means no `xrx`; removal, term/assertion addition, and legal identification are the four changes. The paper establishes obstruction criteria, legal nonempty reachability, and shortest cost `size - size(given) + 2*lost`. The lower bound is a one-step potential bound; the upper bound removes missing givens, merges names if needed, and adds the target. FREE and ANCHORED sameness remain separate choices. Bounded enumeration is supplemented by an orbit count.

**Wrong or limited.** No contradiction in the inspected central cost proof was established. Its Lean upper bound fixes name placement; the rewriting bridge is a written proof, explicitly open in Lean. D11's Lean `build_needs_term_and_assertion` lacks build well-formedness, so it does not establish that the newly mentioned term belongs to the build (lines 280-292). One-state testing of `3*2^d` builds is not completeness of all builds.

**Remaining.** Formalize equivariance for all four changes and arbitrary writing, sequence-level obstruction persistence, and well-formed build minimality/completeness. Source anchors: G/`lean4/H3V7N5QF/Cost.lean` `fewest_changes_lower_A/B` (348/354); `Paths.lean` `fewest_changes_A/B` (247/254); `Answers.lean` build lemmas. Code: G/`code/xry/{changes,cost,orbits,explore}.py`.

### 02. Second: removal deleted

Manuscript: [G/paper/second/paper.md](../../omega_engine_atlas/coda_atlas/F004_papers/001_finite_obstruction_calculus/001_genesis_ongoing_h3v7n5qf/paper/second/paper.md), lines 214-377.

**Derived.** Every allowed step carries assertions through a term map. Givens and images of obstructions persist. Reachable states contain an image of the seed; shortest cost collapses to size difference. Arbitrary-state reachability is characterized on paper by a carrying map; the construction merges fibers then adds missing data. Pulling back a proper split establishes monotonicity of required class count.

**Wrong or limited.** General carrying-map sufficiency is not fully a Lean theorem: the fiber-identification phase is written at lines 331-346. Small-bound backtracking/BFS agreement cannot establish all-finite sufficiency by itself.

**Remaining.** Formalize fiber collapse and arbitrary-state reachability; preserve source-vs-result equivariance. G/`lean4/Second/{Step,Rename,Cost,Reach}.lean`: `Reach3.carries`, `Reach3.obstruction_persists`, `fewest_changes3_every_writing_A/B`; G/`code/second/reach.py`.

### 03. Third: additions only

Manuscript: [G/paper/third/paper.md](../../omega_engine_atlas/coda_atlas/F004_papers/001_finite_obstruction_calculus/001_genesis_ongoing_h3v7n5qf/paper/third/paper.md), lines 251-442.

**Derived.** Each step adds exactly one term or assertion. Containment composes, size increases by one, and every path between fixed endpoints has the size-difference length. Reachability is containment, or containment of a writing under the selected quotient; it is antisymmetric.

**Wrong or limited.** The theorem is conditional on excluding deletion and identification; it does not prove that exclusion necessary. Quotient sequence counts depend on what is counted as a distinct move/history; they are not automatically labeled-history counts. No central contradiction established.

**Remaining.** General shortest-sequence formulas and an explicit quotient-history counting contract. G/`lean4/Third/`: `Step2.contains`, `Reach2.length_unique`, `reach2_iff`; G/`code/third/{explore,reach}.py`.

### 04. Fourth: multiplicities with additions only

Manuscript: [G/paper/fourth/paper.md](../../omega_engine_atlas/coda_atlas/F004_papers/001_finite_obstruction_calculus/001_genesis_ongoing_h3v7n5qf/paper/fourth/paper.md), lines 287-527.

**Derived.** Replace Boolean assertions by nonnegative integer multiplicities. Pointwise containment and exact size growth survive; cost counts total multiplicity. Two-term history counts become binomial; a term bound alone no longer makes the count finite. `reach4_iff` compares multiplicities, not just supports.

**Wrong or limited.** Support equivalence cannot justify counted reachability/cost. No central proof defect established. The ledger records an earlier third-evidence regeneration stopped for memory; this review does not close that historical custody gap.

**Remaining.** Formal orbit-series completeness/counts, general sequence counts, and separately planned replay of missing historical checks. G/`lean4/Fourth/Cost.lean` `fewest_changes4_lower_A/B` (77/83), `reach4_iff` (213); `Compare.lean` `reach4_iff_reach2` (38); G/`code/fourth/orbits.py`.

### 05. Fifth: counted assertions, removal and identification restored

Manuscript: [G/paper/fifth/paper.md](../../omega_engine_atlas/coda_atlas/F004_papers/001_finite_obstruction_calculus/001_genesis_ongoing_h3v7n5qf/paper/fifth/paper.md), lines 281-566.

**Derived.** Legal identifications sum multiplicities; removal lowers one count. The lost-given potential yields exact cost; all legal nonempty states are reachable. ANCHORED states form two mutually reachable components ordered by irreversible name merge. FREE nonempty states communicate. Two-change cycles destroy additions-only length uniqueness.

**Wrong or limited.** Sum-on-merge is chosen; maximum-on-merge is analyzed separately. Fourth-step embedding does not transfer all-quantified statements about all fifth steps backwards. No central contradiction established.

**Remaining.** Formal alternate-merge comparisons and general shortest-history formulas; retain legality/WF/name premises at API boundaries. G/`lean4/Fifth/Cost.lean` `fewest_changes5_A/B` (405/563); `Reach.lean` `reach5_iff` (304); G/`code/fifth/{cost,reach}.py`.

### 06. Sixth: loops permitted

Manuscript: [G/paper/sixth/paper.md](../../omega_engine_atlas/coda_atlas/F004_papers/001_finite_obstruction_calculus/001_genesis_ongoing_h3v7n5qf/paper/sixth/paper.md), lines 249-549.

**Derived.** Removing the ban changes the merged-name lost-given contribution to account for surviving loop multiplicity. Revised potential gives exact cost to every well-formed nonempty counted state; the name-merge reachability criterion remains. A witness refutes the old remove-before/after identity without loop-freeness.

**Wrong or limited.** Obstruction disappears because the seed permits all outcomes; no independent necessity is established. Reusing fifth cost on loopy merged states would be wrong; this paper explicitly repairs it.

**Remaining.** Stated non-Lean count/alternate-reading proofs and general sequence formulas. G/`lean4/Sixth/`: `lostA6`, `fewest_changes6_A/B`, `reach6_iff`, `first_or_last_fails`; G/`code/sixth/{cost,reach}.py`.

### 07. Seventh: empty beginning, one relation

Manuscript: [G/paper/seventh/paper.md](../../omega_engine_atlas/coda_atlas/F004_papers/001_finite_obstruction_calculus/001_genesis_ongoing_h3v7n5qf/paper/seventh/paper.md), lines 194-435.

**Derived.** Every finite well-formed counted one-relation state is reached from empty at cost `size`. The first change adds a term; nonempty states never reach empty because no operation removes the last term. All nonempty states communicate. FREE/ANCHORED distinction disappears without names.

**Wrong or limited.** "Nothing about asserting holds in every result" must mean the listed tested statements, not all propositions: well-formedness and tautologies still hold. The paper qualifies this with its list. No central proof defect established.

**Remaining.** Formal bounded completeness/count and sameness-reading coincidence; general sequence formulas. G/`lean4/Seventh/`: `fewest_changes7_lower`, `reach7_iff`, `no_cycle_at_empty`; G/`code/seventh/orbits.py`.

### 08. Eighth: two relations with an initial r assertion

Manuscript: [G/paper/eighth/paper.md](../../omega_engine_atlas/coda_atlas/F004_papers/001_finite_obstruction_calculus/001_genesis_ongoing_h3v7n5qf/paper/eighth/paper.md), lines 268-482.

**Derived.** On shared terms/names the state set is jointly free in two relation functions. Cost is sixth's r cost plus s total; terms count once. A shared permutation means orbit counts are not products of single-relation counts. Reachability reads the shared name-merge condition.

**Wrong or limited.** Independence here is freely choosing functions on the same carrier, not statistical independence or separate gauges. Multiplying orbit counts or adding both parts' full costs would double-count shared structure.

**Remaining.** Formal non-product counts, general histories, and costs from a nonempty s beginning. G/`lean4/Eighth/Cost.lean` `costA8_eq` (49), `fewest_changes8_A/B` (265/275); `Reach.lean` `reach8_iff_r` (84); G/`code/eighth/orbits.py`.

### 09. Ninth: two relations from empty

Manuscript: [G/paper/ninth/paper.md](../../omega_engine_atlas/coda_atlas/F004_papers/001_finite_obstruction_calculus/001_genesis_ongoing_h3v7n5qf/paper/ninth/paper.md), lines 232-556.

**Derived.** Empty-source cost is terms plus both totals; nonempty states communicate and empty is not re-entered. Exchange is a symmetry. Part costs cannot be summed because each counts shared terms. One-term shortest-history counts are binomial.

**Wrong or limited.** This permissive multigraph grammar does not yield unique dynamics, a probability law, or a Hilbert-space reconstruction. No central defect established in inspected size/reachability arguments.

**Remaining.** Formal count completeness and general history formulas. G/`lean4/Ninth/`: `fewest_changes9`, `reach9_iff`, `cost_not_sum_of_parts9`; G/`code/ninth/{explore,orbits}.py`.

### 10. Tenth: leftover as change annotation

Manuscript: [G/paper/tenth/paper.md](../../omega_engine_atlas/coda_atlas/F004_papers/001_finite_obstruction_calculus/001_genesis_ongoing_h3v7n5qf/paper/tenth/paper.md), lines 80-182.

**Derived.** Under C-L1 the record annotates an incoming change; states remain ninth states. Removal is one-step restorable. Identification is one-step restorable up to writing iff at least one merged term is bare; the proof compares term and bare-term counts. Inert annotation leaves reachability/cost unchanged.

**Wrong or limited.** Wrapper comparison is identity, not independent validation; the paper says so. `tagged_cost_fails` supplies a length-three route, not a lower bound. The bare criterion is written/computed, not Lean.

**Remaining.** Formal bare criterion, exchange identity for identification records, and tagged lower bounds. G/`lean4/Tenth/`; G/`code/tenth/invariants.py` `bare_criterion`, `restores_in_one`.

### 11. Eleventh: colliding writing without merging terms

Manuscript: [G/paper/eleventh/paper.md](../../omega_engine_atlas/coda_atlas/F004_papers/001_finite_obstruction_calculus/001_genesis_ongoing_h3v7n5qf/paper/eleventh/paper.md), lines 76-189.

**Derived.** Under rectangle-constant recoverability, injective writings determine assertions and failure persists under coarsening. One relation can be readable while the other is not. A writing does not identify the terms.

**Wrong or limited.** This recoverability reading is stronger than the seed's converse and is chosen. `labeled_extra` distinguishes raw functions, not label orbits; the manuscript correctly calls it illustration. A past symmetric-overcount defect is reported corrected, not replayed here.

**Remaining.** Formal labeled orbit objects and a complete interpretation register. G/`lean4/Eleventh/Compare.lean` `fewest_changes11` (15), `reach11_iff` (19); G/`code/eleventh/` labeled/Burnside comparison.

### 12. Twelfth: per-relation identification record

Manuscript: [G/paper/twelfth/paper.md](../../omega_engine_atlas/coda_atlas/F004_papers/001_finite_obstruction_calculus/001_genesis_ongoing_h3v7n5qf/paper/twelfth/paper.md), lines 78-176.

**Derived.** The chosen record lists pre-merge local incidences per relation; records can differ. An empty record for isolated terms is restorable by adding one term. Tagged history distinguishes identical underlying ninth states.

**Wrong or limited.** Relation-local determination is by construction of `recordRel`. `recorded_cost_is_size` is underlying-size equality, not BFS shortest cost. The source explicitly notes these limitations.

**Remaining.** Formal recorded quotient/history and exact tagged costs; general restoration classification. G/`lean4/Twelfth/`; G/`code/twelfth/` recorded exploration.

### 13. Thirteenth: forget relation labels by summing

Manuscript: [G/paper/thirteenth/paper.md](../../omega_engine_atlas/coda_atlas/F004_papers/001_finite_obstruction_calculus/001_genesis_ongoing_h3v7n5qf/paper/thirteenth/paper.md), lines 79-174.

**Derived.** Coarsening takes `M_r+M_s`. Fixed-writing split count is the product of `(N(pair)+1)`; uniqueness means no assertion. Size and term-based reachability descend. Taking coarse states as results yields seventh's one-relation quotient.

**Wrong or limited.** The split product does not count isomorphism classes automatically; the paper distinguishes them. Wrapper comparisons are construction checks. No central contradiction established.

**Remaining.** Orbit-aware fiber formalization and quotient change-lifting. G/`lean4/Thirteenth/`: `size_coarse`, `coarse_has_term`; G/`code/thirteenth/`.

### 14. Fourteenth: leftover writing is neither assertion nor answer

Manuscript: [G/paper/fourteenth/paper.md](../../omega_engine_atlas/coda_atlas/F004_papers/001_finite_obstruction_calculus/001_genesis_ongoing_h3v7n5qf/paper/fourteenth/paper.md), lines 78-175.

**Derived.** Chosen types give relation-free removal pair tags and merge tags. Inert tags leave ninth states; putting tags in results changes costs/counts. State and tag require joint canonicalization.

**Wrong or limited.** `leftover_not_answer` is excluded middle (`L = nothing or L != nothing`), not the claimed semantic distinction. Projection `rfl` equalities do not mention leftover. This is a statement/content mismatch already acknowledged by the manuscript, not proof-kernel failure. The former tag-canonicalization bug is reported fixed.

**Remaining.** Replace weakly named tautologies with actual typed claims; formal tagged quotient and lower bounds. G/`lean4/Fourteenth/`; G/`code/fourteenth/` `canonical_tagged`.

### 15. Fifteenth: reaching versus admission

Manuscript: [G/paper/fifteenth/paper.md](../../omega_engine_atlas/coda_atlas/F004_papers/001_finite_obstruction_calculus/001_genesis_ongoing_h3v7n5qf/paper/fifteenth/paper.md), lines 76-176.

**Derived.** A chosen external flag separates reaching from recording admission. Inert reading preserves ninth costs; tagged reading adds admitted copies and increases some shortest costs.

**Wrong or limited.** `admission_not_a_kind` is `reaching = notAdmitted`; `no_cross_constraint` contains projection equalities rather than noninterference. `every_reached_can_be_admitted` is an alternate-model constructor, not an entailment from reachedness. The source discloses this. Admission availability is chosen.

**Remaining.** Nontrivial admissibility, explicit authority owner, typed noninterference, tagged lower bounds. G/`lean4/Fifteenth/`; G/`code/fifteenth/` admission/tag logic.

### 16. Sixteenth: consumable recorded leftovers

Manuscript: [G/paper/sixteenth/paper.md](../../omega_engine_atlas/coda_atlas/F004_papers/001_finite_obstruction_calculus/001_genesis_ongoing_h3v7n5qf/paper/sixteenth/paper.md), lines 137-355.

**Derived.** Counted pair-records enter state. Removal transfers assertion to leftover; admission transfers it back, possibly into the other relation. Potential `size+2*record` gives exact empty-source cost. Mass never falls. Feedback cycles do not terminate. The carry-map criterion refines total/diagonal mass tests.

**Wrong or limited.** General criterion sufficiency is written/computed, not formalized. Total mass monotonicity alone is weaker. Consumable records are selected semantics. "Reachability ... one-way again" must not mean antisymmetry: the section also reports mutual pairs and cycles.

**Remaining.** Formal pairwise pushforward necessity/sufficiency and diagonal invariant; general history counts. G/`lean4/Sixteenth/`: `fewest_changes16`, `no_fall_on_shortest16`, `Reach16.mass_le`; G/`code/sixteenth/reach.py` `carries`.

### 17. Seventeenth: no explicit loop ban, obstruction retained

Manuscript: [G/paper/seventeenth/paper.md](../../omega_engine_atlas/coda_atlas/F004_papers/001_finite_obstruction_calculus/001_genesis_ongoing_h3v7n5qf/paper/seventeenth/paper.md), lines 116-244.

**Derived.** M1 tests newly created loops, M2 any outcome loop. They agree on loop-free inputs and differ on loopy ones. Refusal preserves loop-freeness; performing obstructed steps immediately refutes old cost. This separates refusal's effect from an explicit ban.

**Wrong or limited.** The implication needs A-replace and a loop-free start; it fails under A-perform. The paper retains both and declares a smaller actual bound than its plan. No central contradiction established.

**Remaining.** Arbitrary-writing formalization and larger alternative-reading dynamics. G/`lean4/Seventeenth/`: `m1_iff_m2_of_loopFree`, `Reach17.loopFree`, `cost_not_lower_bound_A/B`; G/`code/seventeenth/`.

### 18. Eighteenth: written identity

Manuscript: [G/paper/eighteenth/paper.md](../../omega_engine_atlas/coda_atlas/F004_papers/001_finite_obstruction_calculus/001_genesis_ongoing_h3v7n5qf/paper/eighteenth/paper.md), read in full.

**Derived.** Literal writing refines the quotient: bounded named/nameless closures have 137/69 written states versus 109/20 base classes. Named cost retains the old potential; nameless least-over-writings cost may strictly underbound a particular reached writing. Infinite free spellings are an unchosen alternative.

**Wrong or limited.** Detours beyond three terms might shorten nameless written paths; this is explicitly unresolved. Finite counts rely on next-index allocation, not term count alone.

**Remaining.** Nameless detour question and general written-state counts; specify allocation in reusable APIs. G/`lean4/Eighteenth/Writing.lean` `swapped_ne_given`; G/`code/eighteenth/`; manuscript O2, lines 135-142.

### 19. Nineteenth: local one-assertion identification

Manuscript: [G/paper/nineteenth/paper.md](../../omega_engine_atlas/coda_atlas/F004_papers/001_finite_obstruction_calculus/001_genesis_ongoing_h3v7n5qf/paper/nineteenth/paper.md), read in full.

**Derived.** Rewriting one assertion keeps terms. Term-count monotonicity excludes base one-term and merged-name states. Three-term closure has 68 named/19 nameless states. Restricting rewrites to a pair already naming both terms produces only refused loop attempts and the same bounded result set.

**Wrong or limited.** This does not implement global identification by iteration. Counts/rounds are computed, not general formulas.

**Remaining.** General reachability/counts for local rewrites. G/`lean4/Nineteenth/Partial.lean`: `performPartial_terms`, `PReach.card_ge`, `oneTerm_unreachable`; G/`code/nineteenth/`.

### 20. Twentieth: order by total changes

Manuscript: [G/paper/twentieth/paper.md](../../omega_engine_atlas/coda_atlas/F004_papers/001_finite_obstruction_calculus/001_genesis_ongoing_h3v7n5qf/paper/twentieth/paper.md), read in full.

**Derived.** Attempt order within BFS waves changes neither closure nor first-discovery round. Globally ranking states by additions changes a budget-limited frontier. The text corrects unequal 12/11-versus-four expansion budgets with a matched four-expansion comparison. Net additions are not distance.

**Wrong or limited.** Unequal-budget comparisons cannot measure ordering effects; the paper says so and supplies the matched case. No blanket efficiency advantage follows.

**Remaining.** Reusable matched-budget scheduler benchmark with work counts and deterministic tie-breaking. G/`lean4/Twentieth/Order.lean` `additions_diverge`; G/`code/twentieth/`.

### 21. Twentyfirst: refusal only

Manuscript: [G/paper/twentyfirst/paper.md](../../omega_engine_atlas/coda_atlas/F004_papers/001_finite_obstruction_calculus/001_genesis_ongoing_h3v7n5qf/paper/twentyfirst/paper.md), read in full.

**Derived.** Removing answer records leaves results already reachable by unobstructed primitive steps. A separately implemented refusal exploration matches bounded base closure/rounds. Refusal does not stop unrelated legal steps; term addition prevents global termination.

**Wrong or limited.** Reachable-set equality does not imply equal histories, attempt work, or explanatory utility. Build redundancy is relative to this grammar/result semantics.

**Remaining.** All-finite step correspondence plus explicit reachability/work/explanation metrics. G/`lean4/Twentyfirst/Refusal.lean`: `identify_given_refused`, `refusal_continues_by_a_term`; G/`code/twentyfirst/` `explore_refusing`.

### 22. Twentysecond: cancellation quotient

Manuscript: [G/paper/twentysecond/paper.md](../../omega_engine_atlas/coda_atlas/F004_papers/001_finite_obstruction_calculus/001_genesis_ongoing_h3v7n5qf/paper/twentysecond/paper.md), lines 220-494.

**Derived.** Canceling co-located r/s pairs leaves integer excess. Generated sameness equals excess equality plus rewriting. Dynamics respect it under sum identification. Cost is `n+sum|e|`; paired additions undo at result level. Seventh embeds; ninth does not inject. Maximum-on-merge loses representative-independent transitions.

**Wrong or limited.** Alternate C-J3 with arbitrary representatives has infinite round-three outcomes. The finite restricted exploration cannot certify unrestricted C-X. No central defect established in signed-excess proof.

**Remaining.** Formal counts, general histories, explicit selector distinguishing C-X from C-X-prime. G/`lean4_core/Twentysecond/`: `gen_iff_same`, `same_iff_excess`, `step_of_same`; `Cost.lean` `fewest_changes` (112), `Reach.lean` `reach_criterion` (61); G/`code/twentysecond/orbits.py`.

### 23. Twentythird: raising/gauge quotient

Manuscript: [G/paper/twentythird/paper.md](../../omega_engine_atlas/coda_atlas/F004_papers/001_finite_obstruction_calculus/001_genesis_ongoing_h3v7n5qf/paper/twentythird/paper.md), lines 238-546.

**Derived.** Sameness is `e_G=e_H+g(x)-g(y)` on a finite carrier. Loops, two-way sums, and triangles detect the zero class. Cost is minimum integer-gauge L1 excess plus `n`. The paper gives a three-term closed form and all-subset descent argument; checking only single terms fails at four terms. Read-back need not be unique.

**Wrong or limited.** Term addition is not a function on classes: equivalent two-term representatives yield inequivalent three-term outputs. Merge also fails beyond stated small-carrier scope. This is a proved limitation, not an error in equivalence. `Cost3` measures actual written `Reach` to a representative; it does not license free representative switches between paid steps. A runtime treating classes as a congruent transition system would be unsound.

**Remaining.** Formal subset optimality, three-term formula, general duality, and operational representative custody. G/`lean4_core/Twentythird/Cost.lean` `Cost3` (36), `cost3_iff`, `adding_a_term_raises_the_cost`; `Reach.lean` `ReachR3` (24); G/`code/twentythird/state.py` `result_key`.

### 24. Twentyfourth: filled vertices

Manuscript: [G/paper/twentyfourth/paper.md](../../omega_engine_atlas/coda_atlas/F004_papers/001_finite_obstruction_calculus/001_genesis_ongoing_h3v7n5qf/paper/twentyfourth/paper.md), lines 239-484.

**Derived.** Fillings decorate the gauge quotient; a filled vertex balances iff its loop excess vanishes. The detector sees filled nonzero loops and misses nonzero pair/triangle classes even when every vertex is filled. Cost adds filling count. OR-on-merge preserves existence of a filling and adds a reachability barrier; alternatives remove it.

**Wrong or limited.** Vertex-detector completeness is false; explicit counterexamples are provided. Cost-change parity fails when two filled vertices merge. Balance invariance does not imply detector adequacy.

**Remaining.** Formal alternative transport criteria, count proofs, and complete observer bundles. G/`lean4_core/Twentyfourth/`: `never_told_of_loops_zero`, `identify_two_filled_even`, `Cost.lean` `cost24_eq` (139), `reach24_criterion`; G/`code/twentyfourth/`.

### 25. Twentyfifth: filled oriented triples

Manuscript: [G/paper/twentyfifth/paper.md](../../omega_engine_atlas/coda_atlas/F004_papers/001_finite_obstruction_calculus/001_genesis_ongoing_h3v7n5qf/paper/twentyfifth/paper.md), lines 275-556.

**Derived.** Filled distinct oriented triples report invariant cycle sums, but loops are invisible. Blind spaces have two extra non-loop directions at three/four terms; at five or more zero triangle sums force zero pair sums, leaving loops only. With loops/pair sums zero, deciding sets have rank `choose(n-1,2)`; the written proof uses rational rank and integer scaling. Cost adds triple count; dropping degenerate triples recovers nonempty mutual reachability.

**Wrong or limited.** Arbitrary triples are not complete detectors without loop/pair premises. General rank and four-term blind converse remain written/computed rather than Lean. Keeping degenerate triples changes cost and reachability.

**Remaining.** Formal rank criterion/integer witnesses; deciding sets for six or more terms; complete loop/pair/triple certificates. G/`lean4_core/Twentyfifth/Blind.lean` `blind_twoWay_five` (70), `blind_five` (98); `Cost.lean` `cost25_eq` (114); `Reach.lean` `reach25_criterion` (83); G/`code/twentyfifth/`.

## Ten additional derivation manuscripts

Each item below has its own `paper.md`, `Derivation.lean`, Python model/evidence, ledger, and audit material under G/`meta/next_ten/`. The existence of these companions is not fresh execution evidence. The Lean models are not uniformly the parent paper's types: several reimplement a smaller carrier. Transport to the parent must be proved rather than inferred from similar names.

### M01. Remove a bare term

Manuscript: [01-remove-bare-term/derivation/paper.md](../../omega_engine_atlas/coda_atlas/F004_papers/001_finite_obstruction_calculus/001_genesis_ongoing_h3v7n5qf/meta/next_ten/01-remove-bare-term/derivation/paper.md).

**Derived.** Adding a bare-term removal closes the empty-to-one-term two-step cycle. Removing assertions first and then bare terms gives a written route from every finite state to empty; additions give the reverse. Size still bounds empty-source shortest cost. This refutes the proposed empty-state irreversibility falsifier.

**Wrong or limited.** The Lean file establishes the concrete cycle and positive in-degree (`two_step_cycle`, `empty_returns_in_two_steps`, lines 196-205), not the full general strong-connectivity/cost theorem. Membership is correctly included inside `isBare` (`t < s.n` at line 34), so no absent-index defect is established. General connectivity is a written remove-all/add-all argument, not a theorem obtained only from the concrete cycle.

**Remaining.** Formalize assertion-total preservation, arbitrary clear/remove/add paths, and exact size cost in the full carrier. Source: G/`meta/next_ten/01-remove-bare-term/derivation/Derivation.lean`, `isBare` (33), `removeBare` (49), `Step.removeBareTerm` (171), cycle (196).

### M02. Cross-relation guard

Manuscript: [02-relation-cross-guard/derivation/paper.md](../../omega_engine_atlas/coda_atlas/F004_papers/001_finite_obstruction_calculus/001_genesis_ongoing_h3v7n5qf/meta/next_ten/02-relation-cross-guard/derivation/paper.md).

**Derived.** Guarded additions preserve disjoint r/s support; identification can bypass the guard. A one-term state with both loop relations needs the displayed two-term route rather than pure additions. For the specific two-term *off-diagonal* overlap witness, an intermediate third term is necessary: merging within two terms can only produce one-term overlap, which later term additions cannot turn into an off-diagonal pair.

**Wrong or limited.** The notion-table claim that overlapping targets on `n >= 2` terms generally require `n+1` intermediate terms is too broad. Counterexample: add two terms, add `0r0` and `1s1`, identify them, then add a bare term. The final two-term state has both relations on its surviving loop; the route never exceeded two terms. This written six-step witness refutes the generalization, while leaving the narrower off-diagonal witness intact. Section 4 also labels the one-term above-bound witness as a "holds" example for an at-most-target-bound claim, although it violates that bound.

**Remaining.** Classify precisely which overlap patterns need term inflation, prove lower bounds with carrier membership, and give exact shortest-cost formulas. Source: G/`meta/next_ten/02-relation-cross-guard/derivation/Derivation.lean`, `reach_add_preserves_disjoint` (212), `overlapping_unreachable_by_additions` (235), `identification_bypasses_guard` (290); manuscript sections 1 and 3.3.

**Current source repair.** [Batch 07](../plans/review_remediation/batch_07.md) supplies written exact cost `n+m+2*tau` and minimum-peak proofs for unnamed natural-multiplicity states, with an admitted construction and independent bounded checks. It corrects the general inflation/witness errors above, malformed removal admission, and the evidence writer's hardcoded Lean-PASS annotation. The existing Lean theorem is one merge; full representation/transition/renaming and general cost/peak transport remain open. This update does not replace the dated review basis.

### M03. A term-adding change already given

Manuscript: [03-given-first-change/derivation/paper.md](../../omega_engine_atlas/coda_atlas/F004_papers/001_finite_obstruction_calculus/001_genesis_ongoing_h3v7n5qf/meta/next_ten/03-given-first-change/derivation/paper.md).

**Derived.** Taking the bare one-term state as round zero excludes empty forever. On nonempty states cost shifts from ninth's `size` to `size-1`; mutual reachability survives. The shift follows from a changed beginning, not a given assertion.

**Wrong or limited.** The source-visible Lean file establishes nonemptiness and empty unreachability (`step_nonempty`, `reach_nonempty`, `empty_not_reachable_from_root03`). The central cost/reachability prose needs its own parent-model transport: the displayed finite census is not a proof of all finite costs. No contradiction established in the written size-minus-one construction.

**Remaining.** Formalize exact upper/lower cost and all-nonempty reachability in the full two-relation carrier, with explicit compatibility with ninth's quotient. Source: G/`meta/next_ten/03-given-first-change/derivation/Derivation.lean`, `root03`, `empty_not_result03`, `root03_size`; `model.py` and `evidence.py` in the same directory.

### M04. Written identity plus refusal

Manuscript: [04-written-refusal/derivation/paper.md](../../omega_engine_atlas/coda_atlas/F004_papers/001_finite_obstruction_calculus/001_genesis_ongoing_h3v7n5qf/meta/next_ten/04-written-refusal/derivation/paper.md).

**Derived.** Refusal adds only identity outcomes to exploration; it does not change the written unobstructed closure or first-discovery waves. Written identity still splits the parent's canonical classes. The proposed dynamic interaction is refuted for this semantics.

**Wrong or limited: confirmed evidence-table defect.** Section 3 copies the `bra=false` wave vector into both `bra=true` rows. The committed [evidence/summary.json](../../omega_engine_atlas/coda_atlas/F004_papers/001_finite_obstruction_calculus/001_genesis_ongoing_h3v7n5qf/meta/next_ten/04-written-refusal/derivation/evidence/summary.json) instead records ANCHORED `bra=true` waves `[1,3,7,16,21,18,13,16,20,15,6,1,0]` and FREE `bra=true` waves `[1,3,7,16,20,15,6,1,0,0,0,0,0]`. The manuscript shows false-case vectors beginning `[1,3,8,...]`. Counts 137/69 remain the same; rounds do not. This discrepancy was established by reading stored bytes, without regeneration.

**Remaining.** Correct those two rows from pinned evidence, add a doc-table-to-receipt consistency check, and formalize closure equivalence rather than only equality reflexivity/legality witnesses. Source: G/`meta/next_ten/04-written-refusal/derivation/Derivation.lean`, `written_step_preserves_legal` (101), `refusal_changes_nothing` (173); `evidence.py` `measure_run` (40-55).

**Repair follow-up, 2026-10-19.** [Batch 05](../plans/review_remediation/batch_05.md) corrects the two manuscript rows and the same copied rows in `resolution.md`. Fresh replay matches stored evidence; both tables now have source-level consistency and mutation checks. New Lean theorems establish closure and first-discovery equivalence for identity extensions of a shared relation, including the bounded list-state model. The Python/Lean representation, admitted-transition, bound-policy and quotient transport obligation remains open. This partial repair does not close the full M04 unit or the wider manuscript review.

### M05. Refusal memory overrides a later obstruction

Manuscript: [05-refusal-memory/derivation/paper.md](../../omega_engine_atlas/coda_atlas/F004_papers/001_finite_obstruction_calculus/001_genesis_ongoing_h3v7n5qf/meta/next_ten/05-refusal-memory/derivation/paper.md).

**Derived.** A result carries refused written changes. First obstruction records; a second matching attempt executes, so loops first arise after two attempts rather than never (A-replace) or immediately (A-perform). Graph and refusal record must be renamed together.

**Wrong or limited.** This changes what counts as a state-changing step: a refusal changes no graph field but does change the result's memory. Equating attempts, performed graph changes, and BFS rounds would hide the extra operation. The record-scope/consumption policy is selected semantics. No contradiction established in the two-attempt witness.

**Remaining.** State the cost unit explicitly, prove equivariance and general record transport through term merges, and formalize the finite census. Source: G/`meta/next_ten/05-refusal-memory/derivation/Derivation.lean`, `two_step_reaches_loop` (167), `rootA_one_step_no_loop` (234); `model.py` `rewrite_refusal_state` (111), `canonical_refusal` (120), `attempt_step` (161).

### M06. Four changes of state-carried budget

Manuscript: [06-written-budget/derivation/paper.md](../../omega_engine_atlas/coda_atlas/F004_papers/001_finite_obstruction_calculus/001_genesis_ongoing_h3v7n5qf/meta/next_ten/06-written-budget/derivation/paper.md).

**Derived.** Budget decreases by one per performed step. Maximum length is four and at budget zero no further performed step exists. Recording budget distinguishes revisited underlying states, producing 46 reported results over levels 1,1,3,9,32. The term cap four is intrinsic to this beginning and budget.

**Wrong or limited.** The notion table calls a zero-budget attempt an identity transition, while formal `BStep.not_step_at_zero` excludes it. These are compatible only if attempts and performed steps are separate relations. `BReach.characterization` (201) is budget equation plus an underlying `State.Reach` premise; it does not itself prove the manuscript's size/parity closed census criterion.

**Remaining.** Prove the full size/parity reachability criterion, formalize the 46-count census, and expose separate attempt/performed-step types. Source: G/`meta/next_ten/06-written-budget/derivation/Derivation.lean`, `BStep.budget_eq` (112), `BReach.four_step_max` (140), `BReach.characterization` (201), `BReach.terms_le` (230).

### M07. Equivalence by two-term readings

Manuscript: [07-two-term-readings/derivation/paper.md](../../omega_engine_atlas/coda_atlas/F004_papers/001_finite_obstruction_calculus/001_genesis_ongoing_h3v7n5qf/meta/next_ten/07-two-term-readings/derivation/paper.md).

**Derived.** Equality of available local record sets is an equivalence. At the declared bound it is coarser than written equality and graph isomorphism (69 -> 20 -> 14 multiset -> 8 set classes). A 2-cycle plus isolated vertex and two joined 2-cycles have equal record sets but differ globally. Deleting an edge shows transition non-congruence.

**Wrong or limited.** The chosen reading compares sets of possible readings, not a shared pointwise naming of every reading; the seed's wording does not force this interpretation. Non-congruence is a real obstruction to treating the eight classes as Markov states. An equivalence proof alone does not authorize quotient dynamics.

**Remaining.** Specify existential/all-successor/representative successor semantics or refine observations until step congruence holds; derive general class counts. Source: G/`meta/next_ten/07-two-term-readings/derivation/Derivation.lean`, `LocalEquiv` (68), `s_A_equiv_s_B` (127), four removal counterexamples (156-175).

### M08. Ordered leftover stack

Manuscript: [08-record-order/derivation/paper.md](../../omega_engine_atlas/coda_atlas/F004_papers/001_finite_obstruction_calculus/001_genesis_ongoing_h3v7n5qf/meta/next_ten/08-record-order/derivation/paper.md).

**Derived.** Keeping arrival order and admitting only the newest unadmitted pair gives a LIFO stack. Two reachable six-step states with records `[(0,0),(0,1)]` and the reverse have equal counts but distinct writing orbits and distinct immediate admissions. Ordered results strictly refine the counted-record model (reported 388 versus 386 at the bound).

**Wrong or limited.** The final comparison asserts a strict computational-power increase and a transition from vector-addition to pushdown reachability. That conclusion is not proved by this witness: the system still contains graph structure, unbounded term allocation and counters, so it is not shown to be an ordinary finite-control pushdown automaton or a pure vector addition system. The Lean file establishes record-list facts, not a full-system expressiveness separation.

**Remaining.** Formal complete state/action transport and projection simulation; qualify the automata analogy or prove encodings and a separation theorem. Source: G/`meta/next_ten/08-record-order/derivation/Derivation.lean`, `toCount` (32), `isAdmissible` (45), `witness_count_eq` (67), `witness_different_admissions` (97).

### M09. A two-step restoration window

Manuscript: [09-two-step-leftover/derivation/paper.md](../../omega_engine_atlas/coda_atlas/F004_papers/001_finite_obstruction_calculus/001_genesis_ongoing_h3v7n5qf/meta/next_ten/09-two-step-leftover/derivation/paper.md).

**Derived.** Each primitive changes size by one. Undoing identification requires size increase one, excluded in exactly two steps by parity. Thus at-most-two restoration collapses to at-most-one; three steps can restore an example that one cannot. The paper's proposed new two-step outcome is refuted.

**Wrong or limited.** Formal `StateMetrics` retains only `(term count,total assertions)`; `EquivState` is equality of those two numbers. It cannot express tenth's graph isomorphism or the bare-term criterion. In that abstraction adding a term restores every identification's metrics, including ones not restorable as full graphs. The parity exclusion is useful, but a full-state-to-metric transition map is needed to transport it; the Lean theorem alone is not the graph classification.

**Remaining.** Add the full-state projection/lifting statement and formalize tenth's bare-term iff. Source: G/`meta/next_ten/09-two-step-leftover/derivation/Derivation.lean`, `StateMetrics` (30), `EquivState` (65), `two_step_cannot_restore_identify` (123), `identify_two_step_iff_one_step` (169).

### M10. Relation exchange as an actual step

Manuscript: [10-swap-as-change/derivation/paper.md](../../omega_engine_atlas/coda_atlas/F004_papers/001_finite_obstruction_calculus/001_genesis_ongoing_h3v7n5qf/meta/next_ten/10-swap-as-change/derivation/paper.md).

**Derived.** Swap is an involution preserving size. Empty-source costs remain size and shortest paths from empty contain no swap. Between written asymmetric states it provides a one-step shortcut; commuting swaps through ninth steps leaves at most one in a shortest path, yielding `min(dist9(S,T),1+dist9(swap(S),T))`.

**Wrong or limited.** The manuscript correctly says Lean keeps only aggregate r/s totals; unequal full tables can have equal totals. A further distinction is needed: written asymmetry is not asymmetry of the isomorphism class. On two terms, r has `0r0`, s has `1s1`; swapping relations equals swapping the two terms, so it is the same result at quotient distance zero despite differing written tables. The one-step-exact claim must specify written states or inequivalent result classes.

**Confirmed archived-number discrepancy.** Section 0 reports waves `[1,1,3,9,22]`, repeated in its ledger/audit/resolution. Committed [evidence/exploration_summary.json](../../omega_engine_atlas/coda_atlas/F004_papers/001_finite_obstruction_calculus/001_genesis_ongoing_h3v7n5qf/meta/next_ten/10-swap-as-change/derivation/evidence/exploration_summary.json) has `[1,1,3,7,24]`. Both total 36, so a total-only check misses the incorrect wave allocation. No regeneration was needed to find this discrepancy.

**Remaining.** Formalize full per-pair transitions and quotient-aware swap asymmetry; retain the written/result distinction in the distance formula and benchmarks. Source: G/`meta/next_ten/10-swap-as-change/derivation/Derivation.lean`, aggregate `NDSt`/`swap` (65), `fewest_changes10_empty` (337), `reach10_swap` (344), `reach9_swap_ge_two` (369); manuscript sections 0 and 5.

## Mind, consciousness, and recursive improvement

### C01. Omega-HOPE operator merging

Manuscript: [google_hope.md](../../omega_engine_atlas/coda_atlas/F004_papers/005_mind_and_consciousness/000_google_hope/google_hope.md), 220 lines; read claim inventory, counterexample and correction formulas, experiment scope, and handoff.

**Derived.** Within its declared duplicate-parent objective, the split `(f/2,f/2)` returning `f/2` is an algebraic executable-signal counterexample to an inverse-of-split interpretation. The manuscript distinguishes pseudoinverse-lift scale `(m*a+b*E)/(E+b)` from aggregate-execution scale `(c+b*E)/(E+b)` and identifies the realization-attainment gap: completeness of ambient L2 does not imply a minimizer on an arbitrary nonlinear neuron family. Degenerate denominators have a source-visible typed refusal. These are model-level algebraic results, not a replicated full HOPE pipeline.

**Wrong or limited.** The attributed upstream arXiv paper/source tree is absent locally and was not externally checked here. Therefore upstream claims/authorship/experimental numbers remain source-attributed assertions, not independently verified facts. The manuscript explicitly labels non-collinear parent descent HOPE-OMG-005B unestablished. Source `hope_engine.py` still calls the m-way generalization "Published HOPE scale" (header/field comment), whereas the paper restricts published attribution to m=2; that attribution should agree. Float64 regression is not an exact certificate or a performance study.

**Remaining.** Pin actual source bytes and precise objective, prove correction under realizability/denominator assumptions, test non-collinear descent and BN realization, and separate functional preservation from task accuracy/latency. Anchors: [hope_engine.py](../../omega_engine_atlas/coda_atlas/F004_papers/005_mind_and_consciousness/000_google_hope/hope_engine.py), `compute_hope_scales` (50-109), `merge_neurons` (156 onward); `experiment_1_split_merge_test.py`, `experiment_2_conv_bn_relu_test.py`; paper sections 3-4.

### C02. What is awareness?

Manuscript: [what_is_awareness.md](../../omega_engine_atlas/coda_atlas/F004_papers/005_mind_and_consciousness/001_awareness_mind_consciousness/what_is_awareness.md), 112 lines; read in full.

**Derived.** The supported mathematical content is an operational definition: a chosen observer detects a nonzero element of the differential's image. Nonzero detection is relative to that differential/projection. Equal exported observations cannot deterministically distinguish hidden inputs; this is a function-factorization statement conditional on identical exports.

**Wrong or limited: substantive unresolved claims.** Theorem 3.1 mostly restates the awareness definition; no bridge to phenomenal awareness is constructed. Section 9 still asserts feedforward DAG implies H1 zero and then no qualia/private fibers. A DAG alone does not determine the coefficient presheaf, filled faces, or cohomology, and the sibling hard-problem review explicitly records an acyclic-poset nonzero-H1 counterexample. Even H1 zero says nothing by itself about projection injectivity or qualia. The worked `d(0)=1` (line 65) violates linearity if 0 is the zero cochain; if it means a state label, a proper cochain assignment must be supplied. The listed Python and Lean links point into absent legacy paths; a repository file search did not find `WhatIsAwareness.lean` or `OE-011-AWARE-C1_awareness_test.py`, so "Type checked, 0 sorry" is unsupported by those locators.

**Remaining.** Replace incompatible claims with the sibling review's actual scope, define the finite complex and observer map, use a valid nonzero cochain example, and reconnect or withdraw proof/test claims. Any consciousness interpretation needs separate operational/empirical premises. The top interpretive-note fence does not repair contrary body assertions.

### C03. Hard-problem manuscript and its controlling review edition

Manuscript: [hard_problem_of_consciousness_v004.md](../../omega_engine_atlas/coda_atlas/F004_papers/005_mind_and_consciousness/001_awareness_mind_consciousness/hard_problem_of_consciousness_v004.md), 1480 lines. Reading covers the controlling review header/register, open obligations, historical theorem loci on cohomology, stability, and privacy, and the actual finite Lean estimator statement. [REVIEW_SCOPE.md](../../omega_engine_atlas/coda_atlas/F004_papers/005_mind_and_consciousness/001_awareness_mind_consciousness/REVIEW_SCOPE.md) repeats the current scope. Historical body is explicitly withdrawn as accepted results.

**Derived.** For one observation, equal boundary states give the same deterministic estimate; triangle inequality bounds the sum of reconstruction errors below by the hidden-state separation. Lean specializes this to integer triples `(s,m,r)` projected to `(s,m)`. Assumed boundary factorization gives non-strict kernel inclusion. Weighted L1 optimization gives distance to coboundaries, conditional on the specified matrix/weights; it is not automatically an H1 class.

**Wrong: historical claims already withdrawn.** The review records false feedback iff H1 assertions, a cover-union implementation bug repaired to true intersections, invalid presheaf/sheaf implications, a false weight-stability bound, a factor-of-two privacy bound, history-aware distinguishability, a vacuous viability test, and unsupported holonomy/qualia claims. The corrected model's cover contains the whole event set, so its positive-degree Cech cohomology vanishes; injected feedback residual is not independent topology evidence. The three surviving results have no constructed bridge between them. These are source-visible counterexamples/withdrawals, not freshly replayed results in this review.

**Remaining.** Separate archived manuscript from accepted review visually and in retrieval; define transcript-relative observability on reachable states; certify closedness separately from LP distance; construct or refute a map from history/cochains to reconstruction diameter. No experience theorem follows until a distinct empirical bridge is supplied. Anchors: [HPC_IntersubjectivePrivacy.lean](../../omega_engine_atlas/coda_atlas/F004_papers/005_mind_and_consciousness/001_awareness_mind_consciousness/lean4/HPC_IntersubjectivePrivacy.lean), `private_fiber_nontransmissibility` (29), `positive_reconstruction_error_bound` (42); `HPC_CommunicationChannel.lean` `factors_through_boundary` (26); `tests/test_review_counterexamples.py` and `tests/test_review_scope.py` are archived falsifier bindings, unexecuted here.

### R01. Finite report-grounded recursive improvement

Manuscript: [relational_reasoning_and_rsi_impossibility_monograph.md](../../omega_engine_atlas/coda_atlas/F004_papers/012_rsi/000_relational_reasoning_and_rsi_impossibility/relational_reasoning_and_rsi_impossibility_monograph.md), 309 lines. Reading covers the base theorem/premises, higher-cell and communication claims, quantum-campaign limitations, and later interpretive proposal; core Lean signatures and injected-defect code were inspected.

**Derived.** A strict transitive irreflexive order grounded in a fixed finite report carrier cannot support an infinite strictly improving trajectory: report collisions violate strictness, and a pigeonhole proof bounds distinct reports. Separate natural-budget descent bounds licensed lifts. Boundary-factorized channels are constant on fibers. A specified nonzero coboundary obstructs being exact. Product-carrier horizon is the same finite counting argument on paired reports. These results do not require quantum mechanics or the full ontology.

**Wrong or limited: precise scope failures.** `IsIndependentVerifier` is defined as unequal natural-number IDs (`RelationalRsiNoGo.lean`214), not statistical/evidential independence. The diagonal lemma (227) refutes a self-negating evaluator row; it is not a general impossibility of self-knowledge. Section 4.5's "any non-exact face perturbation" implies positive next coboundary is false: a closed non-exact cochain has zero next coboundary. The formal `higher_cochain_obstruction` instead *assumes* nonzero `d2`, a valid weaker statement. Async/rewiring horizon theorems count current reports; they do not prove that delay/rewiring creates defects. `non_monotonic_rewired_joint_horizon_bound` includes `rewireTopology k = rewireTopology k`, so topology is not constrained by that component.

The Python async fixture deliberately replaces zero observed lag mismatch with positive effective lag and injects it into a closing face (`rsi_transition_harness.py`1897-1904). Thus its 100% refusal distribution demonstrates the configured injected fixture, not a theorem about arbitrary delayed channels. Constant reports are a simple delayed channel with no stale/live mismatch. Later claims that proposer-selected panels necessarily have zero mutual information, or that a finite token alphabet bounds all transcript-level refinement, require additional assumptions: informative proposer-selected panels and arbitrarily long finite-alphabet strings are countermodels to those unrestricted readings.

**Remaining.** Keep the report-grounded theorem title/premises literal; prove actual independence contracts separately from ID inequality. Distinguish curvature from non-exactness and observation from injected defect. Bound transcript length or declare a fixed report alphabet at each theorem use. Sections 7-9 openly mark new QRU Lean/Rust work unelaborated/uncompiled; retain that status, repair budget linkage with `hclaim`, and compute exact contextuality/entropy witnesses before promotion. Generic total L1 distance to the local polytope must not be identified with contextual fraction without a normalization theorem for that model.

Anchors: [RelationalRsiNoGo.lean](../../omega_engine_atlas/coda_atlas/F004_papers/012_rsi/000_relational_reasoning_and_rsi_impossibility/lean4/RelationalRsiNoGo.lean), `FiniteRelationalUniverse` (458), `rsi_impossible` (489), `higher_cochain_obstruction` (650), `asynchronous_delayed_joint_horizon_bound` (672), `non_monotonic_rewired_joint_horizon_bound` (720); [rsi_transition_harness.py](../../omega_engine_atlas/coda_atlas/F004_papers/012_rsi/000_relational_reasoning_and_rsi_impossibility/code/rsi_transition_harness.py), stale-cochain injection (1897-1904). `RsiImpossible.lean` is the separate internal-natural-evaluation descent model, not interchangeable theorem evidence.

## Prioritized practical obligations

| Priority | Deliverable | Acceptance condition | Why next |
|---|---|---|---|
| P0 | Correct P04 and P10 wave numbers | Tables equal pinned JSON fields, not just totals | Concrete contradictions between manuscripts and stored evidence |
| P0 | Narrow M02 term-inflation claim | Distinguish loop-overlap from off-diagonal witnesses | A two-term loop-overlap target has a route never exceeding two terms |
| P0 | Align awareness note with controlling consciousness review | No DAG/qualia inference or missing-proof assertion remains unqualified | Current sibling texts contradict the accepted scope |
| P0 | Separate observed/injected async defect | Fixture receipt identifies injection and theorem premises | Current distribution can be read as evidence of a forced outcome |
| P1 | Type and prove quotient transition contracts | Congruence proof or explicit refusal/witness for each primitive | Gauge and local-reading quotients are not transition congruences |
| P1 | Full-state abstraction maps for meta Lean models | Each full step maps to the aggregate step; non-lifting claims stay scoped | Metrics/totals erase graph distinctions |
| P1 | Complete detector bundle | Loop/pair/triple certificate; rank premise checked | A detector can be invariant while blind to nonzero classes |
| P1 | Prove subset-descent optimality in Lean | Four-term counterexample rejects single-term-only descent | This is the key general cost algorithm beyond tiny carriers |
| P2 | General carry-map reachability | Constructed paths and exact carrier bounds | Second/sixteenth general sufficiency remains outside Lean |
| P2 | Thin reader/replay package for each manuscript | Claim ID -> actual theorem premises -> command -> source digest -> receipt | Avoids proof-name and archived-PASS substitution |

The strongest reusable result in this partition is the explicit algebra of finite state grammars, quotient defects, representative failures, and detector blindness. The next project should make those boundaries executable and readable before treating them as a physical or cognitive derivation. This review does not change publication status or authorize any mathematical or institutional claim.
