# Omega architecture review: papers, native mathematics and applications

## Current root and delivery reading, 2026-10-18

AuthorityEffect: None. Source pin: `000ee9b0c234eda74340e424d6cfb3f6ec001df7`.
This section supersedes earlier root and delivery observations only; the
historical sections below remain intact. The detailed bounded review is
[48_workspace_and_delivery_review.md](48_workspace_and_delivery_review.md).
It does not certify the entire repository or repeat historical test results.

The root has 33 tracked top-level directories. The Cargo manifest declares
55 members, including two finite-QM members outside `crates_rs`. Root Python
metadata now includes all six packages named as missing in the older FM-08
finding. The old `lake-build-p032` and `research/mssn_sn_tower` root README
references remain absent. These are source observations, not build results.

Live delivery problems remain: the root README still links the absent
`004_oepfp/papers` directory and names absent education `pilots/` and `pfp/`
directories; two legacy pre-commit entries target missing paths; Pixi still
advertises whole-suite commands despite the local bounded-test directive.
More seriously, two migration scripts hardcode the primary checkout before
writing contracts, and the standalone Anthropic runner still discovers
credentials through its own parent-directory `.env` search. The four host
`AGENTS.md` files have the same Git blob identity; broader host parity was
not executed. Slice grade: **C+**, reflecting these execution-boundary risks
and uneven entrypoint reliability rather than a mathematical assessment.

## Remediation pass 2026-10-17, base pin f53db0144c

AuthorityEffect: None. This is a reading and remediation record, not an execution gate or a mathematical proof.

Checked and remediated against `f53db0144c` on `main`:

1. **`README.md` root door alignment:** On `f53db0144c`, `README.md` no longer references the retired `lake-build-p032` task, `research/mssn_sn_tower`, `omega_engine_projects/`, or top-level `receipts/` and `results/`.
2. **`pyproject.toml` package discovery (`FM-08`):** Added the six tracked top-level package patterns (`omega_engine_applications*`, `omega_engine_education*`, `omega_engine_library*`, `omega_engine_research_papers*`, `omega_simplex_autop*`, `omega_simplex_cache*`) to `[tool.setuptools.packages.find] include`.
3. **`Verification52Gate.evaluate` (`FM-01`):** Replaced the 39 hardcoded `True` entries in `omega_engine_research_papers/use_cases/gate_52/evaluator.py` with deterministic domain, trace, halt-guard, metadata, and markdown predicates, and added falsifying unit tests in `omega_engine_research_papers/tests/test_use_case_52_gate.py`.
4. **`LakeProofRunner` comment-aware `sorry` token scan (`FM-07`):** Updated `omega_engine_research_papers/infrastructure/lean4_bridge/lake_runner.py` to strip Lean line (`-- ...`) and nested block (`/- ... -/`) comments before scanning for word-boundary `sorry`, `sorryAx`, and `admit` tokens, eliminating comment false positives while keeping fail-closed toolchain and compilation behavior.
5. **AutoP `CatkitEmitter` canonical category imports (`FM-15`):** Exported `FiniteCategory`, `MorphismMeta`, `MorphismKind`, `Default`, `num_objects`, and `num_morphisms` from `omega_category_theory::finite_category` and updated `omega_engine/crates_rs/auto_p/src/compiler/emitter.rs` to emit `use omega_category_theory::finite_category::{FiniteCategory, MorphismMeta, MorphismKind};` instead of the retired `omega_core::ascent::lambdas::l161_structcat` path.

## Earlier reading 2026-10-17, pin fa7b7384
## Later reading 2026-10-17, pin f53db0144c3d4e2ed2fc27561e02a9163c665ef8

AuthorityEffect: None. This is a reading, not a gate or a proof.

Checked at `f53db0144c3d4e2ed2fc27561e02a9163c665ef8` on `main` (`git rev-parse HEAD`). The parent pin `8aa7c4f86fd0a14567d2ff0ed4dcdc649a733558` is an ancestor (`git merge-base --is-ancestor` exit 0). HEAD is the merge of pull request #1199, `chore/delete-unconnected-contracts-packets`. Cargo, Lake, and pytest were not run. `target/`, `.lake`, `__pycache__`, and `node_modules` were not walked. `README.md`, `PROJECT.md`, `pyproject.toml`, `pixi.toml`, `LICENSE`, and `omega_engine/crates_rs/Cargo.toml` have no diff against this pin. Deletions under `omega_engine_governance/contracts/contracts_packets/` were not counted and were not treated as the pin. `01_omega_design_dag_svg.svg`, `02_architecture_map_v01.yaml`, `03_architecture_dash_v1.html`, `04_paper_source_catalog.json`, and `05_rust_crate_inventory.json` were not rewritten. Goal, paper, and route totals elsewhere in this file were not re-counted. Slop-banner file counts were not re-counted.

Slice grade: B+. The manifest, the licence lines, and most root-map rows match a real tree, and `omega_engine_woland` is on this pin. The material gaps are four scaffold members, three README education doors that are not directories, a gitignored `runs/` row, and census files that still describe an older workspace. That is coherent with named gaps, not a line-for-line match and not a missing member path.

Where the `fa7b7384` paragraph says top-level `omega_engine_woland/` is absent, that clause is historical. The same paragraph already listed the directory. Where it says `README.md` names top-level `omega_engine_projects/`, `receipts/`, and `results/`, that clause is also historical. The current README does not name top-level `omega_engine_projects/` or `results/`, and its receipts row is `omega_engine_product_planning_office/receipts/`. Those three top-level paths are absent both from `git ls-tree -d --name-only HEAD` and from disk. `pixi.toml` still has no `lake-build-p032` and no `research/mssn_sn_tower`. `README.md` and `omega_engine_pfp/README.md` do not contain `research/mssn_sn_tower` either.

`omega_engine/crates_rs/Cargo.toml` declares 55 members. Every member path has a `Cargo.toml` at HEAD. Every member manifest sets `license.workspace = true`. `[workspace.package]` license is `PolyForm-Noncommercial-1.0.0`. There is no `default-members` list and no `exclude` list. Immediate directories under `crates_rs` that contain a `Cargo.toml`, skipping `target/`, number 53. None of those 53 is outside `members`, and none of the local members is missing on disk. The two members outside `crates_rs` are `omega_engine_atlas/coda_atlas/F004_papers/006_finite_qm/campaigns/c750/rust` (package `finite_qm_c750`, `version.workspace = true`) and `omega_engine_atlas/coda_atlas/F004_papers/006_finite_qm/native` (package `finite_qm_native`, `version = "0.2.0"`). Directory and package names that differ: `omega_local_green_global_red_lggr` is package `omega_epk`; `omega_linear_algebra` is package `linear_algebra`; the member `tests` is package `omega_engine_tests`. There is no directory `omega_epk`, `omega_trace`, or `omega_discrete_deformation_calculus` under `crates_rs`.

The scaffold-marked members are the four whose descriptions say "Best-effort dual-face scaffold" and that have `tests/scaffold_not_certified.rs`: `omega_biology`, `omega_chemistry`, `omega_economics`, and `omega_machine_learning`. They are members. `omega_biology` depends on `omega_chemistry`. A search of member `Cargo.toml` files found no other member naming these four. `omega_general_relativity` is not in that set. Its description says domain dual-face GR, and `tests/scaffold_not_certified.rs` is not in HEAD for that crate.

`git ls-tree -d --name-only HEAD` lists 33 tracked top-level directories, 16 of whose names begin with `omega_engine`. `omega_engine_woland` is one of them. It is on disk. `git ls-tree -r --name-only HEAD omega_engine_woland` is 10784 paths, 1483 ending in `.py` and 0 ending in `.rs`. `omega_engine_woland/stage` and `omega_engine_woland/infrastructure/providers` are tracked and on disk. The 33 directories are `.agents`, `.claude`, `.codex`, `.github`, `.grok`, `_ic`, `_ooutwire`, `artifacts`, `lean4`, `manifests`, `omega_engine`, `omega_engine_applications`, `omega_engine_atlas`, `omega_engine_cognitive_operations`, `omega_engine_education`, `omega_engine_epistemic_immune_system`, `omega_engine_governance`, `omega_engine_library`, `omega_engine_operating_system`, `omega_engine_operations`, `omega_engine_pfp`, `omega_engine_product_planning_office`, `omega_engine_prompt_civilization`, `omega_engine_research_papers`, `omega_engine_woland`, `omega_engine_workflows_agents_skills`, `omega_simplex_autop`, `omega_simplex_cache`, `scripts`, `tests`, `tests_e2e`, `tools`, and `web_dashboard`.

Root licence lines agree. `LICENSE` is titled PolyForm Noncommercial License 1.0.0 and carries the required notice for Jeremy H. Carroll. `pyproject.toml` and `pixi.toml` record `PolyForm-Noncommercial-1.0.0`. `pyproject.toml` names `the-symbol-game` 0.1.0 and `requires-python` `>=3.10`. `pixi.toml` bounds Python to `>=3.10,<3.13`. Its tasks include pytest, `cargo check`, and `lake --dir lean4 build`. `PROJECT.md` marks M1 through M7 DONE. Those paper trees were not opened on this pass. The setuptools `include` list does not name `omega_engine_applications`, `omega_engine_education`, `omega_engine_library`, `omega_engine_research_papers`, `omega_simplex_autop`, or `omega_simplex_cache`. All six are tracked top-level directories.

`README.md` says `main` has no top-level `research/`, `engine/`, or `knowledge/`. Those three are absent from HEAD and from disk. The same README presents three education paths that are absent from both: `omega_engine_education/pilots/`, `omega_engine_education/pfp/`, and `omega_engine_education/documentation/004_oepfp/papers/`. Tracked children of `omega_engine_education` are `curriculum_manifest.yaml`, `documentation`, `education_app`, and `scripts`. Tracked children of `004_oepfp` include `README.md`, `curriculum`, `docs`, `encyclopedia`, `grammar`, `lean4`, `levels`, and `math`, and do not include `papers`. The README row `manifests/`, `artifacts/`, `runs/` names `runs/`. `.gitignore` line 24 ignores `runs/`. That path is a directory on disk and is not a HEAD tree. `omega_engine_education/documentation/woland_stage` is absent. `README.md` does not contain the string `woland_stage`; it names the live stage `omega_engine_woland/stage`, which exists. The other repository-map paths checked in this pass, including the listed education strands, the five atlas floors, `010_mub6/artifacts/knowledge`, `lean4/research_programs/mub6`, `NOTICE`, `LICENSING.md`, `uv.lock`, `TEST_INFRA.md`, and `TEST_READY.md`, were tracked and on disk.

Stored figures that still disagree with this pin:

- `01_omega_design_dag_svg.svg` says "Rust production crates — 55 directories". Live immediate `Cargo.toml` directories under `omega_engine/crates_rs`, skipping `target/`, are 53. The SVG still labels `omega_trace`, and that directory is not on disk. The SVG text does not contain `012_rsi`, `013_trace_zero_quotient_duality`, `014_linkedin_articles`, or `015_pfp`. `git ls-tree -d --name-only HEAD:omega_engine_atlas/coda_atlas/F004_papers` lists 17 children, 15 numbered, including those four names.
- `02_architecture_map_v01.yaml` `review_refresh_20261016.confirmed_counts` stores `tracked_top_level_directories` 34 (live 33), `tracked_omega_engine_roots` 17 (live 16), `declared_cargo_workspace_members` 54 (live 55), and `additional_cargo_directories_outside_workspace` 4 (live 0). `later_pass_20261016` stores `workspace_members` 56 (live 55) and `omega_engine_woland_blobs` 0 (live 10784). `full_pass_20261016.workspace_members` 55 matches. The goal, paper, and route figures in that file were not re-counted.
- `03_architecture_dash_v1.html` says "55 workspace members", which matches. FM-14 still says "Four immediate Cargo directories are absent from workspace members" and stores src counts 47, 51, 63, and 40. Those four crates are members. Those src counts were not re-counted. The card's goal, paper, and route figures were not re-counted.
- `04_paper_source_catalog.json` `later_pass_20261016.omega_engine_woland_blobs` is 0. `application_roots` has two `omega_engine_woland` rows, `tracked_files` 86 and `tracked_files` 10410. Live Woland paths at HEAD: 10784. The other application-root rows and the paper digests were not re-counted.
- `05_rust_crate_inventory.json` stores `workspace_member_specs` 54, `members_under_crates_rs` 52, `external_members` 2, `non_member_packages_under_crates_rs` 4, and `production_crate_directories_under_crates_rs` 55. Live figures are 55 members, 53 under `crates_rs`, 2 external, 0 non-members, and 53 immediate cargo directories. `later_pass_20261016.workspace_members` is 56. `later_reading_20261017.workspace_members` is 55 and says the packages array was not regenerated. Its `.rs` file counts were not re-counted. `external_members` 2 matches.

Five findings:

1. The workspace at `omega_engine/crates_rs/Cargo.toml` has 55 members, every path exists, and every member manifest inherits `PolyForm-Noncommercial-1.0.0` from `[workspace.package]`. `LICENSE`, `pyproject.toml`, and `pixi.toml` record the same grant. There is no `default-members` list, no `exclude` list, and no immediate `crates_rs` crate outside `members`.
2. `omega_engine/crates_rs/omega_biology`, `omega_chemistry`, `omega_economics`, and `omega_machine_learning` are members whose descriptions say "Best-effort dual-face scaffold" and that have `tests/scaffold_not_certified.rs`. Biology depends on chemistry. No other member manifest names the four. `omega_general_relativity` has no such test file.
3. `git ls-tree -d --name-only HEAD` is 33 directories and 16 `omega_engine*` roots. `omega_engine_woland` exists, with 10784 tracked paths, including `omega_engine_woland/stage` and `omega_engine_woland/infrastructure/providers`.
4. `README.md` still presents absent doors `omega_engine_education/pilots/`, `omega_engine_education/pfp/`, and `omega_engine_education/documentation/004_oepfp/papers/`. It also lists `runs/`, which `.gitignore` line 24 ignores. Its denials of top-level `research/`, `engine/`, and `knowledge/` match the tree. The setuptools `include` list omits six tracked roots: `omega_engine_applications`, `omega_engine_education`, `omega_engine_library`, `omega_engine_research_papers`, `omega_simplex_autop`, and `omega_simplex_cache`.
5. `01_omega_design_dag_svg.svg`, `02_architecture_map_v01.yaml`, `03_architecture_dash_v1.html` FM-14, `04_paper_source_catalog.json`, and `05_rust_crate_inventory.json` still store the older membership, directory, and Woland-blob figures quoted above. The HTML card's "55 workspace members" and the YAML full-pass member count are the lines that match.

Candidate next project: retarget `README.md` so it no longer presents `omega_engine_education/pilots/`, `omega_engine_education/pfp/`, and `omega_engine_education/documentation/004_oepfp/papers/` as live homes, and stop listing gitignored `runs/` beside tracked `manifests/` and `artifacts/`. F004 `015_pfp` is a tracked family on this pin; its manuscripts were not opened, so this reading does not name it as the replacement prose.

## Later reading 2026-10-17, pin fa7b7384

AuthorityEffect: None. This is a reading, not a gate or a proof.

Checked at `fa7b7384700467927cea7317f9ef495b575b71f8` on `main`. Cargo, Lake, and pytest were not run. `omega_engine/crates_rs/target/` was not walked. `PROJECT.md`, `README.md`, `pyproject.toml`, `pixi.toml`, `LICENSE`, and `omega_engine/crates_rs/Cargo.toml` match that pin. Four Rust paths are modified in the worktree and were not read as uncommitted text: `omega_engine/crates_rs/omega_quantum_physics/src/derivation_dag_witnesses.rs`, `omega_engine/crates_rs/omega_quantum_physics/src/lib.rs`, `omega_engine/crates_rs/omega_symbol_game/src/derivation_dag_witnesses.rs`, and `omega_engine/crates_rs/tests/omega_symbol_game/derivation_dag_witnesses.rs`.

Slice grade: B. The manifest and the licence lines match a real tree. The root README still names doors that are not on this pin, and four workspace members are marked scaffolds. That is a usable uneven core, not a missing member path and not a line-for-line match of every root sentence to a directory.

Where an older paragraph in this file says the workspace has 54 members or 56 members, or says `omega_biology`, `omega_chemistry`, `omega_economics`, and `omega_machine_learning` are outside `members`, that paragraph is historical. The `src` counts in the FM-14 sentence, 47, 51, 63, and 40, still match `src/*.rs` on this pin. The membership clause does not. The 2026-10-16 refresh table's 34 tracked top-level directories and 17 `omega_engine*` roots are historical. `git ls-tree -d --name-only HEAD` on this pin lists 33 directories, 16 of whose names begin with `omega_engine`. This pass did not identify which older name dropped out. Goal, paper, and route totals elsewhere in this file were not re-counted.

`omega_engine/crates_rs/Cargo.toml` declares 55 members. Every path exists. Every member `Cargo.toml` sets `license.workspace = true`. `[workspace.package]` license is `PolyForm-Noncommercial-1.0.0`. There is no `default-members` list and no `exclude` list. No immediate directory under `crates_rs`, aside from `target/`, has a `Cargo.toml` and is absent from `members`. The two members outside `crates_rs` are `omega_engine_atlas/coda_atlas/F004_papers/006_finite_qm/campaigns/c750/rust` (package `finite_qm_c750`, `version.workspace = true`) and `omega_engine_atlas/coda_atlas/F004_papers/006_finite_qm/native` (package `finite_qm_native`, its own `version = "0.2.0"`). Both have `src/` and `tests/`.

Directory and package names that differ: `omega_local_green_global_red_lggr` is package `omega_epk`; `omega_linear_algebra` is package `linear_algebra`; the member `tests` is package `omega_engine_tests`. There is no directory `omega_epk`, `omega_trace`, or `omega_discrete_deformation_calculus` under `crates_rs`.

The scaffold-marked members are the four whose package descriptions say "Best-effort dual-face scaffold" and that have `tests/scaffold_not_certified.rs`: `omega_biology`, `omega_chemistry`, `omega_economics`, and `omega_machine_learning`. They are members. `src/*.rs` files containing `human_llm_best_effort_slop`: biology 45 of 47 (`neurotransmitter.rs` and `potato.rs` do not); chemistry 38 of 51 (the 13 without that marker are `amide_docking.rs`, `chiral_amphetamine.rs`, `coboundary.rs`, `element.rs`, `formula.rs`, `lib.rs`, `lysine.rs`, `nitrogen.rs`, `periodic_table.rs`, `potato.rs`, `quantum_chemistry_chain.rs`, `relation.rs`, and `substance.rs`); economics 63 of 63; machine learning 40 of 40. `omega_chemistry/src/lib.rs` still calls the crate a best-effort scaffold and says the `omega_homology` dependency is not a proof. The opened `omega_biology/tests/scaffold_not_certified.rs` checks a fence that says the cell is not certified. Chemistry depends on `nalgebra` and `omega_homology`. Biology depends on chemistry. The economics and machine-learning manifests list no dependencies. No other member manifest depends on these four. `omega_general_relativity` is not in that set. Its description says domain dual-face GR, it has no `scaffold_not_certified.rs`, and 11 of 37 `src/*.rs` files still contain the same slop marker.

`git ls-files` under `omega_engine/crates_rs`, excluding `target/`, is 3098 `.rs` paths, 2219 of them under `src/`. Two of those paths were added after `cf35917f9c2b1224cbf0b09250ca91ff245265e8`: `omega_quantum_physics/src/bin/emit_pfp_workpads.rs` and `omega_quantum_physics/src/derivation_dag_witnesses.rs`.

Eight members have a local `tests/` directory: the four scaffolds, `omega_policy`, `omega_prompt_civilization`, and the two finite-QM members. `omega_engine/crates_rs/tests/` has 43 directories named for members, plus `e2e` and `integration`. `omega_policy` and `omega_prompt_civilization` are in both places. Five members have neither a local `tests/` directory nor a `crates_rs/tests/<member>` directory: `constants`, `omega_id_run`, `omega_intelligence`, `omega_lifts`, and `omega_terminalizers`. Each of those five has a `#[cfg(test)]` module under `src/`. The shared `tests` member has no `src/`; its sources are that central tree.

Root licence lines agree. `LICENSE` is titled PolyForm Noncommercial License 1.0.0 and carries the required notice for Jeremy H. Carroll. `pyproject.toml` and `pixi.toml` record `PolyForm-Noncommercial-1.0.0`. `pyproject.toml` names `the-symbol-game` 0.1.0 and `requires-python` `>=3.10`. `pixi.toml` bounds Python to `>=3.10,<3.13`. Its tasks include pytest, `cargo check`, and `lake --dir lean4 build`. It does not contain `lake-build-p032` or `research/mssn_sn_tower`. (Historical note: on `fa7b7384`, `README.md` still mentioned that pixi task and `omega_engine_projects/`, `receipts/`, and `results/`, and `pyproject.toml` omitted the six tracked top-level packages; both were resolved on `f53db0144c` and in the 2026-10-17 remediation pass above.)

On disk and not in `git ls-tree -d --name-only HEAD`: `runs/`, `scratch/`, and `the_symbol_game.egg-info/`, plus cache and virtualenv directories. They are not roots in the README map.

The 33 tracked top-level directories are `.agents`, `.claude`, `.codex`, `.github`, `.grok`, `_ic`, `_ooutwire`, `artifacts`, `lean4`, `manifests`, `omega_engine`, `omega_engine_applications`, `omega_engine_atlas`, `omega_engine_cognitive_operations`, `omega_engine_education`, `omega_engine_epistemic_immune_system`, `omega_engine_governance`, `omega_engine_library`, `omega_engine_operating_system`, `omega_engine_operations`, `omega_engine_pfp`, `omega_engine_product_planning_office`, `omega_engine_prompt_civilization`, `omega_engine_research_papers`, `omega_engine_woland`, `omega_engine_workflows_agents_skills`, `omega_simplex_autop`, `omega_simplex_cache`, `scripts`, `tests`, `tests_e2e`, `tools`, and `web_dashboard`.

## Full pass 2026-10-16, pin ca50ed5f

AuthorityEffect: None. This paragraph was checked against `ca50ed5fdbf1beb34ec8b27c5cef2c50eb95cbee`. Twelve readers opened that pin. `origin/main` then moved to `c9abb4a55b7b9de9173301970751d1cf13660f22`. Where this paragraph disagrees with an older section in this file, this paragraph is the later one. The reading guide, the ten projects, and the grade B are [`19_review_toc_and_grade.md`](19_review_toc_and_grade.md) (with PFP pipeline review [`37_004_oepfp_docs_math_and_typed_pfp_pipeline_review.md`](37_004_oepfp_docs_math_and_typed_pfp_pipeline_review.md) and boundary/quality notes [`43_boundary_and_quality.md`](43_boundary_and_quality.md)).

On this pin the goal DAG is 437 rows (301 done, 126 open, 4 blocked, 6 deferred), the paper DAG is 19 nodes and 34 edges under `F004_papers/plans/paper_math_dags/`, and the derivation DAG is 177 nodes and 164 routes. The workspace has 55 members, all PolyForm. The route ledger is 235 records, 115 nodes, 120 edges, and 93 implemented routes. All 93 name an owner and an oracle that exist. All 177 stored hashes match. `MUB6_PILOTS_31_50_ROUTE` is absent. `omega_engine_woland` has zero blobs.

## Later pass 2026-10-16, pin 8ac5da18

AuthorityEffect: None. This paragraph was checked against `origin/main` `8ac5da188390a93252614dfbb707f15d2c4fba42`. Where it disagrees with an older section in this file, this paragraph is the later one.

The census embedded below was checked at `25da16690b`. On `origin/main` `8ac5da188390a93252614dfbb707f15d2c4fba42` the goal DAG is 410 rows (281 done, 119 open, 4 blocked, 6 deferred), the workspace has 56 members, and the route ledger is still 237 records, 116 nodes, 121 edges, and 94 implemented routes. Ninety-three of those 94 name an owner file and an oracle file that exist. `MUB6_PILOTS_31_50_ROUTE` does not. Five bound hashes do not match the pin. `omega_engine_woland` has zero blobs. The paper DAG is still 19 nodes and 34 edges, in `plans/paper_math_dags/paper_dag.jsonl`. Where the older counts disagree, this paragraph is the one remeasured. The reading guide is `19_review_toc_and_grade.md`.


AuthorityEffect: None. Markdown is not a gate.
Historical source baseline: `8bc153ac8dfbe986fd324bf9cab0ca0ae8fa09f8`.
Prior integrated-main pin from the 2026-10-15 text: `a4856e2972018f58aa12adff28247ca76f8bf252`.
`git merge-base --is-ancestor` returned 0 for both pins against the revision below.
Status: ordered source reconciliation with scoped Genesis, Pre-Genesis, S(n),
WDP, LGGR, CODA and DDC replay. One finite Genesis report/repair application
route is implemented; wider paper-to-application correspondence remains open.

## Review refresh 2026-10-16

Pinned revision: `25da16690b7617ecc75285b8e63543bcb8662acc` on `main`
(`git rev-parse HEAD` and `git branch --show-current`). This pass did not
rebuild the SVG, did not run `cargo`, `lake`, or pytest, and did not re-rank
the 2026-10-15 delivery priority. AuthorityEffect: None.

The live directory is `omega_engine_product_planning_office/architecture_review`.
`omega_engine_product_planning_office/plans/epics/architecture_review` is absent
on this tree. Relative links in this file, the YAML map, and the HTML dashboard
were rewritten from that old depth. `01_omega_design_dag_svg.svg` was not
regenerated. A string search of that SVG found none of `012_rsi`,
`013_trace_zero_quotient_duality`, `014_linkedin_articles`, or `015_pfp`.

Counted this pass, with the 2026-10-15 document figures labeled historical:

| Item | This pass | Historical 2026-10-15 figure |
| --- | ---: | ---: |
| Tracked `omega_engine*` roots | 17 | 17 |
| Tracked top-level directories | 34 | not stated |
| Numbered F004 family directories | 15 | 13 |
| Paper-DAG nodes / edges | 19 / 34 | 19 / 34 |
| Goal-DAG records | 378 | 315 |
| Implemented finite routes | 94 | 93 |
| WDP route nodes / edges | 116 / 121 | 115 / 120 |
| Production crates owning a route | 16 of 55 | 15 of 55 |
| Production `src/**/*.rs` | 2,211 | 2,128 |
| Tracked contract YAML / JSON | 1,324 / 34 | 345 YAML; JSON not stated |
| Production src paths literally named by those YAML/JSON files | 83 | 32 |

Goal statuses this pass: 279 done, 89 open, 4 blocked, 6 deferred, 0 in
progress, 0 refuted. The historical split was 144 done, 122 open, 22 blocked,
4 in progress, 23 deferred. `goal_dag.jsonl`, `paper_dag.jsonl`, and
`wdp_rust_routes.jsonl` are under
`omega_engine_atlas/coda_atlas/F004_papers/plans/` (`paper_dag.jsonl` is in
`paper_math_dags/`). `omega_engine_product_planning_office/plans` has no JSONL
copies. Beside `paper_dag.jsonl` are 18 per-paper math-DAG JSONL files; their
rows were not summed. Paper-DAG rows are 54: 1 metadata, 19 nodes, 34 edges.
Route rows are 237. Two implemented edges are owned by Python files
(`source_packet.py`, `validate_wdp_rust_routes.py`). Twenty-eight implemented
edges are owned under `crates_rs/tests`. Fifty-six distinct owner paths sit in
16 production crates.

Workspace membership from `omega_engine/crates_rs/Cargo.toml` is unchanged:
54 members, 52 under `crates_rs` including `tests`, and 2 finite-QM paths that
exist. Immediate `Cargo.toml` directories under `crates_rs`: 56. The four
absent from `members` are `omega_biology` (47 src rs), `omega_chemistry` (51),
`omega_economics` (63), and `omega_machine_learning` (40). Production
directories excluding `tests`: 55. Tracked src rs outside those four: 2,010.
The four add 201. Total production src rs: 2,211. No extra nested `Cargo.toml`
was found when `target` was skipped. `git ls-files` and the `src` walk named
the same 2,211 files.

Contract method: `git ls-files omega_engine_governance/contracts` (1,586 tracked
files: 1,324 `.yaml`, 34 `.json`, 102 `.py`, 74 `.md`, 12 `.source`, 12 `.log`,
12 `.txt`, 11 `.xml`, 2 `.toml`, 3 with no suffix). A filesystem walk also saw
37 `.pyc` files, which are not in the tracked count. The 345 YAML figure was
not recovered as a subset. The 83 path hits are literal `crates_rs/<crate>/src/...rs`
strings in the 1,358 tracked YAML and JSON files that match a current
production src file (142 of those files contain at least one). That is still
not one contract and one Lean proof per Rust file.

`git ls-tree -d --name-only HEAD` lists 34 tracked top-level directories.
README.md names `omega_engine_projects/`, a repo-root `receipts/`, and
`results/`. None of those three paths exists. Cited receipts are under
`omega_engine_product_planning_office/receipts/`. `LICENSE` is PolyForm
Noncommercial 1.0.0. `pyproject.toml` names `the-symbol-game` 0.1.0 and
requires Python `>=3.10`. The package `include` list still has no
`omega_engine_research_papers` entry.

Not re-counted, so still unverified this pass: `source_records` 45,
`projection_obstruction_papers` 9, the six-family / 25-derivation / nine-PO
figures, per-paper math-DAG row totals, epic-file totals, strict-check citation
totals, and every test or parity total in section 6 and in the 2026-10-14
receipts. Reports `20`–`26` pin `1340ebb4` or `4bdf074a`, not this HEAD. Their
prose counts were not re-executed. A read-only `sqlite_master` of
`argon_audit.sqlite3` (10,088,448 bytes) shows 32 tables, 43 views, and 36
indexes. Selected row reads, not a new audit: `findings` 8; `work_items` 8,
all `RESOLVED`; `yaml_artifacts` 321; `normal_forms` 113; `pfp_types` 118;
`lean_theorem_census` 565; `v_open_high_severity_findings` 0;
`v_documentation_code_conflicts` 0; `v_stale_or_historical_claims` 24.
`24_sqlite_evidence_verification.md` says 21 views and OPEN work items. Those
two statements do not match this database file.

The filename convention `NN_<20-character-lowercase-stub>.<ext>` is historical.
This directory already violates it. Files were not renamed. Twenty names,
`00` through `19`, match that pattern.
[`19_review_toc_and_grade.md`](19_review_toc_and_grade.md) is the 2026-10-16
table of contents, project list, and code-quality grade. Numbers 21, 22, 23,
and 24 are each used twice. Names `20`–`26` have longer stubs.
`woland_current_and_missing_architecture.md` and `argon_audit.sqlite3` have no
`NN_` prefix. The directory has 33 files.

## 0. Root, layers and naming contract

This file is the document root of the architecture-review set. The conceptual
programme root is **Pre-Genesis**, with the intended orientation

\[
\text{Pre-Genesis}\longrightarrow\langle\rangle\longrightarrow S(n)
\longrightarrow\mathrm{MSS\!\!-N}\longrightarrow\mathrm{WDP}.
\]

That line is an architecture orientation. It is not a claim that every arrow is
already a proved interpretation theorem. Genesis 19L57G1 and Genesis Ongoing
provide reviewed admission, passage and continuation profiles alongside this
spine. WDP then branches into the paper families, finite deep-idea interfaces,
Python consumers and native Rust owners.

[The SVG](01_omega_design_dag_svg.svg) was not regenerated on 2026-10-16.
`git ls-tree --name-only HEAD:omega_engine_atlas/coda_atlas/F004_papers` shows
15 numbered family directories (`001_finite_obstruction_calculus` through
`015_pfp`). The historical figure of 13 was not recovered as a subset. Any
green or grey crate reading belongs to that older drawing and was not
re-derived. A crate name or dependency is not a completed derivation.

The repository has three graphs with different meanings:

| Graph | Census on 2026-10-16 | What an edge means |
| --- | ---: | --- |
| Paper DAG | 19 nodes, 34 edges (historical figures, re-counted) | Reading and scoped research relationship. |
| Goal DAG | 378 goals: 279 done, 89 open, 4 blocked, 0 in progress, 6 deferred, 0 refuted. Historical 2026-10-15 figure: 315 (144 done, 122 open, 22 blocked, 4 in progress, 23 deferred). | Work prerequisite with an explicit reason. |
| WDP-to-Rust routes | 116 nodes, 121 edges, including 94 implemented finite routes. Historical 2026-10-15 figures: 115, 120, and 93. | A bounded source profile has a named owner and oracle. It does not discharge the parent paper. |

Sixteen of the 55 production crates own at least one implemented finite route.
Historical 2026-10-15 figure: 15. There are 2,211 tracked Rust files below
production `src` trees. Historical 2026-10-15 figure: 2,128. The tracked
governance corpus has 1,324 YAML files and 34 JSON files. Historical
2026-10-15 YAML figure: 345, not recovered as a subset. Literal path matches
name 83 of the 2,211 production src files. Historical figure: 32. The
one-Rust-file/one-contract/one-Lean-binding regime remains a target, not
current coverage. YAML contracts belong under `omega_engine_governance`,
never inside production crates; proof files stay in their declared Lean estate.

The filename pattern `NN_<20-character-lowercase-stub>.<ext>` is historical.
This directory already violates it, as recorded in the refresh section above.
Operational scripts and canonical DAG filenames in the paper `plans` directory
remain stable because validators import them directly. The file table lists
every immediate file. The separate table of contents, the next ten projects,
and the code-quality grade are in
[`19_review_toc_and_grade.md`](19_review_toc_and_grade.md).

| File | Role |
| --- | --- |
| `00_omega_system_rootmap.md` | This root and reading order. |
| [`01_omega_design_dag_svg.svg`](01_omega_design_dag_svg.svg) | Prior generated drawing. Not regenerated on 2026-10-16. |
| [`02_architecture_map_v01.yaml`](02_architecture_map_v01.yaml) | Structured findings, census and target architecture. |
| [`03_architecture_dash_v1.html`](03_architecture_dash_v1.html) | Human navigation dashboard. |
| [`04_paper_source_catalog.json`](04_paper_source_catalog.json) | Paper and outer-source custody. `review_refresh_20261016` added 2026-10-16. Historical rows kept. Thirteen digests still match `06d0589d`, not this HEAD. |
| [`05_rust_crate_inventory.json`](05_rust_crate_inventory.json) | Crate inventory refreshed from manifests on 2026-10-16, without `cargo metadata`. 54 workspace members and 4 non-members. |
| [`06_genesis_native_route.md`](06_genesis_native_route.md) | Genesis source-to-native review. |
| [`07_genesis_routes_trace.json`](07_genesis_routes_trace.json) | Genesis machine trace. |
| [`08_pregen_sn_rust_paths.md`](08_pregen_sn_rust_paths.md) | Pre-Genesis and S(n)/MSS-N review. |
| [`09_pregen_coda_ddc_maps.json`](09_pregen_coda_ddc_maps.json) | Continuation, CODA and DDC trace. |
| [`10_coda_ddc_runtime_map.md`](10_coda_ddc_runtime_map.md) | Runtime ownership and preservation boundaries. |
| [`11_wdp_lggr_connections.md`](11_wdp_lggr_connections.md) | WDP/LGGR conceptual connections. |
| [`12_wdp_lggr_impl_review.md`](12_wdp_lggr_impl_review.md) | WDP/LGGR implementation evidence. |
| [`13_wdp_lggr_routes_data.jsonl`](13_wdp_lggr_routes_data.jsonl) | Machine route bindings. |
| [`14_wdp_lggr_read_traces.jsonl`](14_wdp_lggr_read_traces.jsonl) | Canonical reading coverage. |
| [`15_wdp_apps_rust_routes.md`](15_wdp_apps_rust_routes.md) | Papers, applications and native owners. |
| [`16_prompt_cochain_rules.md`](16_prompt_cochain_rules.md) | First finite execution contract. |
| [`17_plans_layer_findings.md`](17_plans_layer_findings.md) | PLANS-layer adversarial findings. |
| [`18_plans_layer_repaired.md`](18_plans_layer_repaired.md) | Reviewed repairs and remaining limits. |
| [`19_review_toc_and_grade.md`](19_review_toc_and_grade.md) | Table of contents for this directory, the next ten Omega Engine projects, and the B- code-quality grade. |
| [`20_documentation_conformance.md`](20_documentation_conformance.md) | Documentation-conformance report. That file pins `1340ebb4c4ab5b4186a99c38330d0b08eace5321`, not this HEAD. Its prose counts were not re-executed. |
| [`21_normal_form_inventory_and_quotient_laws.md`](21_normal_form_inventory_and_quotient_laws.md) | Normal-form inventory. Duplicate number 21. That file pins `4bdf074a1b18cdeb710d991336e35f8f62979542`. |
| [`21_pfp_yaml_inventory.md`](21_pfp_yaml_inventory.md) | PFP YAML inventory. Duplicate number 21. That file pins `1340ebb4c4ab5b4186a99c38330d0b08eace5321`. |
| [`22_normal_form_quotient_descent.md`](22_normal_form_quotient_descent.md) | Quotient-descent audit. Duplicate number 22. That file pins `1340ebb4c4ab5b4186a99c38330d0b08eace5321`. |
| [`22_pfp_type_inventory_and_cross_language.md`](22_pfp_type_inventory_and_cross_language.md) | PFP type inventory. Duplicate number 22. That file pins `4bdf074a1b18cdeb710d991336e35f8f62979542`. |
| [`23_cross_language_conformance.md`](23_cross_language_conformance.md) | Cross-language conformance. Duplicate number 23. That file pins `1340ebb4c4ab5b4186a99c38330d0b08eace5321`. |
| [`23_pfp_roundtrip_and_compression.md`](23_pfp_roundtrip_and_compression.md) | Roundtrip and Lean census prose. Duplicate number 23. That file pins `4bdf074a1b18cdeb710d991336e35f8f62979542`. |
| [`24_documentation_code_conflicts.md`](24_documentation_code_conflicts.md) | Documentation-versus-code report. Duplicate number 24. That file pins `4bdf074a1b18cdeb710d991336e35f8f62979542`. |
| [`24_sqlite_evidence_verification.md`](24_sqlite_evidence_verification.md) | SQLite evidence prose. Duplicate number 24. Its "21 views" and OPEN work-item statements do not match `argon_audit.sqlite3` as read this pass. |
| [`25_system_mathematical_synthesis.md`](25_system_mathematical_synthesis.md) | Synthesis note. That file pins `4bdf074a1b18cdeb710d991336e35f8f62979542`, not this HEAD. |
| [`26_wdp_gbind_obridge_investigation.md`](26_wdp_gbind_obridge_investigation.md) | G_bind and O_Bridge investigation. That file pins `4bdf074a1b18cdeb710d991336e35f8f62979542`. |
| [`27_four_paper_architectural_implications.md`](27_four_paper_architectural_implications.md) | Four-paper architectural synthesis (`WDP`, `FOC-002`, `FOC-035`, `Finite QM`). |
| [`28_asi_to_jeremy_woland_engine_refactor.md`](28_asi_to_jeremy_woland_engine_refactor.md) | Single-swarm `Woland` reasoning-engine refactoring blueprint. |
| [`29_woland_refactor_adversarial_tournament.md`](29_woland_refactor_adversarial_tournament.md) | Three-adversary tournament and converged `Woland` v2 implementation specification. |
| [`30_f004_papers_a_obstruction_projection_gravity.md`](30_f004_papers_a_obstruction_projection_gravity.md) | `F004_papers` review slice A: Obstruction Calculus, Projection Obstruction, Gravity. |
| [`31_f004_papers_b_quantum_and_finite.md`](31_f004_papers_b_quantum_and_finite.md) | `F004_papers` review slice B: Continuum Quantum, Finite QM, Quantum Foundations. |
| [`32_f004_papers_c_majorana_mub_rh_pfp.md`](32_f004_papers_c_majorana_mub_rh_pfp.md) | `F004_papers` review slice C: Majorana, MUB6, RH, RSI, Trace-Zero, LinkedIn, PFP. |
| [`33_obstruction_calculus.md`](33_obstruction_calculus.md) | Family `001_finite_obstruction_calculus` deep review. |
| [`34_proj_obstruction_gr.md`](34_proj_obstruction_gr.md) | Families `002_projection_obstruction` and `004_general_relativity` deep review. |
| [`35_quantum_and_finiteqm.md`](35_quantum_and_finiteqm.md) | Families `005_continuum_physics` and `006_finite_qm` deep review. |
| [`36_families_five_to_pfp.md`](36_families_five_to_pfp.md) | Families `007` through `015_pfp` deep review. |
| [`44_f004_family_001_deep.md`](44_f004_family_001_deep.md) | Family `001` sub-paper mathematical and mechanization audit. |
| [`45_projection_gr_contin.md`](45_projection_gr_contin.md) | Projection Obstruction, GR, and Continuum Physics audit. |
| [`46_quantum_finite_major.md`](46_quantum_finite_major.md) | Quantum Foundations, Finite QM, and Majorana audit. |
| [`47_remaining_f004_grade.md`](47_remaining_f004_grade.md) | Remaining `F004` families (`009`–`015`) audit and overall paper-estate grade. |
| [`woland_current_and_missing_architecture.md`](woland_current_and_missing_architecture.md) | Woland current-and-missing note. The 2026-10-14 body is unchanged. A 2026-10-16 code-quality evidence section was added. No `NN_` prefix. |
| `argon_audit.sqlite3` | SQLite database, 10,088,448 bytes. No `NN_` prefix. Not a gate. Master and selected row counts are in the refresh section. |

Joins:

- [architecture_review/](../architecture_review/)
- [rust_crates/README.md](../rust_crates/README.md)

## 1. One map and one implementation plan

**Current priority, 2026-10-15:** perfect the Rust capabilities needed by Woland
and PFP, then verify their composition under WDP's protected questions and
admitted transitions. The [closed selected native delivery record](../plans/epics/oewoland/epic_oe_woland_consolidated_residual_plan.md#delivered-boundaries)
selects contract composition, the real native application connection, and bounded
repair/reuse. Derivations require a named consumer or demonstrated system defect.
MUB6 is deferred unless a critical blocker is demonstrated; the same section
states the evidence needed to reopen it. This changes scheduling, not theorem
status. Draft [PR #995](https://github.com/dbccpage/the_symbol_game/pull/995)
centralizes crate tests and governance data and retains the bounded native
report/repair route; it does not establish the complete swarm route.

This combines the whole-estate review with the Woland application-to-Rust map.
The immediate objective is an Omega Engine that retains a task's source history,
preserves its protected answers, checks a proposed repair and reuses that
operation on a different task. Complete physical quantum reconstruction and
MUB6 classification are separate research programmes, not unconditional V1 gates.

Read these in order:

1. [Genesis to Rust](06_genesis_native_route.md): the first paper-level implementation
   review, with distinct source models, existing APIs and the next native seam.
2. [Pre-Genesis and S(n)/MSSN](08_pregen_sn_rust_paths.md): actual paper companions,
   generic report and integral chain owners, and unresolved claim bindings.
3. [WDP and LGGR connections](11_wdp_lggr_connections.md): complete canonical
   manuscript reading, 50 scoped connections and the corrected LGGR index.
   [Implementation evidence](12_wdp_lggr_impl_review.md) separates native
   owners, formal scope, fresh checks and application gaps.
4. [CODA and DDC runtime map](10_coda_ddc_runtime_map.md): measured cochains,
   supplied-diagnostic interfaces, Python consumers and preservation contracts.
5. [Application-to-Rust map](15_wdp_apps_rust_routes.md): application
   ownership, canonical mathematical crates and all nine PO paper links.
6. [Prompt/cochain contract](16_prompt_cochain_rules.md): the declared
   source interpretation, cochain data, solver/replay and terminal behavior.
7. [Woland residual plan](../plans/epics/oewoland/epic_oe_woland_consolidated_residual_plan.md):
   the closed delivery record; this review supplies its Genesis-first entry point.

The [source inventory](04_paper_source_catalog.json) was not regenerated this
pass. Seventeen tracked `omega_engine*` roots were re-counted from
`git ls-tree -d --name-only HEAD`. The six-family, six-LGGR-volume,
25-derivation, and nine-PO-paper figures in the 2026-10-15 text were not
re-counted. The
[Cargo inventory](05_rust_crate_inventory.json) file was not regenerated. A
fresh parse of `omega_engine/crates_rs/Cargo.toml` still has 54 declared
workspace members: 52 under `crates_rs` (including the shared test package)
and two finite-QM members outside it. Both external paths exist. Four
additional immediate Cargo directories, `omega_biology`, `omega_chemistry`,
`omega_economics`, and `omega_machine_learning`, are outside workspace
membership. Excluding `tests`, that is 55 production directories. A tracked
root is not a Python package; a Cargo member is not an integrated runtime
feature. These definitions resolve the previous review's unbound 19-package /
55-member comparisons. The 19-package comparison itself was not re-counted.

The [structured review](02_architecture_map_v01.yaml) holds the current
status of every historical finding. The [dashboard](03_architecture_dash_v1.html)
is a compact navigation view. Existing research obligations remain in the
[goal DAG](../../omega_engine_atlas/coda_atlas/F004_papers/plans/goal_dag.jsonl)
and existing native semantics remain in
[wdp_rust_routes.jsonl](../../omega_engine_atlas/coda_atlas/F004_papers/plans/wdp_rust_routes.jsonl).
None of these views creates another execution authority or certifies all papers.

The [PLANS-layer review](17_plans_layer_findings.md) audits all four planning maps,
their Python validators and native graph checks. It identifies five repair
targets, led by broad goals marked done through narrower finite controls.
Its source/API/fixture counts and current failing checks should guide planning
before any completion percentage is used as an engine-readiness measure.

## 2. What the Genesis review changes

The Genesis implementation is substantial and reusable. It is not one uniform
model. `omega_ooutwire_primitives` owns the admission regime; `omega_wdp` retains
and cross-checks its histories, ports the separate passage/refusal kernels, and
binds them to generic quotient, gluing, probability and computation owners.
The [13-route trace](07_genesis_routes_trace.json) records concrete paths and
symbols with their reviewed source bytes.

The selected Genesis paper DAG currently attaches all three claims to the
admission route. That route cannot discharge the paper's minimum-response census
or its canonical-byte theorem. Conversely, the fuller native registry already
contains passage, stable carrier, composition and other routes absent from that
small selected claim inventory. We should repair claim-to-owner specificity
before adding more undifferentiated derivations.

The next two papers reveal the same distinction. Pre-Genesis has a standalone
Rust replay, and the engine's integral chain-equivalence owner already checks
maps, homotopies, reconstructed fillings and obstruction transport. In contrast,
`MssnFunctorBridge` is a declaration record, and all three selected S(n) DAG
claim anchors remain unresolved. The new [continuation trace](09_pregen_coda_ddc_maps.json)
maps these scopes and the CODA/DDC interfaces without upgrading research status.

The current native action named `genesis_resolve` solves an LP for a supplied
complex, reading and weights. It does not expose the retained Genesis event
history contract. That is the first application seam to implement after freezing
its source profile and protected questions. Reuse the existing OS/native host,
source adapters and mathematical owners.

```mermaid
flowchart TD
    S[Genesis source model and admitted histories] --> W[omega_wdp source-specific profile]
    P[omega_ooutwire_primitives admission] --> W
    W --> Q[Category owners: questions, future quotient, gluing]
    W --> I[Explicit incidence interpretation]
    I --> M[Homology, linear algebra, functional and solver owners]
    Q --> R[Replay against original source and protected questions]
    M --> R
    A[Application task] -. planned history request .-> H[Existing OS and Symbol Game host]
    H -. profile to expose .-> W
    R -. planned task result .-> A
```

Solid edges describe inspected source relationships; dashed edges are the
proposed Genesis history consumer. No live end-to-end application was run.

## 3. Reconciled findings, retaining all original IDs

The original review is preserved at Git commit `8bc153ac8dfbe986fd324bf9cab0ca0ae8fa09f8`
under the three historical, unnumbered architecture-review paths recorded in
the structured map. It had static findings, historical run claims
and proposed architecture mixed together. This table gives each a current scope;
`SOURCE_CONFIRMED` means inspected code, not a reproduced production exploit.

| ID | Current status | Review and source |
| --- | --- | --- |
| FM-01 | `RESOLVED_2026_10_17` | `Verification52Gate.evaluate` (`gate_52/evaluator.py`) now evaluates deterministic domain, trace, halt-guard, metadata, and markdown predicates across all 52 items; `audit_paper_package` remains the disk-byte checker. [Source](../../omega_engine_research_papers/use_cases/gate_52/evaluator.py). |
| FM-02 | `PARTLY_CONFIRMED` | In `checklist.py`, `E06` intentionally stays `NOT_VERIFIED` unless static inspection detects blanket `ignore_missing_imports = true` (which sets `FAIL`), because `checklist.py` does not execute `mypy`/`ruff` subprocesses. [Source](../../omega_engine_research_papers/use_cases/paper_review/checklist.py). |
| FM-03 | `SUPERSEDED_AT_CITED_API` | PaperGateEngine now accepts PaperContext and evaluate_directory calls PaperContext.from_dir. The old dictionary-key diagnosis is stale; current rule behavior needs its own tests. [Source](../../omega_engine_research_papers/domain/rules/base_rule.py). |
| FM-04 | `SUPERSEDED_AT_CITED_API` | ClaimLedgerEvidenceResolvesRule now reads nested source evidence through _check_ledger. Preserve its current coverage limits; do not retain an obsolete schema diagnosis. [Source](../../omega_engine_research_papers/domain/rules/deposit_consistency_rules.py). |
| FM-05 | `REVALIDATION_REQUIRED` | Different ledgers may intentionally cover different claim populations. Current paper-wide consistency and exact counts were not rerun. Bind scopes before proposing one general bijection. [Source](../../omega_engine_atlas/coda_atlas/F004_papers/002_projection_obstruction/000_projection_obstruction/projection_obstruction_claim_ledger.yaml). |
| FM-06 | `SUPERSEDED_BUILD_PROFILE` | Current roots are Po000JordanLie, Po000JordanLieImage and Po000JordanTrace, not the three names in the old review. Compilation coverage requires the transitive import graph and actual commands; no current full-paper Lean pass is claimed. [Source](../../omega_engine_atlas/coda_atlas/F004_papers/002_projection_obstruction/000_projection_obstruction/lean4/lakefile.lean). |
| FM-07 | `RESOLVED_2026_10_17` | `LakeProofRunner` (`lake_runner.py`) fails closed on missing toolchain/compilation failure and now strips Lean line/block comments before scanning for word-boundary `sorry`, `sorryAx`, and `admit` tokens. [Source](../../omega_engine_research_papers/infrastructure/lean4_bridge/lake_runner.py). |
| FM-08 | `RESOLVED_2026_10_17` | Added `omega_engine_applications*`, `omega_engine_education*`, `omega_engine_library*`, `omega_engine_research_papers*`, `omega_simplex_autop*`, and `omega_simplex_cache*` to `[tool.setuptools.packages.find] include` in `pyproject.toml`. [Source](../../pyproject.toml). |
| FM-09 | `SCOPE_CORRECTED` | Xi retains floating-point diagnostics and omitted exact fields in display serialization; its evaluator-owned result cannot deserialize and binds to VerifiedExactPhi1. A numerical diagnostic is not automatically an exact-authority leak. [Source](../../omega_engine/crates_rs/omega_functional/src/xi.rs). |
| FM-10 | `SCOPE_CORRECTED` | ReplayPacket remains numerical and has explicit validation/residual diagnostics. Keep it distinct from exact replay; do not replace every diagnostic solely because it uses f64. [Source](../../omega_engine/crates_rs/omega_replay/src/replay_harness.rs). |
| FM-11 | `SCOPE_CORRECTED` | This module now explicitly labels its tolerance-based output f64 NumericalEvidence/Estimate. Inspect a claiming consumer before calling it an exact certificate. [Source](../../omega_engine/crates_rs/omega_solvers/src/cert_lggr_soundness.rs). |
| FM-12 | `DESIGN_PROPOSAL` | omega_types has the cited normal dependencies. A proposed five-tier assignment is not the actual dependency DAG; measure callers and cycles before splitting or reversing dependencies. [Source](../../omega_engine/crates_rs/omega_types/Cargo.toml). |
| FM-13 | `IDENTITY_DOCUMENTED` | Cargo package linear_algebra and directory omega_linear_algebra differ, as do omega_epk and its LGGR directory. These legal identities belong in the inventory; rename only for a concrete consumer need. [Source](../../omega_engine/crates_rs/omega_linear_algebra/Cargo.toml). |
| FM-14 | `SCAFFOLD_FENCED` | `omega_biology`, `omega_chemistry`, `omega_economics`, and `omega_machine_learning` are workspace members fenced by `tests/scaffold_not_certified.rs`. [Source](../../omega_engine/crates_rs/Cargo.toml). |
| FM-15 | `RESOLVED_2026_10_17` | `auto_p/src/compiler/emitter.rs` now emits `use omega_category_theory::finite_category::{FiniteCategory, MorphismMeta, MorphismKind};` backed by `omega_category_theory::finite_category`, and `auto_p/src/stubs/topos.rs` compiles cleanly under `cargo test -p auto_p --lib`. [Source](../../omega_engine/crates_rs/auto_p/src/compiler/emitter.rs). |
| FM-16 | `SOURCE_CONFIRMED_SCOPE_OPEN` | The standalone RSI companion reimplements SHA-256 and EIS logic. Its publication reproduction role and production caller status must be distinguished before migrating or removing it. RSI tests were not replayed here. [Source](../../omega_engine_atlas/coda_atlas/F004_papers/012_rsi/000_relational_reasoning_and_rsi_impossibility/code/rust_eis_companion.rs). |

The source-confirmed fallback and hard-coded-verdict issues remain important
before publishing through those particular APIs. A corrected context class or
an explicit numerical label does not certify its entire consumer chain. The RSI
review's historical 40-theorem/79-test result was not rerun and is not a current
verification result of this change.

## 4. Corrections to the proposed architecture

- **Traceability is many-to-many.** A claim may have several equations, tests
  and proof modules; a definition need not have a theorem or runtime test.
  `PaperBindingManifestV1` remains a design proposal. Bind each edge's scope,
  assumptions, source bytes, verifier command and unresolved obligations.
- **Lean coverage follows imports.** Listing a file as a root is neither
  necessary for an imported module nor sufficient for proving every advertised
  claim. Record the actual transitive compilation and audited theorem constants.
- **Exact replay has a cost.** An L1 primal/dual witness must check dimensions,
  primal residual, dual annihilation, dual bounds and matching values. Work grows
  with the input and arithmetic bit sizes; the previous O(1) claim is withdrawn.
- **A residual need not be a cohomology class.** `Phi1 > 0` shows distance from
  the declared repair image. A nonzero H1 interpretation additionally requires a
  square-zero complex and a closed residual (`Gamma2 = 0`). Curved PO-001
  restriction data obeying `D² = [K,-]` require their own contract.
- **Module names and tier drawings are not proofs.** Preserve legal Cargo names
  `linear_algebra` and `omega_epk` in commands. The actual dependency graph decides
  an extraction; an invented tier does not justify a package rename or reversal.
- **Reference code has a different role from runtime code.** Keep frozen source
  and independent publication reproduction. Remove duplicated production math
  only after source/consumer tracing and parity, using its existing Rust owner.

## 5. Delivery order and stopping condition

Start with the retained admission profile and protected-question counterexample
in the [Genesis review](06_genesis_native_route.md). Then review its declared continuation
model and translations. Use the completed Pre-Genesis/S(n) and CODA/DDC source
reviews to bind concrete report and preservation witnesses. The WDP/LGGR review
now supplies those papers' connection map and selected checks; Ongoing, Prime
and PO still need their remaining source-specific reviews. Finally bind the engine applications
to the verified routes, beginning with one real task and a distinct reuse task.

The existing Woland priorities remain: production paper-Python imports,
native-required CODA behavior, disconnected LGGR, and cochain computation versus
supplied diagnostic flags. Genesis gives these migrations a concrete source
contract. Do not begin a general prompt-to-mathematics compiler to avoid choosing
that contract.

PR #981 has since supplied DDC procedure persistence, custody readback and
reuse with prompt/premise binding and mandatory fresh checking. Reuse that
application path when adding the Genesis profile. A new task ID with unchanged
premises does not by itself establish transfer to a different mathematical task.

A milestone is complete when the declared input is replayed, answers are
preserved, invalid or insufficient inputs refuse truthfully, a repair is checked
against the original question, and another task reuses the same supported API.
Unrestricted native-history faithfulness, scalar reconstruction and physical
availability keep their research status. The engine can ship supported finite
profiles while those programmes remain open.

## 6. Verification and custody

The test totals, parity totals, epic-file totals, and strict-check citation
totals in this section are historical receipt figures. They were not
re-executed on 2026-10-16. AuthorityEffect: None. Markdown is not a gate.

The [Genesis receipt](../receipts/genesis_architecture_review_20261014.json)
separates source inspection, Python execution, compiled Lean and native tests.
The selected Genesis checks passed: **18 Python tests, 771 Python/source parity
cases and 25 Rust tests**, plus `GenesisContinuation.lean` with at most `propext`
and `Quot.sound` in its printed dependencies. These categories are not additive
counts of theorems.

The Cargo invocations exhausted the temporary disk while compiling automatic CLI
targets. The three selected integration-test files were then compiled directly
with `rustc --test` against the freshly Cargo-built current libraries and run.
This is a selected-test pass; the Cargo commands did not complete. The receipt
retains those failures, commands and library hashes. Full Genesis paper Lean,
publication archives, the broader crate and live application integration were
not certified here.

The [continuation receipt](../receipts/pregen_sn_coda_ddc_review_20261014.json)
adds **128 Python tests**, **14 standalone Cargo tests**, **28 direct native
tests**, and **33,104 Pre-Genesis Rust/Python parity records**. These are scoped
checks, not theorem counts. Adapter tests include mocked subprocesses; actual
Rust execution is recorded separately. No new Lean build or live application
run is claimed. The earlier receipt's document hashes bind the Genesis review
at `212cb2d10c`, before this continuation changed the navigation views.

Remote main had deleted 15 epic files while retaining a 55-entry manifest. This
review reconciles those exact Git-recorded deletions, then includes OEWOLAND-004:
**40 current main epics + 1 new epic = 41**. The canonical generator rebuilds byte
custody; no remaining epic is omitted. Historical receipts retain their original
55/56-file scope. No paper source, source archive or research-goal status was
changed to make these planning checks pass.

The earlier goal-DAG check failed on two PO-035 review witnesses. The
[PLANS repair review](18_plans_layer_repaired.md) now binds their original Git review,
splits 33 over-broad completions and checks claim/goal/native-contract joins.
Ordinary checking passes. Strict checking retains 42 citations to six unavailable
external files, including references inherited by scoped children. The nine
architecture-fitness findings remain separate; this is not an estate-wide pass.

The [WDP/LGGR receipt](../receipts/wdp_lggr_review_20261014.json) adds a
complete reading of the original 18,046-line canonical Markdown corpus,
155 Python tests, 36 fresh Rust-module tests and three Lean compatibility
compiles. It records the cached Rust dependency boundary and the Lean compiler
pin mismatch. The LGGR index and README were corrected; proposed WDP status
edits, full publication reproduction and application integration remain separate.

## Current review additions, 2026-10-18

The [single current guide](19_review_toc_and_grade.md) explains the reports and ten proposed projects. The following source-bound reports extend the dated maps above.

- [49_native_runtime_review.md](49_native_runtime_review.md)
- [50_genesis_coda_wdp_lggr_review.md](50_genesis_coda_wdp_lggr_review.md)
- [51_pfp_runtime_and_prompt_review.md](51_pfp_runtime_and_prompt_review.md)
- [52_woland_workflows_and_swarm_review.md](52_woland_workflows_and_swarm_review.md)
- [53_governance_immune_and_pciv_review.md](53_governance_immune_and_pciv_review.md)
- [54_operations_oeos_and_cognitive_review.md](54_operations_oeos_and_cognitive_review.md)
- [55_formal_math_and_normal_form_review.md](55_formal_math_and_normal_form_review.md)
- [56_applications_security_and_test_review.md](56_applications_security_and_test_review.md)
- [57_atlas_library_and_research_infrastructure_review.md](57_atlas_library_and_research_infrastructure_review.md)
- [58_planning_and_architecture_evidence_review.md](58_planning_and_architecture_evidence_review.md)
- [59_education_runtime_and_documentation_conformance_review.md](59_education_runtime_and_documentation_conformance_review.md)
- [60_papers_finite_obstruction_deep_review.md](60_papers_finite_obstruction_deep_review.md)
- [61_papers_genesis_ongoing_deep_review.md](61_papers_genesis_ongoing_deep_review.md)
- [62_papers_projection_and_quantum_deep_review.md](62_papers_projection_and_quantum_deep_review.md)
- [63_papers_physics_frontiers_deep_review.md](63_papers_physics_frontiers_deep_review.md)
- [64_documentation_prose_and_curriculum_review.md](64_documentation_prose_and_curriculum_review.md)
- [65_documentation_audio_video_and_accessibility_review.md](65_documentation_audio_video_and_accessibility_review.md)
- [66_review_coverage_and_checks.json](66_review_coverage_and_checks.json)

## Current review additions, 2026-10-20

The [refreshed guide](19_review_toc_and_grade.md) re-reads reports 48–65 at source pin `c419cc6beb19817065de08a33d3d81f999d6b0ba` and marks which older maps in this folder are current, stale or historical. The census figures earlier in this document describe their own dated passes; the pin has 103,287 tracked files.

- [48_workspace_and_delivery_review.md](48_workspace_and_delivery_review.md)
- [67_focused_runtime_repairs.md](67_focused_runtime_repairs.md)
- [68_review_refresh_coverage_and_checks.json](68_review_refresh_coverage_and_checks.json)
