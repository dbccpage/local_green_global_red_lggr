# Finite obstruction, PFP and public essays: manuscript review

## Current-source review: 2026-10-22

AuthorityEffect: None. Source pin `305b9690f97fc3f5c13e361cfe752a6d5dc7ad8d` on `feat/crates-rs-l4e-scoring`. That is the SHA expected at dispatch. The worktree is dirty outside this slice; the paper paths below were read from the worktree and compared with `c419cc6beb19817065de08a33d3d81f999d6b0ba..HEAD`.

**Verdict.** The two prior high results are still present. PFP 022's canonical echo and targeted schedules still insert only a gate and its inverse in front of the unmitigated word, so those braid actions are equal; Table 1's common mean `23/1200` is that identity, not a measured mitigation. PFP IV still titles the passage from face sums 7 and 5 to the zero vector an "exact repair"; Gamma2 of the before vector is 12 and is not a coboundary invariant of the zero class. Neither source file changed. The new manuscript work is PFP 028, an implementation study with no theorem, and scope sections added to PFP 023 and 025 without rewriting their finite proofs. Deposit gates for LGGR II, III and IV, and for the role paper, now accept `Classical.choice` while their unchanged claim maps still describe a stricter census. The slice grade remains **B-** (family 001: **B**; family 015: **C+**; family 014: **B-**).

Evidence labels: **W** a written derivation read in this pass; **L** a Lean statement read and not compiled; **R** an archived receipt or local-run claim not reproduced; **C** a check run in this pass.

### What changed since 2026-10-20

`git diff --name-status c419cc6beb19817065de08a33d3d81f999d6b0ba..HEAD` over the three assigned folders includes the excluded `001_genesis_ongoing_h3v7n5qf/` subtree. That subtree is not graded. Excluding it, `git diff --stat` reports 81 files, 1810 insertions and 163 deletions. Most of those lines are `lean-toolchain` pins, lake manifest pins, or two-line axiom-whitelist edits. The manuscript changes inside the grade are:

- New `015_pfp/028_pfp_operadic_composition_and_bounded_ddc_repair/` (paper, TeX, PDF, README, docs). No numbered theorem.
- `015_pfp/023_.../paper.md` and `015_pfp/025_.../paper.md` gain a four-line header, an authorization row, a section 7, and a relative link that now points at the WDP manuscript. The finite proofs and `code/replay.py` are not in the diff.
- `015_pfp/README.md` lists 028 as an author-review implementation study, not a sixth finite theorem.
- WDP `witness.py` now raises if a pilot kill flag is `None`. `Observer.lean` writes the recall field with escapes; `encode_recall` is the same statement. `AmplitudeBridge.lean` and `InstrumentAdapter.lean` change proof tactics only. The WDP manuscript is not in the diff.
- LGGR II, III and IV `verify_deposit.py`, both LGGR II and IV artifact builders, and the role-paper `verify_deposit.py` add `Classical.choice` to `AXIOM_WHITELIST`. The claim-map sentences were not edited. LGGR V's lakefile moves its mathlib pin; its manuscript was not edited.

PFP 022 and PFP IV were not in the diff. Their decisive pages were re-read anyway.

### The two prior high results, re-read

**PFP 022, canonical tournament. OPEN.** Sources unchanged. The default sweep still targets `hadamard_q1` (`adaptive_braid_tournament_demo.py` around the `run_sweep` default). The echo word is `("phase", (1, 0))`, `("phase", (1, 1))`, `("hadamard", (1, 0))` (lines 301-305). The targeted word prepends `("elementary", (j, 0))`, `("elementary", (j, 1))` (lines 330-335). In `majorana_multiqubit_noise.py`, the second component is the inverse flag. The Rust compiler (`omega_majorana/src/multiqubit_braid.rs`) sends phase qubit `q` to the single elementary index `4q-3` and hadamard to the three-step word at `4q-2`, `4q-3`, `4q-2`, preserving that flag. `braid_action.rs` `append` right-multiplies one elementary step; the inverse branch flips the other sign. **C:** transcribing `append` on 8 modes, the echo word equals the bare hadamard word, and elementary index 3 followed by its inverse and then hadamard also equals bare hadamard. The same cancelation is what `phase_and_hadamard_inverse_words_cancel` states for a phase or hadamard pair. The defect is a function of the composite matrix and `K` (`MultiQubitNoisyBraidReferee.evaluate`). Equal actions therefore give equal defects. Table 1 still prints `23/1200` for the unmitigated, echo and targeted rows (`paper.md` lines 66-69). The abstract's "adaptive echo sequences preserve operator commutation" is still this identity. The max-entry formula is still written with an ell-one symbol (`paper.md` lines 30-32); the demo docstring calls the same quantity a max norm. The receipt digest is still unkeyed SHA-256 (demo lines 289-307). `_query_openrouter` still returns `None` on any exception (lines 274-276).

**L8 is not the same identity. New, below.** Echo there repeats `phase` with flag 0, and targeted repeats `elementary` with flag 0 (`l8_n4_cross_validation.py` lines 403-418). Those prefixes are not inverse pairs.

**PFP IV. OPEN.** `004_.../paper.md` lines 203-241 are unchanged. The section is still "exact repair". The before vector `(3,2,2,1,1)` on edges `(0,1),(1,2),(2,0),(1,3),(3,0)` has face sums 7 and 5. **C:** Gamma2 = 12. With head-minus-tail coboundaries and potential `(0,-2,-2,-1)`, the residual is `(5,2,0,0,0)` and Phi1 = 7, matching the printed attainment. The accepted candidate is the zero vector, whose face sums are 0. Face sums are unchanged by coboundaries because `d1 d0 = 0`, so zero is not in the before vector's repair class. It is a replacement of the report, in the sense already used by PFP I. The sentence that the two faces "span both independent cycles, so the replayed normal form is the zero vector" names the cycle space; it does not exhibit a potential taking `(3,2,2,1,1)` to zero. "Replayed normal form" is still undefined.

### New findings (2026-10-22)

| ID | Sev | Location | Mechanism | Failure scenario | Acceptance test |
| --- | --- | --- | --- | --- | --- |
| N15 | medium | `015_pfp/022_.../code/l8_n4_cross_validation.py:403-418`; `paper.md:86-88`; `omega_majorana/src/braid_action.rs:168-186` | L8 echo prepends two copies of phase on qubits 2 and 3. L8 targeted prepends two copies of the same elementary step. **C:** on 16 modes those prefixes are not the identity. Each is a sign flip on one adjacent mode pair (the comment's "R_j^2 = -I on mode pair"), not a global scalar, and not `g` then `g^{-1}`. Because later steps are right multiplications, a non-identity prefix yields a different composite from the target-only word. Table 2 nevertheless prints the same mean `105727/15708000` for unmitigated and targeted. | A reader treats that shared mean as the canonical inverse-pair identity, or as evidence that the extra braid was inert. | Either show, from retained per-round matrices, why those unequal actions have equal held-out defects, or stop printing one mean for both strategies. |
| N16 | medium | LGGR II `verify_deposit.py:113` and `docs/lean_claim_map.md:9`; LGGR III `verify_deposit.py:132` and `docs/lean_claim_map.md:43`; LGGR IV `verify_deposit.py:76`, `docs/lean_claim_map.md:9,46`, claim ledger; role paper `verify_deposit.py:69` | Each whitelist gained `Classical.choice`. The claim maps did not. LGGR II still requires the marker "one uses only `Quot.sound`". LGGR III still says reports used only `propext` and `Quot.sound`. LGGR IV still says the census stays inside `{Quot.sound, propext}`. The archived axiom-report files were not in the diff. | A later census that uses choice passes the gate while the printed axiom result still describes the old set. | The whitelist, the claim-map sentence and a freshly elaborated report name the same axiom set, or the ledger says the gate was widened and the old census is historical. |

No new high finding. PFP 028 does not contradict its own non-claims. Its six implementation files match `docs/source_provenance.json` at this worktree, and those paths are unchanged from `6d9da6fa7919ae2a8b99b704e784e5a4f422aed2` to HEAD (that commit is an ancestor). The raw receipt is not in the package (`observed_execution.json`: `raw_receipt_distributed_in_this_package` is false). That is a custody limit, already stated, not a second mitigation-style contradiction.

### Status of prior high and medium items

| Item | Status | This pass |
| --- | --- | --- |
| N1 canonical inverse-pair mitigation | OPEN | Re-read and checked. See above. |
| N2 L8 target check is label membership | OPEN | `_verify_target_gate` (lines 375-388) still tests `("cnot", (1, 4))` and similar labels. Refused rows still store defect `Fraction(1, 1)` (line 289) and can enter the mean. |
| N3 demo tests do not collect | OPEN | Import target `omega_engine_projects/ms_majorana/code/majorana_multiqubit_noise.py` is absent (**C**). The module is present under `009_ms_majorana/code/`. Pytest was not collected again. |
| N5 "exact repair" changes class | OPEN | Re-read and checked. Gamma2 stays 12 on the before vector and drops only because the candidate is a different class. |
| N6 monograph 028 imported homes absent | OPEN | Lines 53 and 1057 still say the T1-T15 files were read at `omega_engine/research/encyclopedia/archived_research/encyclopedia_anomalon/`. That directory is absent. `999_Layered Authority Framework/v1.3_preprint.md` is not tracked. |
| N7 paper 11 section 3.6 uses retired CH14 names | OPEN | Lines 135-139 still define `WDP-CH14-T01` as the three-axis regress and `WDP-CH14-C01` as the old demarcation. WDP lines 4829-4861 still give those identifiers to the target-separating report theorem and the post-processing corollary, and still say the three-axis text was replaced. |
| N8 S(n) section 6 describes the old carrier | OPEN | `paper.md` lines 190-202 still apply `sectionLift` to `.nonDescent` and still treat `Carrier.higher` as a constructor of the retained model. Retained `SnCarrier.lean` types `sectionLift` on `BasePresentation` and sets `Carrier n := Fin (carrierCard n)`. The refusal round trip lives on local `unconstrainedSectionLift` in `SnCarrierDischarge.lean`, not on the retained section. |
| Action 1, PFP 022 norm, signature, fallback | OPEN | Lines 16, 23, 31 and 274-276 as cited above. Extended by N15, not repaired. |
| Action 2, observer particular-preimage biconditional | OPEN | Essay 001 lines 209-214 still say that if `delta = d0 f`, then repairability holds if and only if that `f` is in `Adm`, "which means" `delta` is in `B_O`. A second admitted preimage makes the particular-preimage test false while `delta` is still admissible. |
| Action 3, PFP 027 checker scope | OPEN | `verify_b_cohomology_exact_certificate_checker` still checks one F2 matrix identity and one signed triangle. `verify_committed_c004_and_c006_receipts` still returns `True` when `omega_engine_pfp/tests/demo_004/a_mechanism` is absent. That directory exists in this worktree, so the vacuous branch is not the path taken here. |
| Action 4, family 001 navigation | NOT RECHECKED | `001_finite_obstruction_calculus/README.md` was not opened. N10 stays carried OPEN. |
| Action 5, authority as constructor or policy facts | OPEN | `AuthEvidence` is still two strings and a `Bool` (`ResidualNonCreation.lean` lines 37-41). `promotesAuthority` is still `false` and `anomalon_does_not_promote` is still `rfl` (`FiniteBoundary.lean` lines 100-103). |
| Action 6, do not apply the old three-axis criticism to current WDP 14.8 | OPEN | The WDP paragraph is still the corrected one. The stale three-axis wording is still paper 11 (N7), not WDP 14.8. |

Prior lows: N9 and N13 were re-read and stay OPEN. `sharp_m5_bound` (`FiniteDistinction.lean` lines 106-114) still checks `R_0(0,1)` and `R_3(0,1)` and does not state `R_2(0,1)` or `R_3 = R_4`. Essay 001 lines 240-252 still set Phi of `c = (1,1)` to 2 and `sqrt(2)` without unit weights or a minimization. N4, N10, N11, N12 and N14 were not reopened. Their files are not in the in-scope manuscript diff. Carried status: OPEN. That is five lows not rechecked, not a claim that they were repaired.

Of the 55 prior per-text rows, the manuscripts reopened at a decisive locus are 03 (WDP 14.8 only), 10, 11, 24 (imported-home paragraphs), 27 (one Lean theorem), 35, 44, 45, 47, 49 (replay functions) and 50 (essay 001 loci). Rows 45 and 47 changed and are summarized below. The other rows sit on manuscripts that were not reopened. Their prior OPEN or CHANGED status is carried. Entry 10 stays CHANGED relative to the 2026-10-18 carrier repair and OPEN as N8. No prior row is FIXED.

### Texts opened this pass

| Text | Derived | Wrong | Remaining |
| --- | --- | --- | --- |
| PFP 022 paper and schedules (W, C) | On 8 modes the canonical echo word and the canonical targeted word, for elementary index 3, compile to the same signed permutation as bare hadamard. The referee's defect depends on that matrix and `K`. | OPEN N1-N3 and the norm/signature/fallback wording. New N15: L8 targeted and echo prefixes are not identity, but Table 2 equates the targeted mean with the unmitigated mean. | A schedule with a genuinely different `U`, implementing the requested gate, and a lower held-out defect, from receipts that keep refused rows out of the mean. |
| PFP IV section 6 (W, C) | Face sums 7 and 5, Gamma2 = 12, Phi1 = 7 by the residual `(5,2,0,0,0)`. The zero vector is exact. Admission of that laboratory route is still refused in the table. | Calling the jump between these classes an exact repair. The normal-form sentence does not produce a coboundary. | Define the normal-form map. State that candidate minus before is not in the image of `d0`, and keep Gamma2 = 12 on the before class. |
| PFP 023 (W) | Unchanged scope theorem: if each checker is sound, a receipt for `J_checked` yields the conjunction of those predicates and no other predicate. The `(1,0)` versus "every solution has `x=1`" counterexample is intact. | The prior missing prose-to-obligation extractor remains. Section 7's gloss of `REPAIRED` omits the code's nonempty `changed_paths` conjunct (`ddc_code_repair_v1.py` `assess`, lines 136-147). | One extractor fragment with a source-span check. If section 7 is kept, state the path-change conjunct. |
| PFP 025 (W, C) | Unchanged gluing theorem: a locally permitted family has a unique glued assignment on the union exactly when pairs agree on overlaps. The Boolean triangle still has three nonempty local relations and no global solution. | `check_family` still returns `(0,0,0)` for three rows and zero relations, and for three rows and only two relations (**C**). Section 7 does not mention that hole. The five named controls can pass while the malformed calls succeed. | `check_family` returns a refusal unless three relation tables of the task schema are supplied. |
| PFP 028 (W, C, R) | No theorem. The implementation split is the table in section 2. The trace is the constant `STAGES = ("C","R","E","I","M","T")`. `assess` returns `REPAIRED` only when there is no refusal, some baseline check failed, no post-check failed, and `changed_paths` is nonempty. The toy source returns `n` for `n<0` and `n-1` otherwise; the patch writes `n+1`. **C:** the two asserts fail then pass as exits `[1,0]` then `[0,0]`. | The six-step `REPAIRED` run, the immune `NOT_MEASURED` record, and "22 pytest cases passed" are local claims. The receipt file is outside the package, so those sentences are **R**. They are not a false finite identity. | Put the raw receipt next to the recorded SHA-256, or keep every such number explicitly unreproduced. Do not promote the example to a descent law; the paper already refuses that promotion. |
| PFP 027 replay (W) | The two small algebraic checks (F2 boundary identity; frustration 0 versus 2) are real calculations on their fixtures. | They are not an audit of ten verifiers. Absence of the receipt directory is still success. | Missing receipts return an explicit missing status. |
| WDP 14.8 and the touched Lean (W, L) | Target-separating obstruction: equal reports and unequal protected answers block every report-only decoder. `encode_recall` is still `encode(recall mark) = mark`. The amplitude lemmas that changed are tactic lines, not new statements. | Nothing new in 14.8. The pilot witness previously treated an undecided `None` kill flag as failure-to-kill; it now raises. That is a control fix, not a manuscript theorem. | The open R10/R11 transport obligation is untouched. The escaped `recall` projection was not compiled. |
| Paper 11 section 3.6 (W) | The use-notes correctly say axes 2 and 3 of the old text are not used as proved steps. | The identifiers still point at theorems WDP has replaced. | Cite the current CH14 statements, or pin the historical WDP text that contained the three axes. |
| S(n) section 6 and both Lean files (W, L) | Free-monoid non-isomorphism is elsewhere in the paper and was not the reopened locus. The discharge file does prove a round trip for its local unconstrained lift, by `rfl`. | The manuscript assigns that bug to the retained `sectionLift`. | The old-image statement on `BasePresentation`, as N8's acceptance line. |
| Monograph 028 homes (W) | The root-fence paragraph says the imported chain is not a genesis derivation. That local caveat is clear. | The T1-T15 premises are still cited at an absent path, with a claim that they were read. | In-deposit proofs or tracked citations. |
| Essay 001 repair paragraph (W) | Quotient versus direct residual, depending on whether `B_O` is a subgroup, is the right split. | The particular-preimage biconditional, and the unstated unit-weight reading of Phi. | Existence of an admitted preimage, plus the two-line minimization. |
| LGGR II-IV gates and role whitelist (W) | The claim maps still record a choice-free or `Quot.sound`/`propext` census. Those sentences were not shown false of the old report files. | The executable acceptance set is now wider than the sentence the same package requires. Not re-elaborated. | One axiom set, named in both places. |
| Firewall and Anomalon constructors (L) | Coproduct separation is a statement about a freely built record. `authorizeLift` is the predicate `metric > 0`. | Neither constructs an issuer. | Unchanged from action 5. |

PFP README's new paragraphs match the papers: 028 is not offered as a finite theorem, and 023/025 are described as revisions around unchanged finite results. That description matches the diff.

### Family grades

| Family | Grade | Rationale |
| --- | --- | --- |
| 001 foundations | B | The reopened finite statements (report obstruction, discharge `rfl`, `sharp_m5_bound` as far as it goes, authority constructors) still say what their proofs say. The new defect is the widened axiom gate (N16), not a broken finite identity. N6, N7 and N8 remain. |
| 015 PFP | C+ | Gluing, scope, the six-stage repair predicate and the Phi1/Gamma2 arithmetic are in good shape. PFP 022 still reports an identity as mitigation, and PFP IV still names a class change an exact repair. PFP 028 is careful and does not lift the family. |
| 014 essays | B- | No essay file changed. The false repair biconditional and the unstated weights were re-read. The other four essays were not reopened. |
| Overall | B- | Same weighing as 2026-10-20: finite arguments with an internally contradicted methods paper and evidence language past the sources. |

### Three most serious defects

1. PFP 022 canonical "mitigation" is insertion of `g` then `g^{-1}`. The braid action equals the unmitigated hadamard action (**C**), and Table 1 prints one defect for all three.
2. PFP IV calls a move from Gamma2 = 12 to the zero vector an exact repair. No coboundary changes those face sums (**C**).
3. LGGR II, III and IV now accept `Classical.choice` in the deposit gate while the unchanged claim maps still say the census uses only `Quot.sound` and `propext` (N16). N6, the absent T1-T15 homes, remains the sharpest imported-dependency gap and is not repaired.

### What remains to be derived

One schedule whose compiled matrix is not the baseline matrix, which implements the requested gate by a matrix comparison, and whose held-out defect is smaller on retained rationals with refusals excluded; a definition of PFP IV's normal form that either exhibits a potential or is labeled replacement; an axiom census in which the whitelist and the claim-map sentence name the same set; tracked proofs or citations for the monograph's T1-T15; the current CH14 identifiers in paper 11; the old-image law on `BasePresentation`; a `check_family` that refuses a missing relation table; and an in-package copy of the PFP 028 receipt if those exit codes are to be more than a local note. The finite gluing theorem, the scope conjunction and the toy `adjust` exits do not close any of those steps.

### Checks run

| Command | Exit | Scope |
| --- | --- | --- |
| `git rev-parse HEAD` and branch | 0 | `305b9690f97fc3f5c13e361cfe752a6d5dc7ad8d`, `feat/crates-rs-l4e-scoring`. |
| `git diff --name-status` and `--stat` for the three folders, with a second stat excluding genesis-ongoing | 0 | Change list only. Genesis-ongoing not graded. |
| `py -3.12 -I -c` transcribing `MajoranaBraidAction.append` | 0 | Echo word equals bare hadamard on 8 modes; elementary `(3, false)` then `(3, true)` then hadamard equals bare hadamard; `(3, false)` twice is the sign flip on modes 3 and 4, not identity and not global minus identity. On 16 modes the L8 echo prefix and the repeated-elementary prefix are not identity. |
| same process, exact integers | 0 | Face sums 7 and 5, Gamma2 = 12, residual `(5,2,0,0,0)`, Phi1 = 7. Zero is a different class. `adjust` exits `[1,0]` then `[0,0]`. |
| same process, inlined `check_family` | 0 | `check_family(((0,0),)*3, ())` and `check_family(((0,0),)*3, (EQ, EQ))` both return `(0,0,0)`. |
| same process, SHA-256 of the six PFP 028 sources | 0 | Each working-tree hash matches `source_provenance.json`. |
| `git rev-parse --verify 6d9da6fa...`, ancestor test, `git diff --stat` of those six paths, `git ls-files` / directory tests | 0 | Provenance commit is an ancestor and those six paths do not differ from HEAD. `omega_engine/research` is absent. The PFP 027 mechanism directory exists. The demo's `omega_engine_projects` import target does not. |

No Lean elaboration, lake build, cargo run, full pytest, network call or Zenodo lookup was run. The braid check is a transcription of the Rust `append` steps, not a call to the native host. The PFP 028 receipt SHA-256 was not recomputed.

### Not opened

Genesis-ongoing, including its diff. WDP outside lines 4829-4861. Essays 002, 003, 004, 005 and the prompt companion. PFP 000-003, 005-011, 021, 024 and 026, except where a prior row is carried. Family 001 README. Full claim ledgers, axiom-report bodies, and bibliographies. The external directory named as holding `pfp-paper028-ddc-20261021/run/receipt.json`. Every manuscript whose prior row is described above as carried rather than reopened.

## 2026-10-20 baseline (historical)

AuthorityEffect: None. Source pin c419cc6beb19817065de08a33d3d81f999d6b0ba.

**Verdict.** No manuscript, Lean file or replay helper in this slice changed between the 2026-10-18 pin and this pin, so no prior finding is repaired. Of 61 prior units (six action items and 55 per-text entries), 60 are OPEN and one is CHANGED. This pass adds 14 findings: one high, six medium and seven low. The most serious new result is that the two "mitigation" strategies of PFP 022 compose to the same braid matrix as the unmitigated strategy in its canonical tournament, so the reported mitigation effect is zero by construction. The slice grade for derivation quality is **B-** overall (family 001: B; family 015 PFP: C+; family 014 essays: B-). This register carried no grade on 2026-10-18, so this is its first grade; because the sources did not change, the same grade would have applied at the old pin.

Evidence labels used below: **W** a written derivation read in this pass; **L** a source-visible Lean statement and proof term, not compiled; **R** an archived receipt or axiom report, not reproduced; **C** a check run in this pass (commands under "Checks run"). A finding that cites only W or L is a static source result.

### What changed since 2026-10-18

- `git diff --name-status 000ee9b0c2..HEAD` over `001_finite_obstruction_calculus/`, `014_linkedin_articles/` and `015_pfp/` lists 19 files. Eighteen lie in the excluded `001_genesis_ongoing_h3v7n5qf/` subtree. The only in-scope change is `001_local_green_global_red_foundational_series/lggr_v_local_green_global_red/code/test_release_verification.py` (commit `a1d6d67059`, merged through PR #1237 as `745f661069`). It replaces `monkeypatch.setitem(sys.modules, ...)` with an explicit try/finally restore. It touches no LGGR V derivation.
- Remediation ledger [`findings.json`](../plans/review_remediation/findings.json): `REPORT-60` and `P60-001` to `P60-055` are all `OPEN_REQUIRES_SOURCE_RECHECK` with empty `merged_prs`. `NEW-08` records the LGGR V test-isolation repair; it is unrelated to the derivations reviewed here.
- External state that moved: the education module `omega_engine_education/documentation/002_oesn/lean4/SnCarrier.lean`, which paper 10 cites, now has a restricted `sectionLift` domain. That turns prior entry 10 into CHANGED (finding N8).

### Slice grades

| Family | Grade | Rationale |
| --- | --- | --- |
| 001 foundations (30 texts) | B | Central finite results (report factorization, weak duality, attainment, LGGR sign and soundness criteria, density-lift bound, guarded-schedule classification) are correctly derived under stated premises at the loci read. Defects are mostly scope: Lean statements narrower than prose (`sharp_m5_bound`, `general_finite_certificate_optimality`), stale cross-paper identifiers (002 section 3.6), a stale model description (S(n) section 6) and unresolvable imported dependencies (028). |
| 015 PFP (19 texts) | C+ | The graph-repair, signed-graph, composition and compression theorems are sound and short. PFP 022 is the weak point: its mitigation claim is contradicted by its own tables and code, its tests cannot be collected, and its norm and signature wording is wrong. PFP IV labels a class-changing replacement an "exact repair". Two replay checkers accept malformed inputs (025, 027). |
| 014 essays (6 texts) | B- | CHSH, report-factorization, tag-count, recovery-defect and logit-patching arithmetic all check. One false biconditional (observer essay line 214) and several unscoped general statements remain. |
| Overall | B- | Coherent finite mathematics with bounded defects, weighed down by one internally contradicted research-methods paper and by evidence statements that outrun their sources. |

### New findings (2026-10-20)

| ID | Sev | Location | Mechanism | Failure scenario | Acceptance test |
| --- | --- | --- | --- | --- | --- |
| N1 | high | `015_pfp/022_pfp_frontier_research/code/adaptive_braid_tournament_demo.py:301-305, 330-335`; `paper.md:16, 66-69` | The echo schedule is `phase(1)`, `phase(1)^-1`, `hadamard(1)`. The targeted schedule is `elementary(j)`, `elementary(j)^-1`, `hadamard(1)`. Each inserted pair is g·g^-1, so U equals the unmitigated `hadamard(1)` matrix, and the defect of UKU^T - K depends only on U. Table 1 confirms it: all three strategies report 23/1200. In the L=8 run (`l8_n4_cross_validation.py:413-418`) "echo" adds S^2 = Z on spectators and raises the mean defect (109/12000 against 105727/15708000). | A reader takes the abstract's "adaptive echo sequences preserve operator commutation" as a measured mitigation effect. | A strategy is reported as mitigating only if its composite U differs from the baseline U and its defect is lower on held-out noise; a test asserts that identity-equivalent schedules yield equal defects and are labeled as such. |
| N2 | medium | `022/.../code/l8_n4_cross_validation.py:375-388, 289`; `paper.md:80, 89` | `_verify_target_gate` tests membership of gate labels such as `("cnot", (1, 4))` in the operation list. It does not compare the composite matrix with the target gate. Refused rows enter the mean with the sentinel defect 1. | `cnot(1,4)` followed by `cnot(1,4)` (the identity) passes "Target Operation Equivalence"; Table 2's "Mean Noise Defect 1.0" averages a sentinel, not a measurement. | The target check compares the composite signed-permutation matrix with the target gate matrix; refused rows are excluded from defect means and counted separately. |
| N3 | medium | `022/.../code/tests/test_adaptive_braid_tournament_demo.py:21`; `paper.md:16` | The demo imports `majorana_multiqubit_noise` from `omega_engine_projects/ms_majorana/code` (`adaptive_braid_tournament_demo.py:39-52`), which is absent; the module lives under `F004_papers/009_ms_majorana/code/`. | Test collection fails (C: pytest exit 2, `ModuleNotFoundError`), so the abstract's "automated test suites with 96% coverage" has no reproducible support at this pin. | Collection and the package tests pass from the package root with the corrected import, and the coverage figure is regenerated from that run. |
| N4 | low | `022/paper.md:71` | "Structured mitigation ... 2/3, unmitigated random baselines ... 1/3" is reported for an unspecified regime. With Table 1's four budgets per agent, a per-agent rate is k/4, so 1/3 is not attainable there. | The rates cannot be reproduced or traced to a table. | State the budgets and round counts and regenerate the rates from a retained receipt. |
| N5 | medium | `015_pfp/004_pfp_native_verification_and_evidence_custody/paper.md:203-241` | Section 6 is titled "exact repair". The before vector has face sums 7 and 5, so Γ2 = 12; Φ1 = 7 (C, exact). Γ2 is invariant under adding any coboundary because d1 d0 = 0, yet the accepted candidate (0,0,0,0,0) has Γ2 = 0. The candidate therefore lies in a different repair class: it is a report replacement in the sense of PFP I (`001_.../paper.md:113-118`). "Replayed normal form" is never defined. | A reader concludes that the host repaired (3,2,2,1,1) by a potential, which no potential can do. | Define the normal-form map; either show candidate minus before lies in im d0 or relabel the route as replacement with Γ2 and Φ1 retained in the outcome. |
| N6 | medium | `001_finite_obstruction_calculus/028_finite_authority_and_non_terminal_computation/finite_authority_and_non_terminal_computation_monograph.md:53, 1057` | The text says the T1-T15 homes are "present at the corrected path above and were read in this pass", at `omega_engine/research/encyclopedia/archived_research/encyclopedia_anomalon/`, and cites `999_Layered Authority Framework/v1.3_preprint.md` as controlling. Neither path is tracked at this pin, and `git log --all` finds no history for `omega_engine/research`. | Every imported T1-T15 step and the Known Gate premise rest on sources a reader cannot open. | Each imported claim cites a tracked file and line, or is restated with its proof inside the deposit; the paragraph no longer asserts a reading that cannot be replayed. |
| N7 | medium | `001_.../002_asi_no_go_theorem_epistemic_contextuality/epistemic_no_go_monograph.md:135-139` | Section 3.6 attributes a "three-axis self-grounding regress" to WDP-CH14-T01 and a demarcation to WDP-CH14-C01. The current WDP (`witnessed_difference_programme.md:4829-4861`) uses those identifiers for the target-separating report theorem and the post-processing corollary, and says it "replaces the earlier three-axis formulation". | A reader resolves CH14-T01 and finds a different theorem; the no-go paper's dependency audit is stale. | Section 3.6 cites the current CH14-T01/C01/N03 statements, or cites a pinned historical WDP version for the three-axis text. |
| N8 | medium | `001_.../001_sn_mssn/paper.md:190-205`; `lean4/SnCarrierDischarge.lean:13-49`; `omega_engine_education/documentation/002_oesn/lean4/SnCarrier.lean:30, 57-80` | The manuscript says the retained SnCarrier model has a refusal-token round trip and a `Carrier.higher` constructor. The retained module now types `sectionLift` on `BasePresentation` and defines `Carrier n := Fin (carrierCard n)`. The discharge file re-creates the old defects as local `unconstrainedSectionLift` and `UnrepairedCarrier`. Its lakefile also requires the education package from outside the deposit. | The paper describes defects in a model that no longer has them and omits that the repaired domain is the case its open obligation asks for. | Reword section 6 to name the historical interface; add a Lean theorem `∀ stage (p : BasePresentation), retractionDownMap stage (sectionLift stage p) = .accepted p.toPresentation`. |
| N9 | low | `001_.../032_.../lean4/FiniteDistinction.lean:104-115`; `wd2_...md:57-58, 154-160` | `sharp_m5_bound` checks R_0(0,1) = true and R_3(0,1) = false (plus a reflexivity conjunct). It does not check R_2(0,1) = true or R_3 = R_4, which is what sharpness (least N = 3) requires. C: R_j(0,1) for j = 0..4 is T,T,T,F,F and the least stabilizing N is 3. | The Lean name suggests the lower half of the sharp bound is mechanized when only the separation is. | Add `related ... 2 0 1 = true` and the R_3 = R_4 equality to the conjunction, or rename the declaration. |
| N10 | low | `001_finite_obstruction_calculus/README.md:3, 11, 18-23, 54` | Links to `WDP_PAPER_TRIO.md` and `paper_trio.json` and six LGGR `parts/` links do not resolve. Line 54 says `000_genesis_19l57g1/` "holds no deposit", yet it contains `000_genesis_19l57g1_2026-10-09.zip` and `verify_deposit.py`. | Navigation fails; the same folder is a paper in the trio table and a non-deposit note below it. | All README links resolve; the folder has one stated role. |
| N11 | low | `000_witnessed_difference_programme/witnessed_difference_programme.md:6240` | With P_σ e_q = e_σ(q), (P_σ u)_q = u_σ^-1(q), so the middle sum should use σ^-1. The conclusion is unaffected. | Index-convention slip only. | Correct the subscript. |
| N12 | low | `015_pfp/027_.../paper.md:165` | Theorem 2 calls Δ = -s e_i* a "single-edge coboundary repair". Δ has sum -s ≠ 0, so it is not a coboundary; it makes c + Δ a coboundary. | Reader conflates the modification with an element of im d0. | Rename to "single-edge modification to a coboundary". |
| N13 | low | `014_linkedin_articles/linkedin_article_001_what_the_hell_is_an_observer_v001.md:240-256` | Φ_{1,1} = 2 and Φ_{2,1} = √2 are stated as norms of the circulation c = (1,1). They equal the residual minima only with unit edge weights, via the triangle-inequality lower bound and single-edge attainment, neither of which is stated. | A weighted reader computes a different Φ and sees a contradiction. | State unit weights and the two-line minimization. |
| N14 | low | `lean4/quantum_mechanics/LggrFiniteResults.lean:205` (evidence cited by text 30) | The docstring calls the odd three-cycle "the PR-box shape on three contexts". The PR box lives on the four-context Bell cover; the manuscript (`lggr_and_the_quantum_observer_presheaf.md:467`) uses the 4-cycle correctly. | Readers transfer PR-box facts to a three-context parity triangle. | Docstring says "odd parity cycle" and cites the 4-cycle instance for the PR box. |

### Status of the six prior action items

| Prior item | Status | Current evidence |
| --- | --- | --- |
| 1. PFP 022 norm, signature and fallback | OPEN, extended | `paper.md:31` still equates max-entry discrepancy with an ℓ1 norm; `paper.md:16` and code docstring line 23 still say "signed"; `TournamentRunReceipt.canonical_digest` (lines 125-160) is an unkeyed SHA-256; `_query_openrouter` returns None on any exception (lines 274-276) and the model label is kept. New: N1-N4. |
| 2. Observer particular-preimage biconditional | OPEN | `linkedin_article_001_...md:214`, unchanged. |
| 3. PFP 027 checker scope | OPEN | `code/replay.py:446-481`: the cohomology demo checks C015 and C018 only; `verify_committed_c004_and_c006_receipts` returns True when `omega_engine_pfp/tests/demo_004/a_mechanism` is absent (that directory exists in the monorepo, so the vacuous branch is reached only from an extracted deposit). |
| 4. Family navigation | OPEN, extended | README lines 3, 11, 18-23 (N10). |
| 5. Authority mechanizations as constructor or policy facts | OPEN | e.g. `027/.../lean4/ResidualNonCreation.lean:38-43` (`AuthEvidence` is any record of two strings and a Bool); `029/.../FiniteBoundary.lean:100-103` (`anomalon_does_not_promote := rfl`). |
| 6. Do not apply stale three-axis criticism to WDP 14.8 | OPEN (still accurate) | `witnessed_difference_programme.md:4829-4861`. The stale three-axis text now survives in paper 11 instead (N7). |

### Per-text register: derived, wrong, remaining

Status words in the "Wrong" column refer to the 2026-10-18 entry of the same number below. "Bytes unchanged" means the manuscript is identical at both pins (git diff), so a manuscript-internal prior finding cannot have been repaired.

| # | Text | Derived (premises; evidence) | Wrong (prior status; new) | Remaining obligation (theorem-shaped) |
| --- | --- | --- | --- | --- |
| 01 | Before the First Mark | Report criterion: a factor through the report exists iff the answer is fiber-constant; unique on the report image (W `paper.md:146-166`; L `lean4/Paper.lean:13-37`; R `axiom_report.txt:1036-1037`). First-separation cost two in the empty-form regime (W 310-326). | OPEN (bytes unchanged): run metadata missing; folder identity. New detail in N10. | For the declared item grammar with positive arities, every valid response has μ1 ≥ 2 and the μ2 minimum (2,1) is unique up to datum/form isomorphism, as one Lean theorem over the grammar. |
| 02 | From Pre-Genesis to MSS-N | Same criterion (W 159-187; R `axiom_report.txt:2719-2720`); s_{n+1} = s_n - d + b under D ⊆ W and disjoint births (W 277-287); tag separation as proper coloring (W 316-322). | OPEN: still absent from the README table (README lines 5-9). | For each claimed native extension: u, r with r∘u = id on admitted old terms and q'∘u = q, stated and checked per stage. |
| 03 | Witnessed Difference Programme | R1-R15 premise map (W 104-149); CH14-T01 (W 4831-4840); section 14.7 costs 6, 4, 15/4 and 7/2 with the stated lower-bound argument (W `docs/derivations/realizable_observation.md:181-213`; C); P.22 thresholds agree with the classical no-(c+1)-equal connectivity, imported not re-derived (W 15132-15145). | OPEN: unread chapters; R9-R11 inputs supplied. New N11. | Given supplied J with J^2 = -I skew-adjoint, a trace readout and a Kraus family, the R10/R11 certificates transport through one concrete report map with witness preservation; separately audit the P.22 cover intersections. |
| 04 | LGGR I | Kernel composition under G1-G3 by reindexing (W 157-205); NGD splits global failure (W 140-150). | OPEN: sufficiency only; integer shadows. | For one workflow with G1, G2 checked, Z_E - Σ_b Z_E2 Z_E1 equals the signed defect sum computed from retained global outcomes. |
| 05 | LGGR II | Four-case defect table; weak sufficiency without factorization; product sufficiency iff E_G = E_1E_2 (W 84-123). | OPEN: supplied flags, not authenticated. | For a declared finite carrier, either E_G = E_1E_2 everywhere or a witness pair is returned, with carrier maps bound to a real interface. |
| 06 | LGGR III | Defect in {-1,0,1}; one-trace counterexample (W 84-110). | OPEN: six roles are interpretations. | Each role adapter constructs the same (e_1, e_2, e_g) triple from its own input, with a separately checked global outcome. |
| 07 | LGGR IV | 3x_n + 1 = (-2)^n, compatibility mod 2^n, no integer solution (W 147-225; C for n = 1..5 and compatibility to n = 11). | OPEN: general Mittag-Leffler and compactness are cited. | A reported completed witness is shown to lie in the image of the original carrier before original-task resolution is claimed. |
| 08 | LGGR V | Soundness iff im D ∩ K = {0}; I(s_R) = 6|λ| family; coupling example; Φ1 = 2, Φ2 = √2, Φ∞ = 1 with attainment sets (W 60-145). | OPEN (test-file change is unrelated). | An exact C with I(s) ≤ C max_α J^α(s) on im D for the Theorem 6 system, with zero-space handling. |
| 09 | LGGR VI | Postprocessing invariance, accepted cylinder, ker Q^TQ = ker Q, centered identity, sign-cube recovery (W 66-215). | OPEN: sampled probes not covered. | A concentration and query-cost bound for a sampled sign-probe estimator of Hx. |
| 10 | S(n) and MSS-N | Demand accounting (W 106-115); free monoids of different finite rank are nonisomorphic via indecomposables (W 233-240). | CHANGED: the retained SnCarrier module was repaired; the manuscript still describes the old defects (N8). | ∀ stage (p : BasePresentation), retractionDownMap stage (sectionLift stage p) = accepted p.toPresentation, plus the observation commuting square. |
| 11 | Limits on prediction and self-certification | Theorem I LP dichotomy (W 183-190); near-Tsirelson table CHSH 14/5 and ℓ1 defect 4/5 agree with the isotropic-box distance (C); Lemma II and the swap witness (W 198-206). | OPEN: Lean covers support-level facts only (W 274). New N7. | The rational LP certificate of Result I is checked in Lean against the Rust output schema for the fixture table. |
| 12 | ℓ1-native cohomology | Attainment by coercivity on a gauge-fixed subspace; quotient norm (W 125-148); weighted endpoint 6/11 versus limit 1/3 (C). | OPEN: real Lp proofs are prose. | A typed rational/real bridge: the Lean integer certificate implies the real attainment statement on the same finite graph. |
| 13 | Finite ℓ1 coboundary obstructions | Weak duality bound (L `lp_general_certificate.lean:114-139`); Hodge components cost 1 + 2(n-1)/n on a unit cycle defect (checked by hand and C). | OPEN: the Lean theorem leaves r unconstrained, so it bounds the objective without showing r is feasible. | Add hypothesis r = ω + D p_0 for some p_0 and conclude optimality of r. |
| 14 | Representation abundance | Observer blindness; strict inflation when no new profile appears; 100 → 101/2 counterexample (W 77-115). | OPEN: Lean is a natural-number inequality. | The Finset statement |F'|/|O(F')| > |F|/|O(F)| under F ⊊ F' and O'(F') = O(F), in Lean. |
| 15 | Degree-wise DSL | Graph-only Γ2 undefined, Γ2 = 1 with the face, Φ1 = 1 (W 117-125; L `DegreeSeparation.lean:27-114`). | OPEN: general degree-k claim is a sketch; readout theorem is `id`. | Construct d_k for one complex with nontrivial C^{k+1} and show Γ_{k+1} is not a function of the C^{k-1} data. |
| 16 | Role non-impersonation | q^{-1}(B) ⊆ A iff B ⊆ ∀_q A (W 198-214); empty-fiber vacuity disclosed (W 225). | OPEN. | An implemented ∀_q on a closed finite domain, restricted to q(X), agrees with the issued capability set. |
| 17 | Authority gap | NGD = 0 iff Pr(L ∩ {E_G = 0}) = 0 when Pr(L) > 0; Examples 3.2-3.4; derivative sign r_V U(0) - (r_G - r_V)V(0) (W 78-121; C 7 and 3/10). | OPEN. | For a workflow, accepted support, weights and undefined-denominator cases are declared and NGD is measured against independent global outcomes. |
| 18 | Density lifts and Ξ | Rank-one projector; lexicographic selector; Ξ ≤ √(1 - 1/N); zero-distance case; example Ξ = √((3 - 2√2)/6) (W 38-170, all rechecked). | OPEN: code does not certify optimality. | An exact rational selector returning (h*, φ*) with a verified primal-dual certificate. |
| 19 | Operator lifts | Γ2 ≤ ‖d1‖ Φ1 (W 43-59); density-lift fiber = punctured line (W 93-120). | OPEN. | A checked finite carrier recovering v from (ρ, M(v), orientation anchor) with metric separation stated. |
| 20 | Constraint regulation | Γ ≤ LΦ; filled triangle Φ = Γ = |Σω|; band selection bounds and the ε = 1/10 example (W 54-157). | OPEN. | A well-founded progress measure for the proposal loop, plus constraint-preservation for each expanding proposal. |
| 21 | Observer-relative control | Coordinate bound on minimizing residuals; one-edge counterexample; weighted-norm bound; (2,1) transfer example (W 95-165). | OPEN. | Joint detector adequacy on the actual realizable defect space, stating whether each bound is raw, representative or class-level. |
| 22 | Proposal layer | Φ = 0 iff exact iff zero cycle sums (W 59-68); R_ε example (exact ratio 2, policy ratio 0); decision invariance; 1/n non-termination (W 100-145). | OPEN. | A dispatcher recomputes (Φ, Γ, X) from candidate fields and its compression preserves transition domains, costs and endpoints. |
| 23 | Authority firewall (027) | Coproduct separation and extractor emptiness (L `ResidualNonCreation.lean:57-90`). | OPEN: `AuthEvidence` is freely constructible. | An authority type whose constructor requires an issuer-bound verified check, and the truthful-guard implication proved at that type. |
| 24 | Finite authority and non-terminal computation | Finite split, witnesses and status separations in `FiniteAuthority.lean` (L; not reopened line by line). | OPEN; new N6 (imported homes absent). | Each used T1-T15 claim has a tracked home or an in-deposit proof; PL-027-2 discharged. |
| 25 | The Anomalon boundary | Exact/closed classifier; (1,1,1) not exact; applyD0 2 0 1 = (-2,1,1) (L `FiniteBoundary.lean:19-103`). | OPEN: `promotesAuthority` holds by `rfl`. | A nontrivial descent packet checker with a soundness theorem over a substantive carrier. |
| 26 | Firewall and verification limits | Calibration from representatives, converse, sharpness under disjointness (L `Calibration.lean:42-93`, read in full). | OPEN. | Derive class-constancy of spec and detector from a declared partition rather than assuming it; close OBL-AVF-02/03. |
| 27 | Finite distinction carriers | WD2-T1 equivalence, monotonicity, stability (L `FiniteDistinction.lean:10-101`); chain sharpness prose (W 154-160; C). | OPEN; new N9. | Over a finite closed state set: least N with R_N = R_{N+1} satisfies N ≤ |S| - b_0, with equality on the chain. |
| 28 | Reasoning trace validation | Carrier-relative exact/obstructed/refused protocol (W 18-58). | OPEN: version blocks at lines 6, 8, 16; abstract line 22 "cannot be scored" against the collapsing-extractor counterexample at line 279. | A sound extractor for one stated fragment with a task-to-carrier preservation theorem and a false-prose negative example. |
| 29 | A quantum observer implies a quantum carrier? | No theorem claimed (W full 37 lines). | OPEN (as limitation). | A finite system-apparatus-environment model with a record distinguishability criterion and an explicit outcome premise. |
| 30 | LGGR and the quantum observer presheaf | Prop B4 and the empirical table (W 240-290); parity section iff holonomy zero (L `LggrFiniteResults.lean:118-199`, outside the package). | OPEN: line 20 cites `src/empirical_presheaf.rs`, now `src/empirical_presheaf/` (`mod.rs`, `parity.rs`, ...); lines 17-18 and 80-81 still say "answers ... in the finite case". New N14. | No-signalling iff signed-section equivalence and the Scenario-to-Lean correspondence, proved for the 4-cycle cover. |
| 31 | PFP: The Symbol Game introduction | Eight teaching examples with changed-input controls (W 283-345). | OPEN. | Each example has a recorded learner prediction, response and rubric outcome. |
| 32 | PFP I | Φ(c + Bh) = Φ(c); weak duality; triangle certificate y = (1,1,1) and residual (3,0,0) at cost 3 (C); cycle optimum ρ|h|; sparse optimum on ≤ |E| - rank B edges (W 100-205). | OPEN. | The native return type carries a dual certificate checked against the original reports and search bounds. |
| 33 | PFP II | Harary balance criterion; diagonal-sign reduction; example (0,1,0); entrywise positivity of e^{-βH'} (W 60-152). | OPEN. | For one physical Hamiltonian, the fixed-basis graph is derived from the stated basis and the resumable frontier is replayed in full. |
| 34 | PFP III | Fuel charge before batch; historical receipt is not treatment evidence (W 515-534). | OPEN. | Native witness routes implemented and checked, then the frozen randomized experiment with false-suppression intervals. |
| 35 | PFP IV | Face sums 7, 5; Γ2 = 12; Φ1 = 7 attained by (5,2,0,0,0) (W 234-241; C). | OPEN; new N5. | Define the normal-form map and state whether candidate minus before lies in im d0. |
| 36 | PFP V | Triangle (1,1,1), weights (1,2,3): minimum 3 = min weight × |holonomy| (W 30-60). | OPEN. | The patched native route is replayed under exact source and binary pins. |
| 37 | PFP VI | Truncation and edit detection against an external anchor; rewritten shorter ledger reopens (W 300-338). | OPEN. | Externally held checkpoint custody with crash and concurrent-writer tests. |
| 38 | PFP VII | Residual (1/3,1/3,1/3) → (0,0,1) by telescoping (W 40-80; C); imported `omega_engine_pfp.domain.ddc` names exist (`__init__.py:59-79`). | OPEN. | Each learning claim is paired with an assessed response and a changed-input control. |
| 39 | PFP VIII | d_1(u_0(x)) = x gives injectivity on the one-element old domain (W 85-125). | OPEN. | Parser, admission and down-map domains for the next stage with preserved old semantics. |
| 40 | PFP IX | Review procedure; recounted runs scoped (W 155-170). | OPEN. | The five original probes replayed against the current gate with blinded claims. |
| 41 | PFP X | `FiniteGroup` checks totality, closure, identity, inverses and associativity (`holonomy.py:46-97`). | OPEN (empirical comparisons). | Answer-blind tasks with gauge-changed negative controls and all replies retained. |
| 42 | PFP 011 shape and findings | F01-F07 reproduced at the named historical source (W 18-50). | OPEN. | The historical falsifiers rerun against the current runner with valid-pair controls. |
| 43 | PFP XI | Census, custody and partial C017 replay are separated from execution claims (W 132-160). | OPEN. | Original-recovery obligations closed with retained runner bytes and independent witnesses. |
| 44 | PFP XX (022) | An exact SO(4N) and determinant check on signed permutations (code read; Majorana module `majorana_multiqubit_noise.py:317-420`). | OPEN (all four prior items, line 31, line 16, lines 274-276, lines 39-52); new N1-N4. | For a declared time-dependent noise model, a schedule with U ≠ U_baseline implementing the target logical gate has lower held-out defect, from receipts with real denominators. |
| 45 | Task-bound claims | Sound-checker conjunction; (1,0) versus (0,1) (W 56-75). | OPEN. | One prose-to-obligation extraction fragment with a source-span checker. |
| 46 | Recursive re-entry | Backward composition; b_i∘f_i = id composes; n ≤ ⌊B/δ⌋ (W 46-75). | OPEN. | One native re-entry adapter with forward coverage, backward decoding, parent identity and charges checked. |
| 47 | Local to global composition | Gluing iff pairwise agreement; bijection under full coverage; Boolean triangle (W 40-75). | OPEN, reproduced (C): `check_family(((0,0),)*3, ())` and `check_family(((0,0),)*3, (EQ, EQ))` both return (0,0,0). | `check_family` refuses unless exactly three relation tables matching the task schema are supplied, with a positive control. |
| 48 | Future-faithful compression | Exact quotient iff equal labels, enablement, costs and successor fibres; coarsest stable refinement (W 40-73). | OPEN. | A bounded arena construction for an adversarial or stochastic extension. |
| 49 | Proposal channels (027) | Theorem 2 single-cycle duality and lightest-edge bound, with dual z* = sgn(s) w_min 1 (W 135-185). | OPEN; new N12. | All ten verifier implementations audited with valid and mutated certificates; missing receipts return NOT_RUN. |
| 50 | What is an observer? | Gauge quotient when B_O is a subgroup; DB = 0 invariance (W 195-290). | OPEN (line 214); new N13. | Replace the particular-preimage biconditional with ∃ f ∈ Adm, δ = d0 f, and keep the constant-potential counterexample. |
| 51 | What is authority? | Authorize as a piecewise typed contract (W 180-215). | OPEN. | One executable example binding a real issuer, frozen policy, scope and evidence, with alias and key-compromise cases. |
| 52 | What is difference? | Fiber criterion; coarsest common refinement; tag minimum = max classes per fiber; triangle α = (0,1,2), residual (0,0,3) (C); [K_j b] = [z] (W 141-336). | OPEN. | An exact finite companion for tag coloring and the recovery-defect identity. |
| 53 | What the hell, John Bell? | |S_λ| = 2; mixture bound; singlet E00 = E01 = E10 = 1/√2, E11 = -1/√2, S = 2√2 (W 140-240, rechecked). | OPEN. | An exact four-table companion with all eight CHSH facets and the PR contrast. |
| 54 | What is a prompt? | x = 1, y = 2; decoy (3,0) violates both equations (W lines 21, 51; companion 413-437). | OPEN (locus reached through the companion and a line search, not a full reread). | A parser and checker demonstration of the copyable packet with stated background algebra rules. |
| 55 | Prompt technical companion | Decoy witness; Newman's lemma correctly scoped; masked softmax; corrupt prompt x + 2y = 10 gives (2,4) while 3x + 4y = 11 keeps (1,2) (C); NLD definition (W 405-490, 1181-1300). | OPEN (line 415 "dramatically improve"). | One reproducible intervention run with baselines, sham patches, nonempty-mask handling and raw output custody. |

### Per-family counts and three most serious errors

| Family | Texts read (loci) | Derived items | Wrong items | Open obligations | Three most serious errors |
| --- | --- | --- | --- | --- | --- |
| 001 | 30 of 30 | 30 entries, about 70 stated results | 37 (30 prior OPEN or CHANGED, 7 new) | 30 | N6 absent imported dependencies (028:53); N7 stale CH14 identifiers (002:135-139); N8 stale SnCarrier description (001_sn_mssn:190-205). |
| 015 PFP | 19 of 19 | 19 entries, about 45 stated results | 25 (19 prior OPEN, 6 new) | 19 | N1 mitigation identical by construction (022 code 301-335); N5 "exact repair" changes the class (004:203-241); 025 omitted-relation acceptance, now executed. |
| 014 essays | 6 of 6 | 6 entries, about 18 stated results | 7 (6 prior OPEN, 1 new) | 6 | Observer biconditional (001:214); N13 unstated weights (001:240-256); companion line 415 effectiveness claim without a trial. |

### Checks run (2026-10-20)

| Command | Tool version | Exit | Scope |
| --- | --- | --- | --- |
| `git diff --name-status 000ee9b0c2..HEAD -- <three assigned folders>` and `git log`/`git ls-files` path checks | git 2.54.0.windows.1 | 0 | Change detection and path existence for 028, 035, README links, SnCarrier. |
| `py -3.12 -I -c "<load 025 code/replay.py by path; call check_family with 0 and 2 relation tables>"` | Python 3.12.10 | 0 | PFP 025 helper only; output (0, 0, 0) for both malformed calls, None for the full incompatible family. |
| `py -3.12 -I -c "<Fraction checks>"` (three invocations) | Python 3.12.10 | 0 | WDP costs 15/4, 7/2, 4; PFP IV Γ2 = 12, Φ1 = 7 and potential consistency; near-Tsirelson E = 7/10, CHSH 14/5, defect 4/5; LGGR IV n = 1..5; 6/11; Hodge factor; PFP I, PFP VII, essay 003 and companion arithmetic; WD2 chain R_j(0,1) and least N = 3. |
| `py -3.12 -m pytest <022>/code/tests/test_adaptive_braid_tournament_demo.py --collect-only -q -p no:cacheprovider --basetemp C:/Users/a343o/.claude/jobs/05b9c4fc/tmp/pt_reader1/b` | pytest 8.3.5 | 2 | Collection only: `ModuleNotFoundError: No module named 'majorana_multiqubit_noise'`. An identical first run was piped through `tail`, which masked its exit status; the second run records exit 2. |

No Lean, notebook, deposit verifier, cargo or provider command was run. The FAIL above is a finding (N3); no source or test was edited.

### Next projects for this slice

| Project | Acceptance evidence |
| --- | --- |
| 1. Rewrite PFP 022 from its receipts. | Composite-U-distinct strategies only; matrix-equivalence target check; refusals excluded from means; max-norm and unsigned-digest wording; import path fixed so the package tests collect and pass from the package root; tables regenerated with denominators. |
| 2. Close the three replay-checker and model-description gaps. | PFP 025 refuses missing relation tables; PFP 027 emits MISSING when receipts are absent; S(n) section 6 rewritten for the repaired SnCarrier with the old-image law as a compiled Lean theorem; PFP IV defines its normal form and labels replacement. |
| 3. Repair cross-paper identity and dependency resolution. | Paper 11 section 3.6 cites the current WDP CH14 identifiers; paper 028 cites tracked homes for T1-T15 or derives them in the deposit; family README links resolve; `sharp_m5_bound` gains its lower-half conjuncts. |

### Inspected-path register (this pass)

Paths are relative to `omega_engine_atlas/coda_atlas/F004_papers/` unless they start with another root. "Loci" means the listed line ranges, not the whole file.

| Path | Depth |
| --- | --- |
| [`001_finite_obstruction_calculus/README.md`](../../omega_engine_atlas/coda_atlas/F004_papers/001_finite_obstruction_calculus/README.md) | Lines 1-16, 52-55. |
| `001_.../000_genesis_19l57g1/paper.md`; `lean4/Paper.lean` | Loci 100-170, 280-335; Lean lines 1-45. |
| `001_.../000_pre_genesis_to_mssn/paper.md` | Loci 130-190, 270-330. |
| `001_.../000_witnessed_difference_programme/witnessed_difference_programme.md`; `docs/derivations/realizable_observation.md` | Loci 100-150, 4780-4865, 6195-6250, 15093-15160; derivation 165-215. |
| `001_.../001_local_green_global_red_foundational_series/*/lggr_*.md` (six parts) | I 140-210; II 70-150; III 80-115; IV 140-230; V 60-155; VI 60-215. |
| `001_.../001_sn_mssn/paper.md`; `lean4/lakefile.lean`, `lean4/SnCarrierDischarge.lean`; `omega_engine_education/documentation/002_oesn/lean4/SnCarrier.lean` | Paper 100-130, 170-250; lakefile full; discharge 1-49; SnCarrier 55-110. |
| `001_.../002_asi_no_go_theorem_epistemic_contextuality/epistemic_no_go_monograph.md` | Headings; loci 135-142, 181-256, 274-276. |
| `001_.../002_l1_native_cohomology/l1_native_cohomology.md` | Loci 95-160. |
| `001_.../003_l1_obstruction_framework/l1_obstruction_framework.md`; `lean4/lp_general_certificate.lean` | Loci 28-80; Lean 114-139. |
| `001_.../003_representation_abundance_is_not_physical_authority/...md` | Loci 70-125. |
| `001_.../004_degree_wise_dsl/degree_wise_dsl.md`; `lean4/DegreeSeparation.lean` | Loci 100-125; Lean theorem lines by search. |
| `001_.../004_role_non_impersonation_and_authority_preservation/...md` | Loci 190-225. |
| `001_.../005_the_authority_gap/the_authority_gap.md` | Loci 60-130. |
| `001_.../009_conditional_density_lift_and_dual_witness_xi_functional/density_lift.md` | Lines 38-220 (sections 2-7 complete). |
| `001_.../013_.../operator_lifts_..._monograph.md` | Loci 38-120. |
| `001_.../018_.../constraint_regulation.md` | Loci 40-165. |
| `001_.../019_.../observer_control.md` | Loci 95-170. |
| `001_.../026_.../operator_proposals.md` | Loci 50-150. |
| `001_.../027_.../lean4/ResidualNonCreation.lean` | Lines 30-115. |
| `001_.../028_.../finite_authority_..._monograph.md` | Loci 25-63; line 1057 by search. |
| `001_.../029_the_anomalon_boundary/lean4/FiniteBoundary.lean`, `OntologyBasic.lean` | Declaration search only. |
| `001_.../030_.../lean4/Calibration.lean` | Lines 15-95. |
| `001_.../032_.../lean4/FiniteDistinction.lean`; manuscript | Lean 1-115 (complete); manuscript 50-64, 120-165. |
| `001_.../033_.../..._monograph.md` | Version and heuristic lines by search; 277-279. |
| `001_.../034_quantum_observer_quantum_carrier/a_quantum_observer_implies_a_quantum_carrier.md` | Complete. |
| `001_.../035_lggr_quantum_observer_presheaf/lggr_and_the_quantum_observer_presheaf.md`; `lean4/quantum_mechanics/LggrFiniteResults.lean` | Manuscript 240-300 and searches; Lean 118-218. |
| `015_pfp/000_pfp_introduction/paper.md` | Headings; 283-345. |
| `015_pfp/001_.../paper.md` | 100-215. |
| `015_pfp/002_.../paper.md` | 60-165. |
| `015_pfp/003_.../paper.md` | 515-536. |
| `015_pfp/004_.../paper.md` | 15-30, 170-255. |
| `015_pfp/005_.../paper.md` | 1-60. |
| `015_pfp/006_.../paper.md` | 300-340. |
| `015_pfp/007_.../paper.md`; `omega_engine_pfp/domain/ddc/__init__.py` | 40-80; exports 59-79. |
| `015_pfp/008_.../paper.md` | 85-140. |
| `015_pfp/009_.../paper.md` | 155-170. |
| `015_pfp/010_.../code/holonomy.py` | 40-117. |
| `015_pfp/011_.../paper.md` | 18-50. |
| `015_pfp/021_.../paper.md` | 132-160. |
| `015_pfp/022_pfp_frontier_research/paper.md`; `code/adaptive_braid_tournament_demo.py`; `code/l8_n4_cross_validation.py`; `009_ms_majorana/code/majorana_multiqubit_noise.py` | Paper complete (105 lines); demo 36-66, 112-160, 222-356, 398-482; L8 255-300, 356-445; Majorana 150-420. |
| `015_pfp/023_.../paper.md` | 50-75. |
| `015_pfp/024_.../paper.md` | 40-75. |
| `015_pfp/025_.../code/replay.py`; `paper.md` | Replay complete (35 lines); paper 40-75. |
| `015_pfp/026_.../paper.md` | 40-80. |
| `015_pfp/027_.../paper.md`; `code/replay.py` | Paper 135-190, 355-375; replay 430-500. |
| `014_linkedin_articles/linkedin_article_001_...md` | 195-330. |
| `014_linkedin_articles/linkedin_article_002_...md` | 180-215. |
| `014_linkedin_articles/linkedin_article_003_...md` | 141-200, 262-410. |
| `014_linkedin_articles/linkedin_article_004_...md` | 140-240. |
| `014_linkedin_articles/linkedin_article_005_...md` | Lines 21, 51 and equation search only. |
| `014_linkedin_articles/pfp/linkedin_article_005_..._technical_companion_v001.md` | 405-490, 1181-1300. |
| `omega_engine_product_planning_office/plans/review_remediation/findings.json` | Units mentioning this register or these folders. |

Not read in this pass: WDP chapters outside the listed loci, every claim ledger in full, the ongoing Genesis subtree (review 61), all bibliographies. In the baseline below, eleven tokens of review vocabulary were replaced by neutral synonyms (for example "establishes" for a word on the repository's forbidden list); no historical claim or status was changed.

## 2026-10-18 baseline (historical)

AuthorityEffect: None.

Review pin: `000ee9b0c234eda74340e424d6cfb3f6ec001df7` (2026-10-18). This is a static source review under the paper-reader skill. No provider calls, Lean compilation, native build, deposit verifier, notebook execution or test suite was run. A theorem declaration below means an inspected source statement and proof term, not a fresh compiler receipt. Bibliographies and DOI/deposit status were not verified against live external records; quoted release labels remain package assertions.

## Scope and how to use this review

The inspected manuscript register contains **55 distinct texts**: 30 family-001 manuscripts outside the ongoing Genesis copy, 19 numbered PFP manuscripts, five public essays and the separate prompt technical companion. The LGGR index is navigation, not a seventh LGGR paper. Math-spine companions, publication exports, historical sources, prior versions, quizzes, findings notes, receipts and outlines are excluded from the distinct-manuscript count. The copied ongoing Genesis repository belongs to [review 61](61_papers_genesis_ongoing_deep_review.md); its local AGENTS.md does not govern the sources reviewed here because that subtree was not entered.

Reading depth is **selected substantive loci** unless explicitly marked complete. For each text this means its thesis, central statement, relevant proof/derivation or worked argument, and the cited claim/evidence boundary. It does not mean every line, every appendix, every dependency or every listed test was audited. WDP alone has 17,685 lines. The text below begins an actionable scholarly audit; it does not certify all proofs or originality. Representative implementation and Lean anchors were inspected where described. Unopened dependencies remain obligations.

The historical [source catalog](04_paper_source_catalog.json) and [family review 44](44_f004_family_001_deep.md) were leads, not the current inventory. Current directory traversal found the actual manuscripts, including PFP 021-027. Each numbered heading below is also the inspected-manuscript register: its linked path identifies the exact text, followed by derived content, defects or limits, and the next obligation.

## Findings requiring action first

1. PFP 022 equates an entrywise maximum with an ell-one norm, advertises signed receipts whose implementation contains only a SHA-256 digest, and retains model labels across deterministic fallback. Its commutation score does not establish dynamical noise mitigation.
2. The observer essay's particular-preimage repair biconditional is false for noninjective repair maps. Existence of an admitted preimage is the correct criterion.
3. PFP 027's soundness theorems assume a sound checker. Its package replay demonstrates two cohomology check examples, not a source-level soundness audit of all ten challenge verifiers. Trial tables are retained measurements, not proof of checker completeness or general prompt superiority.
4. Family navigation still points at absent WDP trio registry and LGGR `parts/` paths. The six current LGGR folders are direct children of the series directory.
5. Several authority papers mechanize constructor distinctions or explicit policy predicates. Those are useful specifications, but do not establish real principal identity, process isolation, authenticated issuance or deployment security.
6. WDP's current Chapter 14.8 explicitly replaces its earlier three-axis argument with a target-separating report theorem. Historical criticism in review 44 must not be applied to that corrected paragraph without rereading it.

## Family 001: foundations and obstruction calculus

### 01. Before the First Mark

[Manuscript](../../omega_engine_atlas/coda_atlas/F004_papers/001_finite_obstruction_calculus/000_genesis_19l57g1/paper.md). Read: abstract; report-factorization proofs, lines 119-165; first-separation proof, lines 310-326; formal inventory.

- **Derived:** An answer factors through a report exactly when it is constant on each report fiber. The two-item first-separation bound depends on the specified empty-form/empty-instance regime and item grammar; the lower bound enumerates all one-item kinds, while a fresh unary form plus an instance supplies the upper bound.
- **Wrong or limited:** The three historical model runs lack model/settings metadata and are failure examples, not performance measurements. Admission mathematics does not derive physical time or a universe. The family index inconsistently calls this a paper in the trio table and a notes folder below it.
- **Next exact obligation:** Give one authoritative publication identity and bind the reported Rust incidence/homology construction to an independently replayable correspondence theorem; retain missing experimental metadata as missing.
- **Evidence anchors:** Manuscript names `GenesisPaper.history_report_criterion`; package `lean4/Paper.lean` and the Census files are source artifacts, not fresh elaboration. The inspected first-separation proof cites `cost1_insufficient_general` and `deltaU0_valid` upstream.

### 02. From Pre-Genesis to MSS-N

[Manuscript](../../omega_engine_atlas/coda_atlas/F004_papers/001_finite_obstruction_calculus/000_pre_genesis_to_mssn/paper.md). Read: abstract; report proof, lines 141-187; finite demand accounting, lines 282-298.

- **Derived:** The report criterion is proved by defining the answer on the report image. Active demands satisfy s_next = s_current - discharged + born only under subset removal and disjoint-birth premises. Chain retraction prevents killing a previously nonzero homology class.
- **Wrong or limited:** This distinct 906-line consolidation is missing from the family README publication table. A chosen demand sequence is illustrative, not an engine invariant. The general report-decoder existence uses classical choice; it is not the finite search algorithm by itself.
- **Next exact obligation:** Reconcile its role with the two entry papers, and prove actual carrier/evaluator transport for each claimed native extension rather than inferring it from presentation-stage numbering.
- **Evidence anchors:** `lean4/Paper.lean` is cited for `PreMssn.history_report_criterion` and `history_factor_unique`; companions include `GraphRetraction.lean` and `BellMixture.lean`. The corresponding source role was inspected, not compiled.

### 03. The Witnessed Difference Programme

[Manuscript](../../omega_engine_atlas/coda_atlas/F004_papers/001_finite_obstruction_calculus/000_witnessed_difference_programme/witnessed_difference_programme.md). Read: theorem map, lines 104-149; observation realization, 4783-4827; corrected report theorem, 4831-4861; classical fork, 6195-6245; completeness, 8383-8427; guarded-schedule classification, 15093-15157.

- **Derived:** The finite spine has explicit repair quotients, protected-query fiber factorization and conditional backward/forward witness transport. Linear observation budgets distinguish realizable defects from whole-space repair classes. Paired-count guards yield a stated equivalence to a real no-equal arrangement complement under explicit tags and precedences. The classical-simplex countermodel excludes inferring quantum theory from normalization or nonsimpliciality.
- **Wrong or limited:** This review did not read every chapter or finish the topological nerve proof and external connectivity argument. Theorem-map R9 assumes a complex structure J; R10 assumes trace readout; R11 assumes process/composite structure. Those inputs are not derived by report minimality. Chapter 14.8 now corrects the former three-axis account; repeating the old criticism would be stale. Finite source results do not establish a global native quotient functor.
- **Next exact obligation:** For finite QM, choose and justify the extra scalar, positive-form, state/effect, instrument and composition assumptions one by one. For schedule topology, independently audit the cover intersections and arrangement connectivity theorem, then connect the general theorem to the actual Source-25 semantics.
- **Evidence anchors:** R1-R15 in the manuscript are an explicit premise/conclusion map; GEN-WDP-49 separates soundness, coverage and resources. `docs/derivations/realizable_observation.md` and `docs/guarded_schedule_topology.md` are named supplements, not fully audited here. No axiom-free claim is inherited from a ledger token.

### 04. LGGR I: Evaluated Path Kernels

[Manuscript](../../omega_engine_atlas/coda_atlas/F004_papers/001_finite_obstruction_calculus/001_local_green_global_red_foundational_series/lggr_i_evaluated_path_kernels/lggr_i_evaluated_path_kernels.md). Read: abstract; Theorem 1 proof, lines 175-204; B/C/D/E/F ledger rows.

- **Derived:** Under unique compatible path decomposition G1, multiplicative weights G2 and evaluator factorization G3, reindexing and factoring the finite sum gives kernel composition. Signed defect corrections and cancellation examples distinguish aggregate equality from pointwise agreement.
- **Wrong or limited:** The composition theorem is sufficient, not an equivalence: residuals can cancel. Integer-weight Lean shadows do not mechanize exponential real analysis or empirical reversal laws. Benchmarks remain proposed testbeds.
- **Next exact obligation:** Instantiate G1-G3 for one actual workflow and measure the non-cancelling defect partition on held-out traces; retain all global outcomes so the predictor cannot leak its target.
- **Evidence anchors:** Ledger C1/C2/D2/D4; `lean4/03_kernel_composition.lean`, `04_defect_corrected_kernel.lean`; named Python `test_kernel_composition_theorem_under_g1_g3`. Tests were not executed.

### 05. LGGR II: Organizational Evaluator Gluing

[Manuscript](../../omega_engine_atlas/coda_atlas/F004_papers/001_finite_obstruction_calculus/001_local_green_global_red_foundational_series/lggr_ii_organizational_gluing/lggr_ii_organizational_gluing.md). Read: abstract; Boolean proof and weak-sufficiency countermodel, lines 84-108 onward; complete main claim table.

- **Derived:** The four Boolean cases yield defect trichotomy. Weak recovery of the global verdict does not imply product factorization. A global verdict that varies within a carrier class cannot descend to that quotient; under the stated local-carrier hypotheses it produces a local-green/global-red witness.
- **Wrong or limited:** Owner, authority and time flags are supplied data, not authenticated governance. Product sufficiency explicitly requires the equality it characterizes. No organizational failure rate follows from the finite countermodel.
- **Next exact obligation:** Bind carrier maps and global verdicts to one real organizational interface; separately authenticate boundary ownership and temporal evidence.
- **Evidence anchors:** Ledger M3/M4/M8/M9, D1-D3; Lean `weak_boundary_sufficiency_does_not_force_factorization`, `boundary_carrier_mixing_blocks_quotient_factorization`; files `02_boundary_sufficiency.lean` and `04_carrier_boundary_obstruction.lean`.

### 06. LGGR III: A finite evaluator overlay across six roles

[Manuscript](../../omega_engine_atlas/coda_atlas/F004_papers/001_finite_obstruction_calculus/001_local_green_global_red_foundational_series/lggr_iii_epk_gtla_overlay/lggr_iii_epk_gtla_overlay.md). Read: abstract; sign proof, lines 84-110; finite-sample and quotient ledger.

- **Derived:** Binary subtraction gives three signed defects; finite distributivity gives global-count minus local-count equals signed-defect sum. Opposite defects can cancel. Quotient descent fails when equivalent inputs receive different verdicts.
- **Wrong or limited:** The six roles are an interpretation of the same diagnostic, not six newly derived mathematical structures. Integer identities do not prove the real weighted-kernel theorem or validate a deployment.
- **Next exact obligation:** Provide typed adapters showing how each selected role constructs the same input triple and records a separately checked global outcome.
- **Evidence anchors:** Ledger LGGR3-C02/C04/C05; `LGGR3.defect_range`, `global_sub_local_eq_defect_sum`, `binary_defect_cancellation` are cited source declarations; no new Lean run.

### 07. LGGR IV: Finite-stage solvability and completion-relative obstruction

[Manuscript](../../omega_engine_atlas/coda_atlas/F004_papers/001_finite_obstruction_calculus/001_local_green_global_red_foundational_series/lggr_iv_finite_presentations_completion_relative/lggr_iv_finite_presentations_completion_relative.md). Read: abstract; inverse-limit scope, lines 105-117; arithmetic proofs, 147-225.

- **Derived:** The geometric series gives 3*x_n+1 = (-2)^n and compatibility modulo 2^n. A fixed integer cannot make the nonzero integer 3*x+1 divisible by every power of two; the compatible solution is completion-relative. A finite-chain thread follows by pulling back one final element.
- **Wrong or limited:** General cofiltered finite-set compactness and Mittag-Leffler statements are cited classical results, not the finite-chain Lean proof. Stage-wise existence alone is insufficient unless valid transition maps and coherence hypotheses are supplied.
- **Next exact obligation:** Bind one intended original carrier and its embedding into the completion; prove that a reported completed witness lies in the original image before claiming original-task resolution.
- **Evidence anchors:** `lean4/core.lean`: `LggrIV.finite_chain_limit_nonempty`; arithmetic ledger M3-M5 and reflection criterion M7. Stacks citations were not checked live.

### 08. LGGR V: Detection and recovery in finite linear evaluation models

[Manuscript](../../omega_engine_atlas/coda_atlas/F004_papers/001_finite_obstruction_calculus/001_local_green_global_red_foundational_series/lggr_v_local_green_global_red/lggr_v_local_green_global_red.md). Read: abstract; soundness proof, lines 90-110; quantitative proof, 118-124; raw/quotient distinction, 126-149; ledger.

- **Derived:** All-green soundness is exactly im(D) intersect joint watcher kernel = {0}, for the stated normed realization. Coupled defects can make observation sound even when each edge has a nontrivial blind spot. Compactness gives a quantitative recovery constant on a fixed finite-dimensional realizable space.
- **Wrong or limited:** The unbounded hidden-defect family requires unbounded assignments. Its section defects have zero distance to im(D), so raw inconsistency and nonzero quotient obstruction are different. The SVD helper is only an ambient sufficient-condition estimate and can miss coupling-based recovery.
- **Next exact obligation:** Compute a certified recovery bound on the actual realizable subspace, with explicit norm conversion and zero-space handling; do not advertise the helper as the sharp optimum.
- **Evidence anchors:** Ledger LGR-MSC/LGR-T3/LGR-T5B/LGR-T6; `lean4/observer_visibility.lean` and `minkowski_repair.lean`; general compactness remains prose.

### 09. LGGR VI: Blind spots under nonlinear aggregation and adjoint probing

[Manuscript](../../omega_engine_atlas/coda_atlas/F004_papers/001_finite_obstruction_calculus/001_local_green_global_red_foundational_series/lggr_vi_nonlinear_aggregation_and_adjoint_probing/lggr_vi_nonlinear_aggregation_and_adjoint_probing.md). Read: abstract; postprocessing proof, lines 66-88; SVD proof, 102-120; complete seven-row ledger.

- **Derived:** Equal reports remain equal after deterministic postprocessing. For rational Q, the Gram kernel equals ker(Q); centered quadratic queries recover Gram pairings, and averaging over the full sign cube recovers Hx.
- **Wrong or limited:** The centered-query and full-cube premises are material: a random finite subsample is not the exact theorem. The real singular-value cylinder bound is classical prose, not rational Lean mechanization. The mutation fixture is one construction, not a detector-effectiveness rate.
- **Next exact obligation:** Prove concentration/error and query-cost bounds for any proposed sampled-probe variant, then compare with direct linear observation on the same protected question.
- **Evidence anchors:** `lean4/Core.lean`: `postprocessing_invariance`, `gram_kernel_iff`, `centered_directional_identity`, `sign_cube_recovers`; ledger LGGRVI-C01-C07.

### 10. From Admitted Distinctions to S(n) and MSS-N

[Manuscript](../../omega_engine_atlas/coda_atlas/F004_papers/001_finite_obstruction_calculus/001_sn_mssn/paper.md). Read: abstract; demand proof, 110-126; recovery limits, 179-195; free-monoid proof, 233-246.

- **Derived:** Disjoint demand accounting, old-image typed retraction, alphabet restriction and chain-retraction homology injectivity are separate preservation results. Free monoids of different generator counts are nonisomorphic because an isomorphism preserves indecomposable nonidentity elements.
- **Wrong or limited:** S(n), alphabet size, grammar stage and homology degree are different indices. The retained SnCarrier has a refusal-token round trip that changes the input; the manuscript discloses it. Syntax recovery does not prove observer preservation or repair.
- **Next exact obligation:** Restrict the retraction domain to admitted old terms or repair the refusal branch, and prove the observation commuting square independently of syntactic round trips.
- **Evidence anchors:** `lean4/SnCarrierDischarge.lean`: `refusal_token_round_trip_changes_input`, `carrier_card_table_disagrees_with_higher`; `Paper001.lean` is the local proof home.

### 11. Conditional limits on prediction, self-knowledge and self-certification

[Preserved manuscript](../../omega_engine_atlas/coda_atlas/F004_papers/012_rsi/001_contextual_prediction_and_self_certification/docs/precursor_monograph.md). The original directory was retired on 2026-10-22; this link resolves to the same historical manuscript bytes. Read: abstract/status; four-result claims; inspected ResultI-IV declaration/proof loci.

- **Derived:** PR support has no positive global assignment; a two-assignment classical mixture gives the contrasting finite example. The fiber lemma rules out report-only recovery of a separated target. Swapping coordinates refutes permanent privacy from a one-step private fiber. A finite ledger prefix can verify internally while differing from an external pinned tip.
- **Wrong or limited:** The general rational ell-one contextuality dichotomy is a written LP argument, not what ResultI.lean establishes. Relabeling blindness assumes invariance. Effect.none is one constructor. Distinct principal strings are not authenticated identities. Version 1.0 false claims are withdrawn, not current theorems.
- **Next exact obligation:** Machine-link the rational LP certificate and role gate to their actual Rust/Python owners; for dynamic privacy quantify over the full admitted intervention/transcript class.
- **Evidence anchors:** `ResultII.lean::fiber_lemma`, `swap_not_intertwined`; `ResultIII.lean::internal_verification_is_not_completeness`; `ResultIV.lean::pass_implies_policy`, `distinct_strings_pass`. No compiler execution.

### 12. Ell-one-native cohomology of finite defect fields

[Manuscript](../../omega_engine_atlas/coda_atlas/F004_papers/001_finite_obstruction_calculus/002_l1_native_cohomology/l1_native_cohomology.md). Read: setup/abstract; attainment and quotient-norm proofs, lines 118-147; formal-scope paragraph.

- **Derived:** Positive finite graph weights and a gauge-fixed injective incidence map give coercivity and attained residual minima. Quotient norm and bounded-circulation duality are classical finite-dimensional results. Distinct p regimes have distinct uniqueness and sparsity properties.
- **Wrong or limited:** The general real Lp claims have prose proofs; the named Lean packages prove conditional finite integer statements. The separate weighted Chebyshev endpoint is not automatically the limit of the chosen finite-p weight convention. No physical holonomy or quantum emergence follows from additive real flux.
- **Next exact obligation:** Prove a typed real/rational bridge for the intended certificate statement and publish exact hypotheses for every endpoint/limit claim; keep original contribution distinct from classical duality.
- **Evidence anchors:** `lean4/l1c_general_certificate.lean`, `l1c_t01_attainment.lean`, `l1c_t07_bianchi_nilpotency.lean`; L1C-TG scope is narrower than real attainment.

### 13. Finite ell-one coboundary obstructions

[Manuscript](../../omega_engine_atlas/coda_atlas/F004_papers/001_finite_obstruction_calculus/003_l1_obstruction_framework/l1_obstruction_framework.md). Read: classification and refutations, lines 32-72; exact certificate source declaration.

- **Derived:** A feasible primal residual and capacity-bounded dual annihilator with equal objectives certify optimality by weak duality. Commuting contractive aggregation bounds residuals; nonzero closed quotient classes differ from failures of closure.
- **Wrong or limited:** The three-step local iterator is explicitly refuted by a nonoptimal one-edge fixed point. Summing overlapping cycle holonomies without joint capacity constraints is also refuted. The general Lean lower-bound theorem assumes annihilation of every permitted coboundary and does not construct the candidate residual feasibility proof.
- **Next exact obligation:** Use the exact checker on a concrete carrier, supply feasibility and a constructed complex with d1*d0=0, and independently audit any proposed replacement solver instead of reviving the withdrawn iterator.
- **Evidence anchors:** `lean4/lp_general_certificate.lean::general_finite_certificate_optimality`, line 114; ledger C3/C5 withdrawn, C18 declared compatibility axiom; manuscript Theorem 4.2 supplies the separate feasible-residual argument.

### 14. Representation abundance is not physical authority

[Manuscript](../../omega_engine_atlas/coda_atlas/F004_papers/001_finite_obstruction_calculus/003_representation_abundance_is_not_physical_authority/representation_abundance_is_not_physical_authority.md). Read: abstract; observer-blindness and inflation proofs, lines 77-115; full principal claim table.

- **Derived:** Observation-only decisions are constant on fibers. Properly extending a finite family without adding observed profiles strictly raises average fiber size. Positive cycle tolerances allow rational local-green/nonzero-holonomy fields, with sharp edge-simple-cycle bounds.
- **Wrong or limited:** The natural-number Lean multiplication inequality does not encode the full finite-family ratio theorem. Selector evidence is assumed authentic and the alternatives are not proved exhaustive. Large physical solution counts motivate the discussion but are not established by the finite examples.
- **Next exact obligation:** Mechanize the finite-family observation-preserving extension and exact ratio statement, then bind a real selector to authenticated measurements and a justified candidate universe.
- **Evidence anchors:** Ledger C2/C3/C14/C5; `lean4/Representation.lean`: `observation_decision_agrees`, `plenitude_inflation` have explicitly different scopes.

### 15. Degree-wise obstruction calculus and symbolic DSL

[Manuscript](../../omega_engine_atlas/coda_atlas/F004_papers/001_finite_obstruction_calculus/004_degree_wise_dsl/degree_wise_dsl.md). Read: scope/ledger; degree-separation proof sketch, lines 106-122; DegreeSeparation.lean, lines 14-110.

- **Derived:** The same integer C3 cochain can have an undefined face readout in a graph-only carrier and Gamma=1 after a face is supplied. The explicit d1*d0 telescoping identity holds. A declared projection structure supplies its idempotence and exact-killing laws as fields.
- **Wrong or limited:** General degree-k separation is schematic. Reading a projection field establishes the declared contract, not existence/canonicity of a projection. The hasEval Boolean gate is a model of authorization discipline, not principal isolation.
- **Next exact obligation:** Construct the intended higher-degree complex and projection, then prove degree-safe evaluation and correspondence for actual DSL parsing/execution.
- **Evidence anchors:** `lean4/DegreeSeparation.lean::c3_d1_d0_zero`, `gamma2_graphOnly_undefined`, `gamma2_withTwoCell_one`, `DeclaredProjection`; ledger C02/C04/C09.

### 16. The Omega Tower: Role non-impersonation and authority preservation

[Manuscript](../../omega_engine_atlas/coda_atlas/F004_papers/001_finite_obstruction_calculus/004_role_non_impersonation_and_authority_preservation/role_non_impersonation_and_authority_preservation.md). Read: abstract; quotient authorization adjunction proof, lines 198-214; local Lean inventory.

- **Derived:** The for-all fiber predicate is the maximal sound descent of an authorization predicate: inverse-image(B) subset A iff B subset forall_q(A). Fiber-constant predicates descend exactly; a mixed fiber blocks accepting the whole class. Constructor separation and exception propagation are distinct companion results.
- **Wrong or limited:** The six-role architecture is a proposed design, not a necessary security theorem. Fiber quantification may reject safe individual representatives in a mixed class; the theorem intentionally prioritizes soundness. It does not authenticate authority data or establish process isolation.
- **Next exact obligation:** Instantiate q and A for one actual representation boundary; construct and test an implementation of the for-all predicate on a closed finite domain and prove the bridge to issued capabilities.
- **Evidence anchors:** `lean4/AuthorityDescent.lean`, `AuthorityResidual.lean`, `ExceptionPipeline.lean`, `QuotientBoundary.lean`; the inspected proof is a set-theoretic adjunction, not a cryptographic construction.

### 17. The authority gap: claims, verification and accountable use

[Manuscript](../../omega_engine_atlas/coda_atlas/F004_papers/001_finite_obstruction_calculus/005_the_authority_gap/the_authority_gap.md). Read: abstract; Proposition 3.1 proof, lines 75-93; current ledger.

- **Derived:** With positive local-acceptance probability, zero conditional failure means acceptance soundness almost surely on that accepted population. Finite hidden-bit examples refute automatic composition. Backlog growth is elementary accounting under stated constant actual rates.
- **Wrong or limited:** Zero conditional failure does not require the boundary to preserve every distinction outside the accepted population. Pointwise soundness requires positive mass on every point. The seven responsibilities are policy design; a digest does not prove process execution or independent provenance.
- **Next exact obligation:** For a concrete workflow, declare accepted support and sample weights, distinguish undefined zero-acceptance denominators, and measure global outcomes independently.
- **Evidence anchors:** Ledger CLM-005-015/016; `lean4/AuthorityGap.lean`: finite `restricted_acceptance_zero_defect` and `global_evaluation_does_not_factor` differ from the general probability theorem.

### 18. Conditional density lifts and a primal-dual alignment statistic

[Manuscript](../../omega_engine_atlas/coda_atlas/F004_papers/001_finite_obstruction_calculus/009_conditional_density_lift_and_dual_witness_xi_functional/density_lift.md). Read: complete mathematical construction and proof, sections 2-7, lines 38-218.

- **Derived:** Signed square-root normalization gives a rank-one projector for every nonzero real vector. Compact optimal primal/dual sets admit a coordinate-order lexicographic selector. Complementary slackness forces sign agreement on primal support and yields Xi <= sqrt(1-1/N) < 1; zero distance requires equal support and uniform primal magnitudes there.
- **Wrong or limited:** The lift is undefined at zero; Xi=0 there is a separate convention. Numerical code accepts supplied vectors and does not certify optimality or implement the successive selector. Its floating LP output is not an exact certificate. The decision policy applies its ratio guard only in its third branch.
- **Next exact obligation:** Implement an exact rational selector/certificate adapter or explicitly retain the numerical-only API, and prove the intended primary/secondary policy comparisons on actual certified values.
- **Evidence anchors:** `code/mod_conditional_density_lift_core.py`; `lean4/Xi.lean` covers discrete integer/rational identities, not the real matrix/compactness/square-root proof.

### 19. Operator lifts, trace metrics and representation limits

[Manuscript](../../omega_engine_atlas/coda_atlas/F004_papers/001_finite_obstruction_calculus/013_operator_lifts_trace_metrics_and_representation_limits/operator_lifts_trace_metrics_and_representation_limits_monograph.md). Read: abstract; chain residual proof, lines 43-59; full fiber proof, 93-118; seven-row ledger.

- **Derived:** Diagonal embedding preserves ell-one norm as trace norm. Signed-square-root projectors identify exactly nonzero scalar multiples; mass and an orientation anchor are required for reconstruction. DB=0 gives Gamma <= norm(D)*Phi by taking the infimum of the residual inequality.
- **Wrong or limited:** Trace distance is a pseudometric before projective quotienting. Integer Lean identities do not construct the continuous projective fiber or global sign-obstruction theorem. Scale-insensitive shape comparisons cannot replace residual mass.
- **Next exact obligation:** Mechanize the continuous/projective statement or supply a checked exact finite algebraic carrier with explicit mass/orientation recovery and metric separation.
- **Evidence anchors:** Ledger C01-C07; `lean4/Lifts.lean`: `trace_norm_eq_mass`, `weight_scale_cross`, `trace_gap_identity` are narrower than the real claims.

### 20. Candidate selection with residual and constraint diagnostics

[Manuscript](../../omega_engine_atlas/coda_atlas/F004_papers/001_finite_obstruction_calculus/018_constraint_level_regulation_via_multi_channel_obstruction_diagnostics/constraint_regulation.md). Read: abstract; DB=0 residual proof, lines 54-70; tolerance selection proof, 147-157; implementation scope.

- **Derived:** Closure and quotient residuals obey Gamma <= L*Phi on a finite complex. Feasible candidates satisfy literal primary non-increase and an exact ratio ceiling before tolerance-band ranking. Nonempty finite bands give the stated near-minimum score and alignment bounds.
- **Wrong or limited:** The channels are not algebraically independent. A ratio ceiling does not prevent deleting task constraints; a greedy ranking does not establish convergence. Tolerance ranking can intentionally select a larger secondary score within the allowed band.
- **Next exact obligation:** Add explicit protected-constraint preservation/transport to each representation-expanding proposal and prove a well-founded progress measure if termination is required.
- **Evidence anchors:** `code/mod_constraint_regulation_core.py` exact rational routines; `lean4/Regulate.lean`; manuscript Proposition 4.1 and section 6 limitations.

### 21. Observer-relative control of cochain residuals

[Manuscript](../../omega_engine_atlas/coda_atlas/F004_papers/001_finite_obstruction_calculus/019_observer_robust_control_of_obstruction_diagnostics/observer_control.md). Read: abstract; coordinate-bound proof, lines 111-120; one-edge counterexample, 122-127; raw-norm proof, 146-162.

- **Derived:** A weighted norm bounds each input coordinate, while a quotient seminorm bounds coordinates only of a chosen minimizing residual. The one-edge incidence image is all scalar fields, so Phi(t)=0 for arbitrarily large raw t despite complete coverage.
- **Wrong or limited:** Complete coordinate coverage does not convert a distance-to-subspace bound into a raw-state bound. Different observers can choose incompatible residual representatives. The integer norm Lean development is not the numerical projected quotient optimizer.
- **Next exact obligation:** Construct a joint detector and prove adequacy on the actual realizable defect space; state whether every bound concerns raw fields, selected representatives or quotient classes.
- **Evidence anchors:** `lean4/ObserverRobustControlCore.lean` and `JointDetectorAdequacy.lean`; `code/mod_observer_robust_control_core.py`; manuscript Counterexample 4.2.

### 22. Proposal selection and continuation-stable diagnostics on finite graphs

[Manuscript](../../omega_engine_atlas/coda_atlas/F004_papers/001_finite_obstruction_calculus/026_operator_proposal_layer_for_finite_l1_obstruction_systems/operator_proposals.md). Read: abstract; exactness proof, lines 59-68; decision invariance, 137-148; continuation characterization.

- **Derived:** On a connected finite graph, vanishing cycle sums construct a potential by path integration, hence exactness. Equal before/after diagnostic tuples give equal decisions because the policy is a function of those tuples. Future-equivalent states require every declared continuation, not just current diagnostics.
- **Wrong or limited:** Diagnostic numbers must be recomputed from candidate fields; caller assertions are insufficient. Strict rational descent can be infinite. The continuation quotient depends on the full transformation family and executable endpoint matching.
- **Next exact obligation:** Bind one actual proposal dispatcher to field-recomputed diagnostics and prove transition-domain, cost and endpoint preservation for its chosen compression.
- **Evidence anchors:** `lean4/Proposal.lean`; `code/mod_operator_proposal_core.py`; the manuscript explicitly uses the decreasing 1/n counterexample to termination.

### 23. The authority firewall: separation of evidence from authority

[Manuscript](../../omega_engine_atlas/coda_atlas/F004_papers/001_finite_obstruction_calculus/027_the_authority_firewall_a_machine_checked_separation_of_evidence_from_authority_in_finite_systems/authority_firewall_monograph.md). Read: lead scope and ledger; ResidualNonCreation.lean, lines 36-109 and guard bridge.

- **Derived:** Sum.inr residuals cannot inhabit the Sum.inl authority summand. An inhabited residual type makes the for-all family of contrary membership proofs empty. The truthful-guard obstruction theorem additionally assumes that a zero-delta guard implies actual coboundary exactness.
- **Wrong or limited:** Constructor disjointness does not prevent constructing a fresh AuthEvidence record. Seven Boolean fields do not authenticate seven checks. The categorical natural-transformation claim remains conditional on H3 and an unproved reduction bridge; AF-03/04 refer to missing historical files with narrowed negative-boundary status.
- **Next exact obligation:** Construct an authority evidence type whose issuers and binding checks enforce the intended trust boundary; prove the concrete truthful-guard implication and categorical bridge at their actual scope.
- **Evidence anchors:** `lean4/ResidualNonCreation.lean::residual_not_auth`, `authExtractor_empty`, `authority_only_via_evidence`; ledger AF-01/03/04/20/22. Source #print axioms commands were not executed.

### 24. Finite authority and non-terminal computation

[Manuscript](../../omega_engine_atlas/coda_atlas/F004_papers/001_finite_obstruction_calculus/028_finite_authority_and_non_terminal_computation/finite_authority_and_non_terminal_computation_monograph.md). Read: abstract and imported-dependency account, lines 25-63; current ledger and local Lean inventory.

- **Derived:** The package records finite split, two-point witness, three-point refusal, halt-status separation and counterfeit-status separation. The broad proposal/authority architecture is imported from other layers, with the known positivity gate explicit.
- **Wrong or limited:** The fifteen LLM-spine arguments live in archived prose and are not theorems of this deposit. Proposal non-authority is a declared authority regime, not a capability bound or an impossibility of correct self-checking. The known-gate positivity premise is not discharged here.
- **Next exact obligation:** Trace every used T1-T15 claim to its actual current theorem home and discharge PL-027-2; prove detector separation rather than assuming positivity of the chosen gauge.
- **Evidence anchors:** `lean4/FiniteAuthority.lean`; ledger C1/C1a identifies negative boundaries and open obligations. The manuscript explicitly separates this LLM-spine numbering from the imported authority-framework numbering.

### 25. The Anomalon boundary

[Manuscript](../../omega_engine_atlas/coda_atlas/F004_papers/001_finite_obstruction_calculus/029_the_anomalon_boundary/the_anomalon_boundary_monograph.md). Read: abstract; current claim ledger; FiniteBoundary.lean, lines 9-103.

- **Derived:** The finite classifier separates exact/closed, nonclosed and closed/nonexact cases. C3 telescoping rules out (1,1,1) as an integer coboundary. Continuation tags and positive-metric lift authorization follow explicit definitions. The root boundary is supplied as a coproduct.
- **Wrong or limited:** NoAuthorityWithoutDescent unfolds a conjunct of HasAuthority; it is not an executed descent verifier. Time, space, truth and meaning entries are vocabulary/audit hooks, not ontological derivations. Difference-first structure generation remains a conjecture. promotesAuthority=false holds by rfl.
- **Next exact obligation:** Choose a substantive carrier, construct a nontrivial descent packet/checker and prove its soundness; keep carrier-origin and physical interpretation obligations separate.
- **Evidence anchors:** `lean4/FiniteBoundary.lean::c3_cycle_not_exact`, `filled_triangle_comp`, `anomalon_does_not_promote`; ledger C2/C7/C9/C15, plus `OntologyBasic.lean` for supplied root data.

### 26. The authority firewall and verification limits

[Manuscript](../../omega_engine_atlas/coda_atlas/F004_papers/001_finite_obstruction_calculus/030_authority_firewall_and_verification_limits/authority_firewall_and_verification_limits_monograph.md). Read: scope/calibration theorem; Calibration.lean, lines 19-93; principal ledger rows.

- **Derived:** Class-constant specification and detector agree globally if representatives meet every class and agree there. Flipping an omitted disjoint class gives the sharp coverage counterexample. The proof passes equality through a representative; its premises carry the coverage burden.
- **Wrong or limited:** Four calibration examples cannot establish arbitrary detector adequacy. Python witness sealing/HMAC is a reference security contract, not a general theorem that no computable program can forge a capability. Authentic process isolation and principal identity need their own threat model.
- **Next exact obligation:** Close OBL-AVF-02 public-key validation and OBL-AVF-03 PFP pilot binding with independently scoped security tests; derive the actual partition/class-constancy rather than only supplying them.
- **Evidence anchors:** `lean4/Calibration.lean::calibration_from_representatives`, `representatives_from_calibration`, `sharpness`; ledger AVF-030-C11 distinguishes the theorem from implementation contracts.

### 27. Finite distinction carriers and history escape

[Manuscript](../../omega_engine_atlas/coda_atlas/F004_papers/001_finite_obstruction_calculus/032_witnessed_difference_finite_distinction_carriers_and_history_escape/wd2_finite_distinction_carriers_and_history_escape.md). Read: abstract/status; FiniteDistinction.lean, lines 10-110; claim boundaries.

- **Derived:** Recursive finite-horizon observation equality is an equivalence and decreases with horizon. Once global adjacent-horizon equality is assumed, induction preserves it. Written finite-state partition refinement supplies the classical stabilization/minimal quotient account.
- **Wrong or limited:** The Lean relation ranges over Nat states and its stability theorem assumes the fixpoint; it does not prove finite stabilization. Only WD2-T1 is a Lean theorem and the five-state bound is one instance. The general counting and quotient mapping-property statements remain prose/withdrawn mechanization claims.
- **Next exact obligation:** Introduce an explicit finite closed state set and prove class-count termination, word-kernel equivalence and quotient mapping property with empty-state/alphabet cases.
- **Evidence anchors:** `lean4/FiniteDistinction.lean::related_mono`, `related_stable`, `sharp_m5_bound`; ledger WD2-L1 and WD2-T2-T6 must retain their narrowed status.

### 28. Path-additive coboundary defects for reasoning trace validation

[Manuscript](../../omega_engine_atlas/coda_atlas/F004_papers/001_finite_obstruction_calculus/033_reasoning_trace_validation_via_l1_obstruction_geometry/reasoning_trace_validation_via_l1_obstruction_geometry_monograph.md). Read: abstract/realization contract, lines 18-58; evidence/claim ledger distinctions.

- **Derived:** The proposed protocol extracts a finite carrier and diagnoses that carrier by exact repair, witnessed obstruction or typed refusal. It correctly separates carrier-relative exactness from truth of surrounding language and operational permission.
- **Wrong or limited:** The sentence that text cannot be scored directly by heuristics is too absolute as mathematics: a heuristic score can be defined, but need not certify semantics. Deterministic extraction alone does not prove semantic fidelity: ledger PL-014-2 explicitly leaves extractor adequacy open, exhibits a collapsing extractor with C1=0, and row C14 says the proposed trace validator is unimplemented. The front matter has conflicting RELEASED v2.0.0 and v1.0.1 preprint blocks.
- **Next exact obligation:** Define a concrete task-to-carrier preservation theorem and a sound extractor for a stated fragment; add negative examples where exact extracted structure represents false prose. Reconcile duplicated version metadata.
- **Evidence anchors:** Manuscript section 2 task tuple; `reasoning_trace_validation_via_l1_obstruction_geometry_claim_ledger.md`. No paper-local Lean file was found in the top-level lean4 glob; external formal homes remain dependencies, not freshly checked proof.

### 29. A quantum observer implies a quantum carrier?

[Manuscript](../../omega_engine_atlas/coda_atlas/F004_papers/001_finite_obstruction_calculus/034_quantum_observer_quantum_carrier/a_quantum_observer_implies_a_quantum_carrier.md). Read: complete 37-line essay and question ledger.

- **Derived:** It separates the question of negligible accessible interference from the question of a particular recorded outcome. A declared observer requires a carrier, but the definition does not make that carrier quantum. No theorem is claimed.
- **Wrong or limited:** No confirmed mathematical contradiction in the inspected question text. It contains an agenda and imported physics discussion; it neither derives stable classical records nor supplies outcome-selection dynamics. Its citations were not checked live.
- **Next exact obligation:** Specify a finite system-apparatus-environment model, record distinguishability criterion, allowed operations and error bounds; state any extra interpretive or dynamical outcome premise.
- **Evidence anchors:** `claim_ledger.md` Q1-Q3 remain open questions; no local Rust or Lean result is promoted.

### 30. LGGR: observer tuple, empirical presheaf and three-role gate

[Manuscript](../../omega_engine_atlas/coda_atlas/F004_papers/001_finite_obstruction_calculus/035_lggr_quantum_observer_presheaf/lggr_and_the_quantum_observer_presheaf.md). Read: scope/source table, lines 1-50; narrowed B11 and open ledger claims; parity theorem source location checked.

- **Derived:** The finite parity-section result is existence iff holonomy zero for a nonempty cycle, with positive-mass exclusion when holonomy is one. The gate models role distinction. Empirical-model LP/support notions are kept apart in the ledger.
- **Wrong or limited:** The cited Rust empirical_presheaf.rs is now a module directory, so that exact file link is stale. Saying this answers FOC-034 in the finite case exceeds its result: gluing/parity does not derive decoherence or a recorded outcome. Some rows remain computed or explicitly vacuous historical tests.
- **Next exact obligation:** Correct source links; prove rational normalization, no-signalling/coboundary equivalence and concrete Scenario-to-Lean correspondence. Retain Q1-Q3 as open rather than interpreting the parity theorem as measurement theory.
- **Evidence anchors:** `lean4/quantum_mechanics/LggrFiniteResults.lean` is repository-root evidence outside the paper package; `section_exists_iff_holonomy_zero`, `no_joint_measure_when_holonomy_one`; ledger L035-L1 stays open.

## Family 015: PFP papers and methods drafts

These are the 19 direct numbered package manuscripts. The `publication/` copies are alternate exports and are not counted again. Historical source pins in individual papers are retained; this review does not silently substitute the current implementation for their historical subject.

### 31. The Symbol Game: A first game with S(n), MSS-N and basic packets

[Manuscript](../../omega_engine_atlas/coda_atlas/F004_papers/015_pfp/000_pfp_introduction/paper.md). Read: abstract; worked-example ladder, section 8; teaching-checker claim ledger.

- **Derived:** Eight finite teaching examples distinguish proposal packets from checker receipts, retained marks from observational separation, and stage names from runtime execution. The first example deliberately has one presentation and zero admitted marks.
- **Wrong or limited:** This is an introduction with a local teaching schema, not the full Genesis engine or a proof of general PFP effectiveness. A completed workbook does not establish learner understanding without a response and rubric.
- **Next exact obligation:** Bind each example to an independently predicted changed-input outcome and add a short learner-assessment record; keep native/model routes separately labeled.
- **Evidence anchors:** `code/basic_packets.py`, `lesson_packets.py`; ledger teaching-checker row points to `code/tests/test_basic_packets.py`. No replay executed here.

### 32. PFP I: Exact graph repair and proposal/certificate boundary

[Manuscript](../../omega_engine_atlas/coda_atlas/F004_papers/015_pfp/001_pfp_discrete_cochain_retraction_and_toy_involutions/paper.md). Read: sections 2-4, lines 71-220; current certificate/claim maps.

- **Derived:** For fixed rational reports and positive weights, Phi=0 iff exactness, and adding a coboundary leaves Phi invariant. A balanced, capacity-feasible dual with matching primal value certifies optimality. A directed cycle has optimum min(weight)*abs(holonomy). Some sparse optimum exists; not every optimum is sparse or unique.
- **Wrong or limited:** A section update cannot erase fixed-data obstruction; replacing reports changes the task. The native bounded exhaustive solver described here does not return the complete dual certificate. Strict rational descent alone does not terminate.
- **Next exact obligation:** Connect the actual native return type to a separately constructed and checked dual certificate, preserving the original reports and search-domain bounds.
- **Evidence anchors:** Ledger PFP001-01/02/03; package `code/certificate_gate.py::BqnfCertificateGate`; manuscript weak-duality proof, lines 121-167, checks feasibility before equality.

### 33. PFP II: Signed certificates, resumable search and restricted path pairing

[Manuscript](../../omega_engine_atlas/coda_atlas/F004_papers/015_pfp/002_pfp_signed_presentations_and_search_frontier/paper.md). Read: signed-graph proof and matrix reduction, lines 60-161; frontier scope.

- **Derived:** Path integration over F2 constructs a vertex gauge iff every closed walk has even parity. A fixed-basis real symmetric matrix reduces exactly to this diagonal-sign problem. A shifted nonnegative matrix power series gives positivity of its thermal exponential.
- **Wrong or limited:** Failure in this sign grammar is not failure under arbitrary basis changes. One negative hopping sequence lacking an equal-magnitude positive partner only refutes a specific pairing construction. Bounded incomplete search is UNKNOWN, not an obstruction theorem.
- **Next exact obligation:** Prove the physical Hamiltonian-to-fixed-basis graph transport for each application, and retain a fully replayed prefix/frontier certificate for resumptions.
- **Evidence anchors:** `code/genesis_alpha/sign_graph.py::verify_gauge`, `verify_odd_cycle`, `classify_sign_graph`; ledger PFP002-01/02/03 and `frontier_search.py`.

### 34. PFP III: Admitting failure detectors and testing their effects

[Manuscript](../../omega_engine_atlas/coda_atlas/F004_papers/015_pfp/003_pfp_host_admitted_failure_detectors/paper.md). Read: abstract; transaction worked example, lines 395 onward; evidence boundary, 520-534; ledger P3.

- **Derived:** The declared host charges fuel before a batch and restores semantic state on refusal without refunding fuel. Detector admission distinguishes screening a proposed rule from executing that rule. Exact finite detector lemmas describe the two-signal gate and contributor threshold.
- **Wrong or limited:** The audited baseline returns NO_NATIVE_PORT for all witness routes. A historical receipt reporting terminal certificates therefore cannot establish treatment effectiveness for that host. A phrase detector that also matches a true attractive-Hubbard statement illustrates false suppression.
- **Next exact obligation:** Implement and independently check the missing native routes; then run the frozen randomized matched-feedback experiment with valid near misses, false-suppression intervals and complete source/billing custody.
- **Evidence anchors:** Ledger P3-01/02/03; `code/detector_lemmas.py::gate`, `sound_for_every_panel`, `rejects_no_harmless_rule`; baseline host claims remain source-inspected, not refreshed execution.

### 35. PFP IV: Native verification and custody of finite evidence

[Manuscript](../../omega_engine_atlas/coda_atlas/F004_papers/015_pfp/004_pfp_native_verification_and_evidence_custody/paper.md). Read: abstract; worked carrier and exact arithmetic, lines 203-252; P4 ledger.

- **Derived:** The supplied five-edge/two-face example has face sums seven and five, so Gamma=12. A feasible residual with mass seven and a matching cycle lower bound give Phi=7. Exact candidate replay coexists with refused admission because conformance is partial and attestation unsigned.
- **Wrong or limited:** Packet/request hashes support byte binding, not producer authenticity or a source-to-binary build theorem. Sorted tagged JSON is distinguished from RFC 8785. Package-local historical tests do not renew native evidence at this review pin.
- **Next exact obligation:** Discharge the three unchecked conformance laws and establish reproducible build and authenticated issuance before claiming stronger native admission.
- **Evidence anchors:** Ledger P4-01/02/03; Rust owner names `host.rs`, `protocol.rs`, `tests/host_contract.rs::face_aware_coda_crosses_exact_host_but_global_admission_stays_refused`; the arithmetic is inspectable in manuscript lines 234-241.

### 36. PFP V: A practitioner guide to checked proposals

[Manuscript](../../omega_engine_atlas/coda_atlas/F004_papers/015_pfp/005_pfp_practitioners_field_manual/paper.md). Read: introductory triangle; sections 2 and 9; G005 ledger.

- **Derived:** The triangle with reports (1,1,1), weights (1,2,3), has a hand-attained lower bound three. Potential differences preserve cycle sum, whereas replacing reports by (-2,1,1) creates a different exact instance. Session restoration and refusal are explicitly part of the lesson.
- **Wrong or limited:** The current publication-review native route was unavailable and native tests were skipped; its mocked error test is not Rust execution. Earlier native receipts concern older bytes. The instructional UNKNOWN terminal is not implemented by the four-move governor itself.
- **Next exact obligation:** Build and replay the patched native route under exact source/binary pins, and either implement the instructional budget controller or label it as a separate exercise.
- **Evidence anchors:** G005-01/02/03, `test_offline_worksheet.py`; `code/play_demo.py`, `native_functional.py`; manuscript lines 227-237 explicitly separate historical and current evidence.

### 37. PFP VI: Retained failure evidence and controlled reuse

[Manuscript](../../omega_engine_atlas/coda_atlas/F004_papers/015_pfp/006_pfp_epistemic_immune_system_and_cemetery_dag_mining/paper.md). Read: abstract; three-modification ledger argument, lines 259-338; P6 ledger.

- **Derived:** Hash chains plus an unchanged expected count/head detect specified edits and truncation. A fully rewritten shorter internally consistent ledger can reopen, but differs from an independently retained external anchor. Reuse requires reproducing a failure and checking valid near misses.
- **Wrong or limited:** Logical append-only API is not immutable storage, concurrent-writer safety or crash durability. Holding the anchor beside the adversary-controlled file does not supply external custody. The 61 harvested detector candidates are data, not an executed automatic miner.
- **Next exact obligation:** Add independently retained checkpoint custody, crash/concurrent-writer tests and a scoped detector-transfer study; do not turn missing infrastructure into a mathematical rejection rule.
- **Evidence anchors:** P6-01/02/03; production `omega_engine_pfp/infrastructure/persistence/cemetery_sink.py` is the named owner; manuscript lines 304-338 give the attack and reuse limitations.

### 38. PFP VII: Executable lessons with explicit evidence boundaries

[Manuscript](../../omega_engine_atlas/coda_atlas/F004_papers/015_pfp/007_pfp_executable_lessons_and_evidence_boundaries/paper.md). Read: worked lesson, lines 40 onward; current lesson-design and evidence ledger.

- **Derived:** The displayed potential moves the normalized triangle residual from (1/3,1/3,1/3) to (0,0,1), preserving cycle sum one by telescoping. A lesson consists of a declared example, worked calculation, learner prediction, changed-input probe and evidence boundary.
- **Wrong or limited:** Twenty named notebooks at an audit baseline establish an inventory, not twenty fresh successful runs or learner gains. Self-comparing cells and LP objective equality without feasibility are documented failure patterns, not acceptable evidence.
- **Next exact obligation:** Pair each learning claim with an assessed learner response and independent changed-input control; conduct a learner study before reporting retention or transfer improvements.
- **Evidence anchors:** G007-01/02/03; package `test_007_worked_triangle.py`; the two copied Lean modules have their own formal scope, no new build here.

### 39. PFP VIII: Conservative grammar growth and source-bound evidence

[Manuscript](../../omega_engine_atlas/coda_atlas/F004_papers/015_pfp/008_pfp_mssn_tower_challenges_and_retraction_benchmarks/paper.md). Read: abstract; actual map branches and injectivity proof, lines 85-138; stage evidence sections.

- **Derived:** The actual MSS-0 to MSS-1 map preserves its one old Diff packet, while a new packet produces a typed non-descent receipt. A left inverse establishes injectivity on that declared old domain. Evidence grades distinguish syntax round trips from computed certificate checks.
- **Wrong or limited:** One old-packet round trip does not construct a general tower or prove semantic conservativity. The local teaching toy is explicitly not the actual map. Prompt runs containing repair values and hosts accepting discarded claims do not measure unaided reasoning.
- **Next exact obligation:** For the next adjacent stage, construct actual parser/admission/down-map domains and prove preserved old semantics; measure prompt effects on answer-blind held-out inputs with retention controls.
- **Evidence anchors:** PFP008-01/02/03; `docs/source_archive/mss0_mss1_52cb5457/updown_maps.py`; manuscript names the versioned evidence resolver and its historical-byte boundary.

### 40. PFP IX: Reviewing claims against code and evidence

[Manuscript](../../omega_engine_atlas/coda_atlas/F004_papers/015_pfp/009_pfp_adversarial_dialectics_and_terminal_reality_gates/paper.md). Read: purpose; triangle example; limitations and verification, lines 158-166; G009 ledger.

- **Derived:** The protocol traces a small claim to assumptions, implementation, hostile probe and evidence. The worked triangle separates subtracting a potential from replacing the source claims. Five historical probe records demonstrate four defect families in one terminal gate.
- **Wrong or limited:** This is a review procedure, not a measured reviewer-effectiveness study. String comparison in a semiotic-audit fixture is not semantic equivalence. Copied formal modules and a source explicitly not typechecked cannot certify the integrated routing path.
- **Next exact obligation:** Replay the five original probes against the current gate, bind the formal statement to the code branch, and test review accuracy with blinded claims before any effectiveness claim.
- **Evidence anchors:** G009-01/02/03; `code/triangle_cycle_sum.py`, `review_counts.py`; manuscript states no fresh native, model or Lean run in its own publication review.

### 41. PFP X: Exact host checking on finite algebraic challenges

[Manuscript](../../omega_engine_atlas/coda_atlas/F004_papers/015_pfp/010_pfp_holonomy_checks_and_model_pilots/paper.md). Read: abstract; lattice checker construction; limitations, lines 628 onward; source group validation, lines 43-97.

- **Derived:** The finite group constructor checks identity, inverse and associativity over all listed elements/triples. Ordered plaquette products use inverse links on reversal. On a periodic lattice, flatness and the two noncontractible holonomies distinguish the specified trivial/nontrivial cases.
- **Wrong or limited:** The retained five-case arms differ in prompts, models and budgets; some inputs carry expected answers. The paper recounts 15 fully retained records, not all historical raw responses. Constant refusal can pass two old challenge panels. No causal superiority or unaided capability follows.
- **Next exact obligation:** Freeze answer-blind tasks, preserve all replies and test flatness/holonomy under gauge changes with independent negative controls; separately reconstruct unavailable historical reports.
- **Evidence anchors:** `code/holonomy.py::FiniteGroup._check_axioms`; `replay_c017.py`, `recount_pilots.py`; PFP10-00 explicitly withdraws unretained old filter-effect claims.

### 42. PFP shape, review findings and next test campaign

[Manuscript](../../omega_engine_atlas/coda_atlas/F004_papers/015_pfp/011_pfp_the_minimum_theorem/paper.md). Read: source scope and historical F01-F07 table, lines 18-88; theoretical minimum.

- **Derived:** The declared target is a typed graph of task-preserving checked transformations. The historical reproduction shows rejected outer extraction being bypassed by a correct inner proposal, cyclic prompt dependencies accepted by count checks, and fabricated lineage defaults.
- **Wrong or limited:** These are defects at the named 5e049cde source, not automatically current defects everywhere. The 175 proposed rounds are execution specifications, not new model runs. Ten fixture self-tests did not cover malformed-host or outer-contract failures.
- **Next exact obligation:** Rerun the exact historical falsifiers against the actual current runner; close each issue with valid-pair controls and preserved source/checker lineage before scaling the planned campaign.
- **Evidence anchors:** F01-F07 and the displayed reproduction; `run_host_replay`, `topology_fields`, `lineage_summary`, `validate_stage` are named branch anchors. No providers invoked here.

### 43. PFP XI: The broken referee, archive audit and self-falsification ledger

[Manuscript](../../omega_engine_atlas/coda_atlas/F004_papers/015_pfp/021_recreated_demos_and_proposal_fidelity_evidence/paper.md). Read: abstract; current evidence and remaining-work section, lines 132-192; reconstruction obligations.

- **Derived:** The manuscript distinguishes source census, custody checks, finite mechanism fixtures and historical model results. The documented original Genesis verifier returned verified=true on empty/wrong-task/unproved responses, while its retained CHECKED labels contained timeouts, failures or absent snippets.
- **Wrong or limited:** This review did not independently rerun those recovered verifiers. A complete source inventory is not complete demonstration replay. Schema-valid contradiction labels can pass a retained consistency checker on native-zero-residual inputs; no obstruction witness follows from schema acceptance.
- **Next exact obligation:** Finish positive original-recovery obligations, preserve exact original runner bytes, and replace every label-only route with an independently checked mathematical witness and negative controls.
- **Evidence anchors:** `code/audit_findings.py`, `demo_catalog.py`, `genesis_g03_validate.py` and original-recovery modules are inspected file inventory; source-derived claims and recorded execution claims remain separate.

### 44. PFP XX: Multi-agent tournaments and adaptive noise mitigation

[Manuscript](../../omega_engine_atlas/coda_atlas/F004_papers/015_pfp/022_pfp_frontier_research/paper.md). Read: complete 105-line manuscript; tournament receipt and fallback implementation, code lines 116-170, 228-315, 445-466.

- **Derived:** The actual local construction proposes deterministic braid-operation strategies and computes a rational matrix-conjugation discrepancy. A static commutation predicate can be checked exactly on the chosen matrix carrier.
- **Wrong or limited:** Confirmed source/text defects: equation at manuscript line 31 calls max-entry discrepancy an ell-one norm; they are different norms. The receipt contains a SHA-256 digest and no signing key/signature, so signed cryptographic receipt is unsupported. Failed live requests silently fall back to deterministic strategies while retaining model labels. Imports target absent omega_engine_projects/ms_majorana/code and old provider paths. The current module is under F004/009_ms_majorana/code. Static commutation and SO membership do not establish dynamical echo suppression or logical CNOT semantics.
- **Next exact obligation:** Correct norm/receipt terminology and imports; separate attempted provider output, refusal and offline strategy records; require target logical-channel equivalence and an explicit time-dependent noise model before mitigation claims. Regenerate tables from source-bound receipts with real coverage denominators.
- **Evidence anchors:** `code/adaptive_braid_tournament_demo.py::TournamentRunReceipt.canonical_digest`, `_synthesize_operations`, `_query_openrouter`; broad exception at lines 274-276 returns None. These are static counterexamples, not a run of the tournament.

### 45. Task-bound claims and scope of hallucination control

[Manuscript](../../omega_engine_atlas/coda_atlas/F004_papers/015_pfp/023_pfp_task_bound_claims_and_hallucination_control/paper.md). Read: complete 131-line manuscript; complete code/replay.py.

- **Derived:** Given sound invoked checkers, finite conjunction establishes exactly the checked task predicates. The witness (1,0) satisfies x+y=1 but does not establish every solution has x=1; (0,1) is the counterexample. Source quotation needs a separate bound source-span check.
- **Wrong or limited:** This is the elementary sound-checker conjunction rule; it does not prove the checker sound or extract faithful obligations from arbitrary prose. The local source_quote=False is an explicit missing-evidence control, not a quotation engine.
- **Next exact obligation:** Implement one actual prose-to-obligation extraction fragment and a source-span checker, retaining original task/witness/checker bindings through prompt rendering.
- **Evidence anchors:** Proof lines 58-70; `code/replay.py::check`, lines 7-17; no Lean or model-inference claim is made.

### 46. Recursive re-entry with evidence scope and shared fuel

[Manuscript](../../omega_engine_atlas/coda_atlas/F004_papers/015_pfp/024_pfp_recursive_reentry_and_evidence_scope/paper.md). Read: complete 122-line manuscript; complete replay helper.

- **Derived:** Backward sound solution maps compose; forward coverage maps are a separate obligation. Left-inverse laws compose. Positive minimum operation charge delta and a never-reset budget B bound operations by floor(B/delta). A source-sound rejection rule can reject the only solution after a task change.
- **Wrong or limited:** The example checks ledger equality and unit costs, not the existence/correctness of actual native solution adapters. An empty backward map is vacuously sound but loses coverage. Free uncharged operations or silently reset budgets invalidate the claimed bound.
- **Next exact obligation:** Construct and independently verify one native re-entry adapter with explicit forward coverage, backward decoding, parent identity and all relevant charges.
- **Evidence anchors:** Proof lines 48-61; `code/replay.py::check_step`, lines 4-15. It rejects Boolean cost and budget resets in its declared synthetic profile; no execution renewed here.

### 47. Local witnesses and global compatibility in agent composition

[Manuscript](../../omega_engine_atlas/coda_atlas/F004_papers/015_pfp/025_pfp_local_to_global_agent_composition/paper.md). Read: complete 120-line manuscript; complete replay helper.

- **Derived:** Locally allowed selected rows glue uniquely on their union iff overlaps agree. Full variable coverage gives a bijection to global constraint solutions. Equality/equality/inequality on a Boolean triangle gives three satisfiable local tables and no global solution.
- **Wrong or limited:** Confirmed helper boundary defect: check_family tests row count but not relation count. With three (0,0) rows and an empty relations tuple, zip skips membership checks, and decoding returns (0,0,0). This is a static walkthrough, not an executed test; it affects malformed supplied task tables, not the written theorem with all relations supplied. Python equality also needs an explicit type policy for any generalized domain.
- **Next exact obligation:** Validate exactly three relation tables or bind the supplied task to a fixed schema before any zip; reject missing constraints and add an otherwise-valid positive control. Prove effects/timing/authority contracts separately for real agents.
- **Evidence anchors:** Proof lines 47-60; `code/replay.py::check_family`, lines 12-21. Existing main fixtures always pass three relations and do not exercise the omission.

### 48. Compression preserving future operations and cost

[Manuscript](../../omega_engine_atlas/coda_atlas/F004_papers/015_pfp/026_pfp_future_faithful_compression_and_cost/paper.md). Read: complete 129-line manuscript; complete replay helper.

- **Derived:** Equal terminal labels, action enablement, enabled costs and successor fibers are necessary/sufficient for exact deterministic operation quotienting. Refinement terminates after finitely many block splits. Positive-cycle deletion reduces optimal finite route search to simple paths.
- **Wrong or limited:** Current-answer equality can preserve a task answer while losing future capability/cost. This deterministic table theorem does not certify stochastic or hidden-state adapters. The finite helper uses exact fractions, but its domain remains the supplied table, not a physical observer.
- **Next exact obligation:** Bind actual native states, edits, guards and costs to the table; prove a bounded arena construction for any adversarial or stochastic extension.
- **Evidence anchors:** Proof lines 48-75; `code/replay.py::refine`, `minimum_cost`, `check_route`; minimum_cost rejects nonpositive prices before enumerating simple paths.

### 49. Glyphs, rewrites, logits and attention as checked proposal channels

[Manuscript](../../omega_engine_atlas/coda_atlas/F004_papers/015_pfp/027_pfp_proposal_channels_and_internal_interventions/paper.md). Read: abstract/theorem map; Theorems 1/2/5/12 with proofs; trial 8/9 table and limits; replay routines at lines 446-481.

- **Derived:** Channel-independent admission soundness follows pointwise from parser binding and a sound checker, regardless of proposal distribution. Cycle telescoping and duality give weighted lightest-edge repair. Guarded retry formulas require the stated conditional retry-law and Stage-2 dependence assumptions. Tree/chord splitting and syndrome equations make smaller exact guard tasks.
- **Wrong or limited:** Confirmed implementation gap: verify_committed_c004_and_c006_receipts returns True when the mechanism directory is absent, so a standalone PASS can omit its advertised recount without a typed missing status. The cohomology verifier demo checks only C015 and C018 arithmetic, not all ten production checkers. Theorem 12 assumes certificate-predicate equivalence rather than proving each checker. Its for-all bad-coordinate argument requires nontrivial witness/schema conditions. Zero-admission conditional precision is undefined; saved Stage-2 cost excludes retry/guard cost. Tables with unequal calls do not isolate a causal prompt effect.
- **Next exact obligation:** Emit NOT_RUN/MISSING for unavailable receipts; audit all ten actual verifier implementations with nonvacuous positive and mutated certificates. State zero-admission handling and full resource costs, and run a held-out equal-budget comparison independent of guard-provided answers.
- **Evidence anchors:** `code/replay.py::verify_b_cohomology_exact_certificate_checker`, lines 446-472; `verify_committed_c004_and_c006_receipts`, lines 475-481; theorem proofs at manuscript 107-116, 171-185, 319-329, 775-782. No empirical values were independently recounted here.

## Family 014: public essays and separate technical companion

The five numbered essays are distinct prose texts. The 1,511-line technical companion adds substantial architecture and intervention material, so it has a separate sixth entry. Feed-post excerpts, images and three level outlines are not additional manuscripts. These pieces are explanatory proposals; they do not inherit proof or execution status only by linking a research paper.

### 50. What the hell is an observer?

[Manuscript](../../omega_engine_atlas/coda_atlas/F004_papers/014_linkedin_articles/linkedin_article_001_what_the_hell_is_an_observer_v001.md). Read: observer tuple and quotient argument, section 4; repair algebra, section 6; closure/quantum boundaries.

- **Derived:** The report equivalence is the kernel of the declared question family. If the allowed repair image is a subgroup/subspace, quotienting is legitimate; a restricted repair subset instead requires direct constrained distance. DB=0 makes closure invariant under admitted coboundaries.
- **Wrong or limited:** Confirmed mathematical wording defect in section 6: from delta=d0(f), it says delta is repairable iff that particular f is admitted. Noninjectivity invalidates this. Let Adm={0}, choose nonzero constant potential f on a connected graph, and delta=d0(f)=0. Then delta is repairable via admitted 0 although f is not admitted. The correct criterion is existence of some admitted preimage. Definition of observer also does not authenticate an authorization regime.
- **Next exact obligation:** Replace the particular-witness iff by existential admissibility and add the constant-potential counterexample. Keep physical record realization and operational authority as separate contracts.
- **Evidence anchors:** Lines 209-230, especially the sentence after B_O is defined. The counterexample is derived symbolically here, without executing code. The essay has no local checker providing this guarantee.

### 51. What the hell is authority?

[Manuscript](../../omega_engine_atlas/coda_atlas/F004_papers/014_linkedin_articles/linkedin_article_002_what_the_hell_is_authority_v001.md). Read: complete operational contract, lines 152-224; root limitation, lines 267-279.

- **Derived:** Authorization is explicitly a regime plus a scoped attempt, evidence, role policy, issuance decision and certificate verification. Authentic signing is distinguished from legitimate issuance. Fail-closed routing is defined as the promoted/refused sum.
- **Wrong or limited:** The contract assumes implementations of IssueCertificate, Verify and policy checks; writing the piecewise function does not establish them. Distinct identity labels do not directly prove independent control, despite the phrase check independence directly. The author correctly leaves the legitimacy of the trust root outside the calculus.
- **Next exact obligation:** Provide one executable authorization example binding a real issuer, frozen policy, scope and evidence; add role-alias and key-compromise cases under an explicit threat model.
- **Evidence anchors:** Section 4 Authorize definition, lines 185-191; certificate binding, 201-214. No institutional legitimacy or cryptographic unforgeability theorem is inferred.

### 52. What the hell is difference?

[Manuscript](../../omega_engine_atlas/coda_atlas/F004_papers/014_linkedin_articles/linkedin_article_003_what_the_hell_is_difference_v001.md). Read: report proof and sharp tag count, lines 141-195; recovery-defect derivation, 304-336; spinor boundary, 380-402.

- **Derived:** Fiber-constant answers descend. The joint report (p,q) is the coarsest equivalence refinement preserving both; unrestricted finite tags need at least the largest number of answer classes within one report fiber. A chain retraction cannot kill a nonzero homology class, and a nonchain recovery map retains that class in its compatibility defect.
- **Wrong or limited:** The tag minimum assumes unrestricted functions and does not construct an acquisition instrument. The spin-half representation and coherent interferometer are supplied physical models, not consequences of primitive distinctions. The recovery-defect bound requires a functional annihilating boundaries; it is correctly stated in the current text.
- **Next exact obligation:** Attach an exact finite companion for tag coloring and recovery-defect equality, then separately bind any laboratory claim to original experimental data and uncertainty/control assumptions.
- **Evidence anchors:** Fiber proof at 151-161; class-count formula at 179-183; K_j boundary identity at 320-336. External neutron references were not verified live.

### 53. What the hell, John Bell?

[Manuscript](../../omega_engine_atlas/coda_atlas/F004_papers/014_linkedin_articles/linkedin_article_004_what_the_hell_john_bell_v001.md). Read: master-ledger/CHSH derivation, lines 112-237; witness-versus-cohomology distinction, 261-289.

- **Derived:** For a deterministic local row, exactly one of B0+B1 and B0-B1 is zero, giving absolute CHSH value two. Nonnegative measurement-independent mixtures obey the same bound. The supplied singlet directions give 2*sqrt(2). The complete CHSH family is distinguished from one orientation, and violation excess from a general Cech obstruction.
- **Wrong or limited:** No confirmed algebraic error in the inspected CHSH calculation. Fine/Tsirelson and experimental statements are imported, not independently proved or source-verified here. Bell locality, no-signalling and quantum realizability remain different assumptions; the LGGR language is an interpretive crosswalk.
- **Next exact obligation:** Add an exact rational/algebraic four-table companion showing all eight facets and the PR contrast, with an explicit map from each measured table to the stated normalization and witness.
- **Evidence anchors:** Lines 150-168 give the classical proof; 200-218 the chosen quantum calculation; 178-185 state Fine equivalence with compatible marginals. No claim of fresh experiment.

### 54. What the hell is a prompt, and how do you write one?

[Manuscript](../../omega_engine_atlas/coda_atlas/F004_papers/014_linkedin_articles/linkedin_article_005_what_the_hell_is_a_prompt_v001.md). Read: linear-system packet and direct substitution; transitivity boundary; wire/family and antibody examples; final evaluator-scope rule.

- **Derived:** The example x+2y=5, 2x-y=0 has x=1, y=2. Checking only sum three misses candidate (3,0), which violates both equations. Prompt families are defined relative to the same protected task and acceptance predicates; negative-control tasks belong to a different associated family.
- **Wrong or limited:** The operational witness improves what a host can check; it is not evidence of a measured model reliability gain. The sentence that an omitted substitution license makes a solver guess a hidden rule is too broad outside the declared game: ordinary field algebra can be an already supplied background. Wire canonicalization also needs a specified grammar and number encoding, not only whitespace removal.
- **Next exact obligation:** Link the copyable packet to an actual parser/checker demonstration, state background mathematical rules, and measure presentation effects on answer-blind paired tasks.
- **Evidence anchors:** Sections 2-6 contain the packet, two-equation decoy and antibody schema; section 7 explicitly limits proof/test/model scopes. No provider result was inferred from an illustrative example.

### 55. What the hell is a prompt? Technical companion

[Manuscript](../../omega_engine_atlas/coda_atlas/F004_papers/014_linkedin_articles/pfp/linkedin_article_005_what_the_hell_is_a_prompt_technical_companion_v001.md). Read: witness argument, lines 413-437; confluence/descent boundaries, 474-487; stage-mode diagram, 874-919; logit and activation-patching mathematics, 1169-1298.

- **Derived:** The intermediate bindings expose the same false-sum decoy. The two algebraic reductions illustrate a common answer, with full PFP confluence explicitly left open. Hard grammar masks restrict proposer support; clean/corrupt patching defines a measured logit contrast and normalized restoration metric, with baseline separation required.
- **Wrong or limited:** No general theorem or trial supports dramatically improve verification reliability at line 415. A complete strict-descent termination argument needs a well-founded measure; weak nonincrease allows loops. The softmax formula needs positive temperature and nonempty admissible support. A patch restoring logits does not prove a head independently computed the derivation, which the current text acknowledges. Architecture diagrams and synthetic telemetry are specifications, not live receipts.
- **Next exact obligation:** Provide one parser-bound finite packet and one reproducible intervention experiment with tokenizer/context/position alignment, nonempty-mask handling, measured baselines, sham patches, ablations and raw output custody; keep correctness on the independent host.
- **Evidence anchors:** Intermediate Witness Verification at 431-437; Newman limitation at 479; host-only Stage 5 at 908-909; normalized logit difference at 1290-1298. Illustrative telemetry is explicitly SYNTHETIC_FIXTURE_CANDIDATE.

## Reproducibility, formal premises and unread limits

The conclusions above have three distinct strengths:

- **Source-derived counterexamples/defects:** observer particular-preimage biconditional; PFP 022 norm/signature/fallback/import discrepancies; PFP 025 omitted relation-count check; PFP 027 absent-directory success. Their logic is inspectable in the cited source. No fresh execution result is claimed.
- **Read mathematical arguments:** fiber factorization, graph-cycle duality, Boolean defect arithmetic, finite-table gluing, budget composition, partition refinement, rank-one fiber geometry and selected residual inequalities. This review found the stated conditional proofs coherent at the inspected loci unless a defect is stated explicitly. This is not a certification of every lemma or an originality determination.
- **Recorded execution evidence:** test counts, provider outcomes, compiler versions, DOI labels and prior PASS tokens in the manuscripts remain historical assertions. They were not reproduced by this review, and they do not become fresh receipts through quotation.

Lean has two premise layers: ordinary kernel axioms such as Classical.choice, propext and Quot.sound where actually used, and mathematical hypotheses supplied as structure fields or theorem arguments. A theorem with no custom kernel axioms may still assume a sound detector, truthful guard, positive-definite norm, admitted complex structure or faithful parser. Such assumptions cannot be removed by calling the source axiom-free. Source-to-code correspondence and authentic issuer identity are further obligations outside an abstract model theorem.

Unclosed reading work includes WDP's full proof dependency graph and all 17,685 lines, every claim-ledger row across the 30 foundational packages, the complete source of every PFP checker, every archive export and dependency, all original model replies, and the external literature. The ongoing Genesis copy is intentionally assigned to its separate reader. This report does not claim an exhaustive proof audit, a full bibliography audit or a successful replay of every paper.

## Concrete next derivation queue for these texts

| Order | Deliverable | Acceptance condition |
| --- | --- | --- |
| 1 | Correct PFP 022 evidence/semantics boundary | Max norm named correctly; offline/provider provenance disjoint; authenticated signatures claimed only when verified; target-channel and dynamical-noise assumptions explicit. |
| 2 | Close two malformed-input checker gaps | PFP 025 missing relation tables refuse; PFP 027 absent receipt corpus emits explicit missing/unrun status; useful positive controls remain. |
| 3 | Repair the observer admissibility criterion | Existential admitted preimage stated; constant-gauge counterexample retained. |
| 4 | Audit all ten cohomology certificate owners | Every positive claim names actual algebraic checks, independent witnesses, invalid-certificate controls and a source-bound receipt. |
| 5 | Build one finite-QM vertical derivation | Carrier, scalar field, state/effect/process rules and original question are fixed; exact witness transport is proved; no quantum assumption is silently obtained from a mark. |
| 6 | Complete finite observational quotient proof | Explicit finite closed state domain, stabilization count, shortest distinguishing word and quotient mapping property. |
| 7 | Certify realizable-space detector recovery | Compute/prove a bound on im(D), including coupling and zero-space cases, rather than ambient watcher coverage alone. |
| 8 | Bind an actual native re-entry adapter | Backward soundness, forward coverage, parent receipt and never-reset paid fuel all checked on actual state transitions. |
| 9 | Reconcile navigation and manuscript identity | Family trio registry and LGGR paths resolve; 000_pre_genesis_to_mssn has an explicit role; alternate exports do not inflate the census. |
| 10 | Independent scholarly/replay package | Every central claim has a current prose/formal/code/empirical status, precise source locus, reproducible command and independent negative control; bibliographic originals checked separately. |

These are paper-specific research and repair priorities. They do not replace the repository-wide project ranking or overall code-quality grade in the final architecture-review table of contents.
