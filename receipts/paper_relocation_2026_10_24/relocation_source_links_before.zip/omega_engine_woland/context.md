# Woland Swarm Bounded Context

The universal swarm deliberation, Bulgakovian red-team audit, and evidence encapsulation engine for the Omega Engine ecosystem.

AuthorityEffect: None.

The [Retinue gate integration map](_docs/retinue_gate_integration.md) links the 22 PFP primary gates, 10 intergates and 3 empirical specifications to workflow review phases and the scoped diagnostic CLI. Native transition composition and trusted-checker configuration remain explicit residuals.

## Architectural Topology & Execution Hierarchy

The execution hierarchy of the agentic estate operates under a strict 5-layer sovereignty model:

```
+-------------------------------------------------------------------------------+
|                             9 Sovereign Estates                               |
|  (prompt_civilization, research_papers, product_planning_office, projects,   |
|   epistemic_immune_system, cognitive_operations, education, atlas, engine)    |
+-------------------------------------------------------------------------------+
                                        ^
                                        | (Direct Typed Estate Communication)
+---------------------------------------v---------------------------------------+
|                    Woland (omega_engine_woland)                               |
|   "Every swarm is Woland in disguise" -- universal base for all swarms       |
|   One base + workload profiles; Governance and Paper retain subclasses       |
+-------------------------------------------------------------------------------+
       |                                                         |
       | (Exclusive LLM Gateway)                                 | (Runs on)
       v                                                         v
+---------------------------------------+         +-----------------------------+
|    Symbol Game Engine                 |         |        WOLAND STAGE         |
|    (omega_engine_pfp)         |         | (omega_engine_woland.stage) |
|    Deterministic retraction manifold  |         |   Pure typed swarm kernel   |
|    Exclusive LLM communication spine  |         +-----------------------------+
+---------------------------------------+                        |
                                                                 | (Runs on)
                                                                 v
                                                  +-----------------------------+
                                                  |           OEOS              |
                                                  | (omega_engine_operating_    |
                                                  |         system)             |
                                                  | Base operating system       |
                                                  +-----------------------------+
```

### Core Hierarchy Directives

1. **OEOS (`omega_engine_operating_system`)**:
   Foundational base operating system providing raw process boundaries, filesystem custody roots, hardware binding, and typed effect ports.

2. **Woland stage (`omega_engine_woland.stage`, formerly Moscow)**:
   Pure typed agentic swarm kernel that runs directly on OEOS. The stage owns typed state machines, deterministic schedulers, memory ports, and seat-turn execution contracts with zero host side effects.

3. **Woland (`omega_engine_woland`)**:
   The sovereign deliberation, adversarial red-team verification, and 7-act cognitive engine running on its stage.
   - **Retinue v0.1 migration:** Ordinary research, software, project, cognitive, teamwork, and swarm-development work uses narrowed profiles on `OmegaEngineWolandSwarm`. Only governing councils and paper review/repair retain named subclasses. This class collapse is implemented in `use_cases/base_swarm/specializations.py`; OEWAS instruction admission and full ingress cutover are still open.
   - Woland coordinates Apartment 50 Bulgakovian dialectics and cryptographically seals immutable research evidence envelopes.

4. **Symbol Game (`omega_engine_pfp`) as Exclusive LLM Gateway**:
   The canonical Woland runtime uses `omega_engine_pfp` seat transport. The legacy `retinue_sandbox` direct-provider path is now quarantined: its toy provider emits only explicit offline fixtures or a typed live refusal. The production import-mediation scan passes, but the retained toy sandbox and its historical tests are not evidence of v0.1 instruction cutover.

5. **Direct Communication with 9 Sovereign Estates**:
   Woland communicates directly with nine canonical estates without intermediate bridge layers or adapter facades:
   - `omega_engine_prompt_civilization`: Prompt schemas, dialectic structures, and civilizational memory.
   - `omega_engine_research_papers`: Monograph packaging, preprints, formal publication gates, and Lean 4 kernels.
   - `omega_engine_product_planning_office`: Product roadmaps, epics, sprint manifests, and execution packets.
   - `omega_engine_atlas/coda_atlas/F004_papers`: Applied research paper programs (`006_finite_qm`, `007_finite_to_continuum`, `008_fsp`, `009_ms_majorana`, `010_mub6`, `011_rh`, `012_rsi`).
   - `omega_engine_epistemic_immune_system`: Mined antibodies, pharmacy catalogs, negative selection gates, and defect quarantine.
   - `omega_engine_cognitive_operations`: Execution receipts, runtime telemetry, traces, and orchestration ledgers.
   - `omega_engine_education`: Curriculum frameworks, pedagogical engines, and scaffolding exercises.
   - `omega_engine_atlas`: EADC catalog, research atlas reconciliation, and structured knowledge spines.
   - `omega_engine`: Sovereign Rust mathematical solver crates, exact arithmetic, and core algebraic primitives.

6. **"There Is No Bridge" (Zero-Facade Directive)**:
   Cross-domain shim layers, bridge modules, and pseudo-adapters (such as legacy `symbol_game_bridge`) are prohibited. Domain packages interact directly via sovereign protocols and typed value objects.

---

## Language & Domain Modeling

### Swarms & Retinue

**Woland Swarm (`OmegaEngineWolandSwarm`)**:
The ordinary execution base with native-checked workload profiles; governing councils and paper review/repair are the only named subclass exceptions. CODA and LGGR ports are licensed only where the profile permits them.
_Avoid_: Agent runner, chat bot swarm, generic agent pool.

**Woland Retinue**:
The dialectical deliberation suite (Apartment 50 Bulgakovian persona ensemble) that subjects candidate proposals to adversarial fireproof audits.
_Avoid_: Multi-agent chat, persona prompt team.

**Research Evidence Envelope (`ResearchEvidenceEnvelopeV1`)**:
An immutable, SHA-256 content-addressed cryptographic envelope binding a task contract, CODA evaluation result, LGGR gluing defect metrics, and Woland deliberation receipt into permanent intelligence custody.
_Avoid_: Output JSON, result summary, response dictionary.

### Invariant Checks

**CODA Evaluation (`CodaEvaluationResult`)**:
Exact rational evaluation across the 9-layer CODA stack over Q, verifying coboundary conditions and zero-allocation contractions without Python floating-point leakage.
_Avoid_: Heuristic score, floating-point solver, metric estimate.

**LGGR Gluing (`LggrGluingResult`)**:
Gluing defect evaluation verifying consistency between local and global evaluators and guaranteeing null-space soundness $\operatorname{im}(D) \cap K = \{0\}$.
_Avoid_: Consistency check, consensus score.
