"""Render the ordered Omega paper-to-engine architecture map.

The picture is a navigation and implementation-coverage view.  It does not
turn a paper relationship, crate dependency, or planned contract into a proof.
"""

from __future__ import annotations

import argparse
import json
import os
import re
import subprocess
import tempfile
from collections import Counter
from pathlib import Path

import tomllib

REPOSITORY = Path(__file__).resolve().parents[4]
PLANS = REPOSITORY / "omega_engine_atlas/coda_atlas/F004_papers/plans"
PAPERS = PLANS.parent
CRATES = REPOSITORY / "omega_engine/crates_rs"
ARCHITECTURE = (
    REPOSITORY
    / "omega_engine_product_planning_office/architecture_review"
)
OUTPUT = ARCHITECTURE / "01_omega_design_dag_svg.svg"
ORDERED_NAME = re.compile(r"^(\d{2})_([a-z0-9_]{20})\.[a-z0-9]+$")
RUST_FILE_CENSUS_MODE = "tracked_git_with_worktree_parity"


def records(path: Path) -> list[dict]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def production_crates() -> list[Path]:
    manifest = tomllib.loads((CRATES / "Cargo.toml").read_text(encoding="utf-8"))
    members = set(manifest.get("workspace", {}).get("members", ()))
    crates = sorted(
        CRATES / member
        for member in members
        if member != "tests"
        and not member.startswith("../")
    )
    missing = [crate.relative_to(REPOSITORY).as_posix() for crate in crates if not (crate / "Cargo.toml").is_file()]
    if missing:
        raise RuntimeError(f"PRODUCTION_CRATE_MANIFEST_UNAVAILABLE: {missing}")
    return crates


def tracked_rust_sources(repository: Path, crates: list[Path]) -> list[Path]:
    """Require the tracked production-source census to match the working tree."""
    source_roots = {
        (crate / "src").relative_to(repository).as_posix() + "/"
        for crate in crates
    }
    try:
        tracked_output = subprocess.check_output(
            ["git", "-C", str(repository), "ls-files", "-z", "--", "omega_engine/crates_rs"],
            encoding="utf-8",
            stderr=subprocess.PIPE,
        )
    except (OSError, UnicodeError, subprocess.CalledProcessError) as exc:
        raise RuntimeError("TRACKED_RUST_CENSUS_UNAVAILABLE: git ls-files failed") from exc
    tracked = {
        relative
        for relative in tracked_output.split("\0")
        if relative.endswith(".rs")
        and any(relative.startswith(root) for root in source_roots)
    }
    actual = {
        path.relative_to(repository).as_posix()
        for crate in crates
        for path in (crate / "src").rglob("*.rs")
        if path.is_file()
    }
    missing = sorted(tracked - actual)
    untracked = sorted(actual - tracked)
    if missing or untracked:
        raise RuntimeError(
            "TRACKED_RUST_CENSUS_UNAVAILABLE: "
            f"missing_tracked={missing}; untracked={untracked}"
        )
    return [repository / relative for relative in sorted(tracked)]


def route_owner_crate(path: str) -> str | None:
    parts = path.split("/")
    if parts[:3] == ["omega_engine", "crates_rs", "tests"] and len(parts) > 3:
        return parts[3]
    if parts[:2] == ["omega_engine", "crates_rs"] and len(parts) > 2:
        return parts[2]
    return None


def q(value: str) -> str:
    return json.dumps(value, ensure_ascii=False)


def node_id(prefix: str, value: str) -> str:
    return prefix + re.sub(r"[^A-Za-z0-9_]", "_", value).upper()


def census() -> dict:
    crates = production_crates()
    rust_files = tracked_rust_sources(REPOSITORY, crates)
    routes = records(PLANS / "wdp_rust_routes.jsonl")
    route_nodes = {row["id"]: row for row in routes if row.get("type") == "node"}
    finite_routes = [
        row
        for row in routes
        if row.get("type") == "edge" and row.get("kind") == "implemented_finite_route"
    ]
    routed = set()
    owner_artifacts: set[str] = set()
    by_source: Counter[str] = Counter()
    by_crate: Counter[str] = Counter()
    for edge in finite_routes:
        by_source[edge["from"]] += 1
        target = route_nodes[edge["to"]]
        artifact_path = target["artifact"]["path"]
        owner_artifacts.add(artifact_path)
        owner = route_owner_crate(artifact_path)
        if owner and (CRATES / owner / "Cargo.toml").is_file():
            routed.add(owner)
            by_crate[owner] += 1

    paper_graph = records(PLANS / "paper_math_dags/paper_dag.jsonl")
    goals = records(PLANS / "goal_dag.jsonl")
    paper_families = sorted(
        path.name
        for path in PAPERS.iterdir()
        if path.is_dir()
        and not path.name.startswith("_")
        and path.name not in {"plans", "_images"}
    )
    contracts = (
        REPOSITORY
        / "omega_engine_governance/contracts/contract_canonical_definitions"
    )
    contract_files = sorted((*contracts.rglob("*.yaml"), *contracts.rglob("*.yml")))
    rust_pattern = re.compile(r"omega_engine/crates_rs/[A-Za-z0-9_./-]+\.rs")
    bound_paths: set[str] = set()
    for path in contract_files:
        bound_paths.update(rust_pattern.findall(path.read_text(encoding="utf-8")))
    actual_rust = {path.relative_to(REPOSITORY).as_posix() for path in rust_files}
    return {
        "crates": crates,
        "rust_files": rust_files,
        "rust_file_census_mode": RUST_FILE_CENSUS_MODE,
        "owner_artifacts": owner_artifacts,
        "routed_crates": routed,
        "routes_by_crate": by_crate,
        "routes_by_source": by_source,
        "finite_routes": finite_routes,
        "paper_families": paper_families,
        "paper_nodes": sum(row.get("type") == "node" for row in paper_graph),
        "paper_edges": sum(row.get("type") == "edge" for row in paper_graph),
        "goals": goals,
        "route_nodes": route_nodes,
        "contract_files": contract_files,
        "contract_bound_rust": bound_paths & actual_rust,
    }


def validate_numbered_files(include_output: bool = True) -> None:
    seen: set[int] = set()
    failures: list[str] = []
    for path in sorted(item for item in ARCHITECTURE.iterdir() if item.is_file()):
        if path == OUTPUT and not include_output:
            continue
        prefix_match = re.match(r"^(\d{2})_", path.name)
        if not prefix_match:
            continue
        prefix = int(prefix_match.group(1))
        if prefix >= 19:
            continue
        match = ORDERED_NAME.fullmatch(path.name)
        if not match:
            failures.append(f"not NN_<20-char-stub>.<ext>: {path.name}")
            continue
        if prefix in seen:
            failures.append(f"duplicate numeric prefix: {prefix:02d}")
        seen.add(prefix)
    required = {0, 1} if include_output else {0}
    if not required.issubset(seen):
        failures.append("00 root or 01 SVG is absent")
    if failures:
        raise ValueError("; ".join(failures))


def build_dot(data: dict) -> str:
    crates: list[Path] = data["crates"]
    routed: set[str] = data["routed_crates"]
    status_counts = Counter(goal["status"] for goal in data["goals"])
    route_hub_label = (
        f"{len(data['finite_routes'])} implemented finite routes\n"
        f"{len(data['owner_artifacts'])} owner artifacts · scoped APIs"
    )
    lines = [
        "digraph omega_architecture {",
        '  graph [rankdir=LR, bgcolor="#fbfcfe", pad="0.35", nodesep="0.18", ranksep="0.55", splines=polyline, fontname="Arial", label="Omega Engine: papers → deep ideas → Python → Rust → centralized contracts → Lean\nNavigation and finite-route coverage; no arrow alone certifies a theorem", labelloc=t, fontsize=22];',
        '  node [shape=box, style="rounded,filled", fontname="Arial", fontsize=9, color="#44546a", fillcolor="white", margin="0.08,0.05"];',
        '  edge [fontname="Arial", fontsize=7, color="#718096", arrowsize=0.6];',
        '  DOC_ROOT [shape=tab, fillcolor="#163a5f", fontcolor="white", label="00_omega_system_rootmap\ndocument root"];',
        '  PREGEN [fillcolor="#d9eaf7", label="Pre-Genesis\nconceptual root"];',
        '  DISTINCTION [shape=ellipse, fillcolor="#d9eaf7", label="<>\nprimitive witnessed difference"];',
        '  SN [fillcolor="#d9eaf7", label="S(n)\npresentations"];',
        '  MSSN [fillcolor="#d9eaf7", label="MSS-N\nminimal symbol system"];',
        '  WDP [fillcolor="#9fd3c7", label="WDP\nprotected questions and finite obstructions"];',
        '  DOC_ROOT -> PREGEN [color="#1769aa", penwidth=2, label="conceptual entry"];',
        '  PREGEN -> DISTINCTION -> SN -> MSSN -> WDP [color="#1769aa", penwidth=2];',
        '  GENESIS [fillcolor="#d9eaf7", label="Genesis 19L57G1\nadmission and passage profiles"];',
        '  ONGOING [fillcolor="#d9eaf7", label="Genesis Ongoing\nfinite continuation families"];',
        '  PREGEN -> GENESIS [style=dashed, label="reviewed programme link"];',
        '  GENESIS -> DISTINCTION [style=dashed];',
        '  SN -> ONGOING [style=dashed];',
        '  ONGOING -> WDP [style=dashed];',
        "  subgraph cluster_papers {",
        '    label="PAPER layer — every F004 top-level family is a peer source container";',
        '    color="#b8c2cc"; style="rounded,dashed";',
    ]
    paper_ids = {}
    for family in data["paper_families"]:
        ident = node_id("P_", family)
        paper_ids[family] = ident
        label = family.replace("_", " ")
        lines.append(f"    {ident} [fillcolor=\"#fff4cc\", label={q(label)}];")
    lines.extend(["  }"])
    for ident in paper_ids.values():
        lines.append(f"  DOC_ROOT -> {ident} [style=dotted, color=\"#b08d00\"]; ")

    ideas = {
        "I_PQRC": "Presentation · Question\nReport · Certificate",
        "I_QUOT": "protected-question quotient\nfuture-sensitive reports",
        "I_LGGR": "LGGR\nlocal checks and global obstruction",
        "I_CODA": "CODA · Prime · DDC\nproposal, descent and continuation",
        "I_PO": "Projection Obstruction\nresiduals, retractions and holonomy",
        "I_QM": "finite QM\nstate, effect, channel and Bell tests",
        "I_SIGN": "FSP · Majorana · MUB\nsign and finite geometry",
        "I_LIMIT": "finite-to-continuum · GR · RH\nscaling and completion",
    }
    lines.extend(
        [
            "  subgraph cluster_ideas {",
            '    label="Deep-idea layer — finite extracted interfaces, not one general theorem";',
            '    color="#b8c2cc"; style="rounded";',
        ]
    )
    for ident, label in ideas.items():
        lines.append(f"    {ident} [fillcolor=\"#e9ddff\", label={q(label)}];")
    lines.append("  }")
    for ident in ideas:
        lines.append(f"  WDP -> {ident} [color=\"#6b46c1\", label=\"scoped extraction\"]; ")
    family_ideas = {
        "001_finite_obstruction_calculus": ("I_PQRC", "I_QUOT", "I_LGGR", "I_CODA"),
        "002_projection_obstruction": ("I_PO",),
        "003_quantum_foundations": ("I_QM",),
        "004_general_relativity": ("I_LIMIT",),
        "005_mind_and_consciousness": ("I_PQRC",),
        "006_finite_qm": ("I_QM",),
        "007_finite_to_continuum": ("I_LIMIT",),
        "008_fsp": ("I_SIGN",),
        "009_ms_majorana": ("I_SIGN",),
        "010_mub6": ("I_SIGN",),
        "011_rh": ("I_LIMIT",),
        "012_rsi": ("I_PQRC",),
        "013_trace_zero_quotient_duality": ("I_QM", "I_QUOT"),
        "014_linkedin_articles": ("I_PQRC",),
        "015_pfp": ("I_PQRC", "I_CODA"),
    }
    for family, targets in family_ideas.items():
        for target in targets:
            lines.append(
                f"  {paper_ids[family]} -> {target} [style=dotted, color=\"#8b6f00\", label=\"idea inventory\"];"
            )

    python_roots = [
        "omega_engine_woland",
        "omega_engine_pfp",
        "omega_engine_operating_system",
        "omega_engine_applications",
        "omega_engine_research_papers",
    ]
    lines.extend(
        [
            "  subgraph cluster_python {",
            '    label="Python interpretation and application layer";',
            '    color="#b8c2cc"; style="rounded";',
        ]
    )
    for root in python_roots:
        lines.append(f"    {node_id('PY_', root)} [fillcolor=\"#fbd5e5\", label={q(root)}];")
    lines.append("  }")
    for idea in ideas:
        lines.append(f"  {idea} -> PY_OMEGA_ENGINE_WOLAND [style=dashed, color=\"#a63d6f\"]; ")
    lines.extend(
        [
            "  PY_OMEGA_ENGINE_PFP -> PY_OMEGA_ENGINE_WOLAND [label=\"task/profile input\"];",
            "  PY_OMEGA_ENGINE_WOLAND -> PY_OMEGA_ENGINE_OPERATING_SYSTEM [label=\"native host seam\"];",
            "  PY_OMEGA_ENGINE_APPLICATIONS -> PY_OMEGA_ENGINE_WOLAND [label=\"consumer\"];",
            "  PY_OMEGA_ENGINE_RESEARCH_PAPERS -> PY_OMEGA_ENGINE_OPERATING_SYSTEM [style=dashed, label=\"scoped replay\"];",
            "  subgraph cluster_route_sources {",
            '    label="Finite-route source profiles from wdp_rust_routes.jsonl";',
            '    color="#b8c2cc"; style="rounded,dashed";',
        ]
    )
    paper_sources = sorted(
        (key, value)
        for key, value in data["route_nodes"].items()
        if value.get("kind") == "paper"
    )
    for source_id, source in paper_sources:
        count = data["routes_by_source"][source_id]
        fill = "#c6f6d5" if count else "#edf2f7"
        label = source["title"] + f"\\n{count} finite route(s)"
        lines.append(
            f"    {node_id('SRC_', source_id)} [fillcolor=\"{fill}\", label={q(label)}];"
        )
    lines.extend(
        [
            "  }",
            f'  ROUTE_HUB [shape=component, fillcolor="#c6f6d5", label={q(route_hub_label)}];',
            '  PY_OMEGA_ENGINE_OPERATING_SYSTEM -> ROUTE_HUB [color="#248232", penwidth=2, label="checked host boundary"];',
            "  subgraph cluster_rust {",
            f'    label="Rust production crates — {len(crates)} directories; green = current route owner, grey = not yet paper-route-bound";',
            '    color="#b8c2cc"; style="rounded";',
        ]
    )
    for source_id, _source in paper_sources:
        count = data["routes_by_source"][source_id]
        style = "solid" if count else "dashed"
        color = "#248232" if count else "#a0aec0"
        lines.append(
            f"  WDP -> {node_id('SRC_', source_id)} [style=dotted, color=\"#718096\", label=\"profile registry\"];"
        )
        lines.append(
            f"  {node_id('SRC_', source_id)} -> ROUTE_HUB [style={style}, color=\"{color}\", label={q(str(count))}];"
        )
    for crate in crates:
        manifest = tomllib.loads((crate / "Cargo.toml").read_text(encoding="utf-8"))
        package = manifest.get("package", {}).get("name", crate.name)
        label = crate.name if package == crate.name else f"{crate.name}\nCargo: {package}"
        color = "#c6f6d5" if crate.name in routed else "#edf2f7"
        lines.append(
            f"    {node_id('RS_', crate.name)} [fillcolor=\"{color}\", label={q(label)}];"
        )
    lines.append("  }")
    for crate in crates:
        style = "solid" if crate.name in routed else "dashed"
        color = "#248232" if crate.name in routed else "#a0aec0"
        label = (
            f"{data['routes_by_crate'][crate.name]} route(s)"
            if crate.name in routed
            else "unmapped"
        )
        lines.append(
            f"  ROUTE_HUB -> {node_id('RS_', crate.name)} [style={style}, color=\"{color}\", label={q(label)}];"
        )

    contract_bound = len(data["contract_bound_rust"])
    rust_count = len(data["rust_files"])
    lines.extend(
        [
            f'  CONTRACTS [shape=folder, fillcolor="#ffe3b3", label="central YAML contract registry\nomega_engine_governance\n{len(data["contract_files"])} contracts; {contract_bound}/{rust_count} Rust source paths literally bound"];',
            '  LEAN [shape=folder, fillcolor="#cfe8ff", label="Lean4 proof estate\nplanned contract-specific proof bindings"];',
            '  ROUTE_HUB -> CONTRACTS [style=dashed, color="#c56a00", label="planned per-source contract; never inside crates"];',
            '  CONTRACTS -> LEAN [style=dashed, color="#1769aa", label="planned checked theorem/profile binding"];',
            '  LEGEND [shape=note, fillcolor="white", label="Solid green: implemented finite route owner\\nGrey dashed: crate exists but has no current paper-route binding\\nBlue spine: programme orientation; unreviewed mathematical implications remain obligations\\nYAML and Lean arrows are architecture targets, not completed coverage"];',
            f'  STATUS [shape=note, fillcolor="white", label="Current graph census\\n{len(data["paper_families"])} paper families · {data["paper_nodes"]} paper nodes · {data["paper_edges"]} paper edges\\n{len(data["goals"])} goals: {status_counts["done"]} done · {status_counts["open"]} open · {status_counts["blocked"]} blocked · {status_counts["in_progress"]} in progress · {status_counts["deferred"]} deferred\\n{len(data["finite_routes"])} finite routes · {len(routed)}/{len(crates)} production crates route-bound\\nRust census mode: {data["rust_file_census_mode"]}"];',
            "  LEGEND -> STATUS [style=invis];",
            "}",
            "",
        ]
    )
    return "\n".join(lines)


def render(dot: str, output: Path) -> None:
    with tempfile.TemporaryDirectory(prefix="omega-architecture-") as directory:
        source = Path(directory) / "architecture.dot"
        target = Path(directory) / "architecture.svg"
        source.write_text(dot, encoding="utf-8")
        environment = os.environ.copy()
        environment["XDG_CACHE_HOME"] = directory
        subprocess.run(
            ["dot", "-Tsvg", str(source), "-o", str(target)],
            check=True,
            env=environment,
        )
        output.write_bytes(target.read_bytes().replace(b"\r\n", b"\n"))


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--check", action="store_true", help="refuse if the SVG is stale")
    args = parser.parse_args()
    data = census()
    dot = build_dot(data)
    if args.check:
        validate_numbered_files()
        with tempfile.TemporaryDirectory(prefix="omega-architecture-check-") as directory:
            expected = Path(directory) / OUTPUT.name
            render(dot, expected)
            if not OUTPUT.is_file() or OUTPUT.read_bytes() != expected.read_bytes():
                raise SystemExit("architecture SVG is stale; rerun without --check")
    else:
        validate_numbered_files(include_output=False)
        render(dot, OUTPUT)
        validate_numbered_files()
    print(
        json.dumps(
            {
                "paper_families": len(data["paper_families"]),
                "paper_nodes": data["paper_nodes"],
                "goals": len(data["goals"]),
                "finite_routes": len(data["finite_routes"]),
                "production_crates": len(data["crates"]),
                "route_bound_crates": len(data["routed_crates"]),
                "production_rust_files": len(data["rust_files"]),
                "rust_file_census_mode": data["rust_file_census_mode"],
                "owner_artifacts": len(data["owner_artifacts"]),
                "contract_bound_rust_paths": len(data["contract_bound_rust"]),
                "output": OUTPUT.relative_to(REPOSITORY).as_posix(),
            },
            sort_keys=True,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
