# F004 Papers: Research Monograph and Object Paper Library

**Directory:** `omega_engine_atlas/coda_atlas/F004_papers/`  
**Status:** Library index. Each row below quotes the live ledger. A row is not a theorem census and not a fresh Lake or pytest run.  
**AuthorityEffect:** None  

---

## 1. Overview

Floor 4 (`F004_papers/`) holds the research papers, monograph suites, companion harnesses, and claim ledgers where a ledger file is present. Each program keeps its own receipts. The status cell is the ledger's status. Protocol terminals stay spelled as the ledger spells them, including `REQUIRES_CORRECTION`, `PROOF_CANDIDATE`, `HEURISTIC_UNCERTIFIED`, `OPEN`, `HistoricalIllustrativeFixture`, `PAIRED_REPLAY_PENDING`, and `UNTESTED_NOT_ESTABLISHED`.

---

## 2. Paper Programs Register

| Index | Program Name | Primary Domain | Status | Key Artifacts |
|---|---|---|---|---|
| `001` | [`001_finite_obstruction_calculus`](001_finite_obstruction_calculus) | Discrete Cochain & Boundary Calculus | Open | `foc_claim_ledger.yaml` is absent (0 paths). Package titles that say machine-checked denote the named constructor lemma, not a certification of the programme. |
| `002` | [`002_projection_obstruction`](002_projection_obstruction) | Projection Obstruction Dynamics | Open correction | Paper 000 is an author-review revision: S1 stays open and unqualified C4 is refuted. Paper 033's numerical prototype is `HEURISTIC_UNCERTIFIED`. Paper 035's four master claims are `REQUIRES_CORRECTION`. |
| `003` | `003_quantum_foundations` | Quantum Foundations | Removed from this tree | The directory was deleted on 2026-10-22. This row is an index mark, not a retraction of any theorem that lived there. |
| `004` | `004_general_relativity` | Finite lattice residuals and Regge bookkeeping | Removed from this tree | The directory was deleted on 2026-10-22. This row is an index mark, not a retraction of any theorem that lived there. |
| `005` | [`005_mind_and_consciousness`](005_mind_and_consciousness) | Finite observation bound | Open review | `001_awareness_mind_consciousness/REVIEW_SCOPE.md` withdraws the cohomological dissolution of the hard problem and keeps one finite two-state bound. `what_is_awareness.md` is an interpretive note. The hard problem stays open. HOPE-OMG-005B is `UNTESTED_NOT_ESTABLISHED`. The companions `001_google_hope_omega_engine.md`, the attack memo, the pseudoinverse note, and `source/` are absent from `000_google_hope/`. |
| `006` | `006_finite_qm` | Finite Quantum Mechanics & State Discrimination | Removed from this tree | The directory was deleted on 2026-10-22. This row is an index mark, not a retraction of any theorem that lived there. |
| `007` | `007_finite_to_continuum` | Finite cyclic inclusions and character sums | Removed from this tree | The directory was deleted on 2026-10-22. This row is an index mark, not a retraction of any theorem that lived there. |
| `008` | `008_fsp` | Fermion Sign Problem & Meron Clusters | Removed from this tree | The directory was deleted on 2026-10-22. This row is an index mark, not a retraction of any theorem that lived there. |
| `009` | `009_ms_majorana` | Majorana realization-packet gap | Removed from this tree | The directory was deleted on 2026-10-22. This row is an index mark, not a retraction of any theorem that lived there. |
| `010` | `010_mub6` | Mutually Unbiased Bases in Dimension 6 | Removed from this tree | Gap G1 stays open. The manuscript directory was deleted on 2026-10-22. Seven mutually unbiased bases in dimension 6 are not settled by this deletion. |
| `011` | [`011_rh`](011_rh) | Riemann Hypothesis Finite Weil Positivity | Research | `rh_status` is `OPEN`. PO011-C10 is `WITHDRAWN`. The shift is a bijection of the test class, not a corridor. |
| `012` | [`012_rsi`](012_rsi) | Finite relational report pigeonhole | Foundation | In `RelationalRsiNoGo.lean`, `rsi_impossible` refuses an injection of `N + 1` duplicate-free reports into a carrier of length `N`. In `RsiImpossible.lean`, the declaration of the same name is a separate descent under strict internal dominance and alignment. Both sit inside RSI-15. |
| `013` | [`013_trace_zero_quotient_duality`](013_trace_zero_quotient_duality) | Trace-Zero Quotient Duality | Scoped monograph; Lean absent | Theorem 4.1 states quotients `6` and `9/2` on `K_{2,3}`. `claim_ledger.md` records that statement. No Lean formalization is claimed. |
| `014` | [`014_linkedin_articles`](014_linkedin_articles) | Public essays | Essays | Five "What the Hell Is" essays. `pfp/` tiers 2–4 are outline files. |
| `015` | [`015_pfp`](015_pfp) | Proposal Fidelity Protocol & Symbol Game | Open | The shelf index is not a verification of each paper. Shelves 012–020 are absent. Shelf 011 on disk is `011_pfp_the_minimum_theorem`. |

---

## 3. Verification & Ledgers

- **Multi-Paper Claim Cross-Check:** [`cross_check_claim_ledgers.py`](cross_check_claim_ledgers.py)  
  The script is the cross-check. This register does not record a fresh run of it.
- **Zenodo Deposit Registry:** [`zenodo_records.md`](zenodo_records.md)  
  Records archive identifiers, deposit checksums, and release manifests. A row there is a deposit record, not a new proof.
- **Setup & Results Ledger:** [`setup_and_results.md`](setup_and_results.md)  
  Consolidated experimental notes. A recorded count is not a rerun.

---

## 4. Foundational Master Essays & Public Introductions

- **Observer essay:** [`linkedin_article_001_what_the_hell_is_an_observer_v001.md`](014_linkedin_articles/linkedin_article_001_what_the_hell_is_an_observer_v001.md)  
  A public essay. The essay says it is not solving quantum measurement, AI safety, consciousness, or institutional failure.

